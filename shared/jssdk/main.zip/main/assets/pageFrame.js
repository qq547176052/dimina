//#region ../common/dist/common.js
function isFunction$3(value) {
	return typeof value === "function";
}
function uuid$2() {
	return Math.random().toString(36).slice(2, 7);
}
var isBrowser$2 = typeof window !== "undefined" && typeof navigator !== "undefined";
isBrowser$2 && /Android/i.test(navigator.userAgent);
isBrowser$2 && /iPad|iPhone|iPod/.test(navigator.userAgent);
isBrowser$2 && /OpenHarmony|harmony/.test(navigator.userAgent);
isBrowser$2 && /Android|iPad|iPhone|iPod|OpenHarmony|harmony|Mobile/.test(navigator.userAgent);
(() => {
	if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) return true;
	else return false;
})();
var JSModules$2 = {};
var MODULES_STATUS_UNLOAD$2 = 1;
var MODULES_STATUS_LOADED$2 = 2;
function modDefine(id, factory) {
	if (!JSModules$2[id]) JSModules$2[id] = {
		factory,
		status: MODULES_STATUS_UNLOAD$2,
		exports: void 0
	};
}
function modRequire$2(id, callback, errorCallback) {
	if (typeof id !== "string") throw new TypeError("require args must be a string");
	const mod = JSModules$2[id];
	if (!mod) throw new Error(`module ${id} not found`);
	if (mod.status === MODULES_STATUS_UNLOAD$2) {
		mod.status = MODULES_STATUS_LOADED$2;
		const module = { exports: {} };
		let res;
		try {
			if (mod.factory) res = mod.factory.call(null, modRequire$2, module, module.exports);
		} catch (e) {
			mod.status = MODULES_STATUS_UNLOAD$2;
			const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
			console.error(`require ${id} error: ${em}`);
			if (isFunction$3(errorCallback)) errorCallback({
				mod: id,
				errMsg: e.message
			});
		}
		mod.exports = module.exports === void 0 ? res : module.exports;
	}
	if (isFunction$3(callback)) callback(mod.exports);
	return mod.exports;
}
modRequire$2.async = async (id) => {
	return new Promise((resolve, reject) => {
		try {
			resolve(modRequire$2(id));
		} catch (e) {
			reject(/* @__PURE__ */ new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
		}
	});
};
var Callback$2 = class {
	constructor() {
		this.callbacks = {};
	}
	store(callback, keep, evtId = uuid$2()) {
		if (keep) {
			for (const [k, v] of Object.entries(this.callbacks)) if (v.callback === callback) return k;
		}
		this.callbacks[evtId] = {
			callback,
			keep
		};
		return evtId;
	}
	/**
	* [Container] triggerCallback -> [Service] invoke
	* @param {*} evtId
	* @param {*} args
	*/
	invoke(evtId, args) {
		if (evtId === void 0) return;
		const obj = this.callbacks[evtId];
		if (obj && isFunction$3(obj.callback)) {
			obj.callback(args);
			if (!obj.keep) delete this.callbacks[evtId];
		}
	}
	remove(evtId) {
		if (evtId) Object.keys(this.callbacks).forEach((k) => {
			if (evtId === k) delete this.callbacks[k];
		});
		else Object.entries(this.callbacks).forEach(([k, v]) => {
			if (v.keep) delete this.callbacks[k];
		});
	}
};
new Callback$2();
//#endregion
//#region ../render/dist/render.js
function defineArrayMethod(name, value) {
	if (typeof Array.prototype[name] === "function") return;
	Object.defineProperty(Array.prototype, name, {
		value,
		configurable: true,
		writable: true
	});
}
defineArrayMethod("toReversed", function toReversed() {
	return Array.prototype.slice.call(this).reverse();
});
defineArrayMethod("toSorted", function toSorted(compareFn) {
	return Array.prototype.slice.call(this).sort(compareFn);
});
defineArrayMethod("toSpliced", function toSpliced(...args) {
	const copy = Array.prototype.slice.call(this);
	copy.splice(...args);
	return copy;
});
function isFunction$2(value) {
	return typeof value === "function";
}
function deepEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== "object" || typeof b !== "object" || a == null || b == null) return false;
	const keysA = Object.keys(a);
	const keysB = Object.keys(b);
	if (keysA.length !== keysB.length) return false;
	return keysA.every((key) => deepEqual(a[key], b[key]));
}
function hasOwn$1(object, key) {
	return Object.prototype.hasOwnProperty.call(object, key);
}
function isUnsafeProperty(key) {
	return key === "__proto__";
}
function isDeepKey(key) {
	switch (typeof key) {
		case "number":
		case "symbol": return false;
		case "string": return key.includes(".") || key.includes("[") || key.includes("]");
	}
}
function isIndex(value, length = Number.MAX_SAFE_INTEGER) {
	switch (typeof value) {
		case "number": return Number.isInteger(value) && value >= 0 && value < length;
		case "symbol": return false;
		case "string": return /^(?:0|[1-9]\d*)$/.test(value);
	}
}
function isObject$1(value) {
	return value !== null && (typeof value === "object" || typeof value === "function");
}
function isSymbol$1(value) {
	return typeof value === "symbol" || Object.prototype.toString.call(value) === "[object Symbol]";
}
function isEqualsSameValueZero(value, other) {
	return value === other || Number.isNaN(value) && Number.isNaN(other);
}
function toKey(value) {
	if (typeof value === "string" || typeof value === "symbol") return value;
	if (Object.is(value?.valueOf?.(), -0)) return "-0";
	return String(value);
}
function toPath(value) {
	if (Array.isArray(value)) return value.map(toKey);
	if (typeof value === "symbol") return [value];
	value = toPathString(value);
	const result = [];
	const length = value.length;
	if (length === 0) return result;
	let index = 0;
	let key = "";
	let quoteChar = "";
	let bracket = false;
	if (value.charCodeAt(0) === 46) {
		result.push("");
		index++;
	}
	while (index < length) {
		const char = value[index];
		if (quoteChar) if (char === "\\" && index + 1 < length) {
			index++;
			key += value[index];
		} else if (char === quoteChar) quoteChar = "";
		else key += char;
		else if (bracket) if (char === "\"" || char === "'") quoteChar = char;
		else if (char === "]") {
			bracket = false;
			result.push(key);
			key = "";
		} else key += char;
		else if (char === "[") {
			bracket = true;
			if (key) {
				result.push(key);
				key = "";
			}
		} else if (char === ".") {
			if (key) {
				result.push(key);
				key = "";
			}
		} else key += char;
		index++;
	}
	if (key) result.push(key);
	return result;
}
function toPathString(value) {
	if (value == null) return "";
	if (typeof value === "string") return value;
	if (Array.isArray(value)) return value.map(toPathString).join(",");
	const result = String(value);
	if (result === "0" && Object.is(Number(value), -0)) return "-0";
	return result;
}
function isKey(value, object) {
	if (Array.isArray(value)) return false;
	if (typeof value === "number" || typeof value === "boolean" || value == null || isSymbol$1(value)) return true;
	return typeof value === "string" && (/^\w*$/.test(value) || !/\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/.test(value)) || object != null && hasOwn$1(object, value);
}
function getWithPath(object, path, defaultValue) {
	if (path.length === 0) return defaultValue;
	let current = object;
	for (let index = 0; index < path.length; index++) {
		if (current == null) return defaultValue;
		if (isUnsafeProperty(path[index])) return defaultValue;
		current = current[path[index]];
	}
	if (current === void 0) return defaultValue;
	return current;
}
function get(data, path) {
	if (data == null) return;
	switch (typeof path) {
		case "string": {
			if (isUnsafeProperty(path)) return;
			const result = data[path];
			if (result === void 0) return isDeepKey(path) ? get(data, toPath(path)) : void 0;
			return result;
		}
		case "number":
		case "symbol": {
			if (typeof path === "number") path = toKey(path);
			const result = data[path];
			return result === void 0 ? void 0 : result;
		}
		default: {
			if (Array.isArray(path)) return getWithPath(data, path);
			path = Object.is(path?.valueOf(), -0) ? "-0" : String(path);
			if (isUnsafeProperty(path)) return;
			const result = data[path];
			return result === void 0 ? void 0 : result;
		}
	}
}
function set(data, path, value) {
	updateWith(data, path, () => value, () => void 0);
}
function updateWith(obj, path, updater, customizer) {
	if (obj == null && !isObject$1(obj)) return obj;
	let resolvedPath;
	if (isKey(path, obj)) resolvedPath = [path];
	else if (Array.isArray(path)) resolvedPath = path;
	else resolvedPath = toPath(path);
	const updateValue = updater(get(obj, resolvedPath));
	let current = obj;
	for (let i = 0; i < resolvedPath.length && current != null; i++) {
		const key = toKey(resolvedPath[i]);
		if (isUnsafeProperty(key)) continue;
		let newValue;
		if (i === resolvedPath.length - 1) newValue = updateValue;
		else {
			const objValue = current[key];
			const customizerResult = customizer?.(objValue, key, obj);
			newValue = customizerResult !== void 0 ? customizerResult : isObject$1(objValue) ? objValue : isIndex(resolvedPath[i + 1]) ? [] : {};
		}
		assignValue(current, key, newValue);
		current = current[key];
	}
	return obj;
}
function assignValue(object, key, value) {
	const objValue = object[key];
	if (!(hasOwn$1(object, key) && isEqualsSameValueZero(objValue, value)) || value === void 0 && !(key in object)) object[key] = value;
}
function uuid$1() {
	return Math.random().toString(36).slice(2, 7);
}
function toCamelCase$1(attr) {
	return attr.toLowerCase().replace(/-(.)/g, (_, group) => {
		return group.toUpperCase();
	});
}
/**
* 通过 vnode 获取 data 属性
* @param {*} attrs
* @param {*} handler
*/
function getDataAttributes$1(attrs, handler) {
	if (!attrs) return;
	const result = {};
	for (const attr in attrs) {
		if (!attr.startsWith("data-")) continue;
		const transAttr = toCamelCase$1(attr.replace(/^data-/, ""));
		result[transAttr] = handler(attrs[attr]);
	}
	return result;
}
var isBrowser$1 = typeof window !== "undefined" && typeof navigator !== "undefined";
var isAndroid$1 = isBrowser$1 && /Android/i.test(navigator.userAgent);
var isIOS$1 = isBrowser$1 && /iPad|iPhone|iPod/.test(navigator.userAgent);
isBrowser$1 && /OpenHarmony|harmony/.test(navigator.userAgent);
isBrowser$1 && /Android|iPad|iPhone|iPod|OpenHarmony|harmony|Mobile/.test(navigator.userAgent);
(() => {
	if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) return true;
	else return false;
})();
/**
* 高效的深拷贝实现
* @param {*} value - 要拷贝的值
* @returns {*} 拷贝后的值
*/
function cloneDeep(value) {
	if (value === null || typeof value !== "object") return value;
	const seen = /* @__PURE__ */ new WeakMap();
	function clone(item) {
		if (item === null || typeof item !== "object") return item;
		if (item instanceof Date) return new Date(item);
		if (item instanceof RegExp) return new RegExp(item.source, item.flags);
		if (Array.isArray(item)) {
			if (seen.has(item)) return seen.get(item);
			const arr = [];
			seen.set(item, arr);
			arr.push(...item.map(clone));
			return arr;
		}
		if (seen.has(item)) return seen.get(item);
		const obj = Object.create(Object.getPrototypeOf(item));
		seen.set(item, obj);
		return Object.assign(obj, ...Object.keys(item).map((key) => ({ [key]: clone(item[key]) })));
	}
	return clone(value);
}
var JSModules$1 = {};
var MODULES_STATUS_UNLOAD$1 = 1;
var MODULES_STATUS_LOADED$1 = 2;
function modRequire$1(id, callback, errorCallback) {
	if (typeof id !== "string") throw new TypeError("require args must be a string");
	const mod = JSModules$1[id];
	if (!mod) throw new Error(`module ${id} not found`);
	if (mod.status === MODULES_STATUS_UNLOAD$1) {
		mod.status = MODULES_STATUS_LOADED$1;
		const module = { exports: {} };
		let res;
		try {
			if (mod.factory) res = mod.factory.call(null, modRequire$1, module, module.exports);
		} catch (e) {
			mod.status = MODULES_STATUS_UNLOAD$1;
			const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
			console.error(`require ${id} error: ${em}`);
			if (isFunction$2(errorCallback)) errorCallback({
				mod: id,
				errMsg: e.message
			});
		}
		mod.exports = module.exports === void 0 ? res : module.exports;
	}
	if (isFunction$2(callback)) callback(mod.exports);
	return mod.exports;
}
modRequire$1.async = async (id) => {
	return new Promise((resolve, reject) => {
		try {
			resolve(modRequire$1(id));
		} catch (e) {
			reject(/* @__PURE__ */ new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
		}
	});
};
var Callback$1 = class {
	constructor() {
		this.callbacks = {};
	}
	store(callback, keep, evtId = uuid$1()) {
		if (keep) {
			for (const [k, v] of Object.entries(this.callbacks)) if (v.callback === callback) return k;
		}
		this.callbacks[evtId] = {
			callback,
			keep
		};
		return evtId;
	}
	/**
	* [Container] triggerCallback -> [Service] invoke
	* @param {*} evtId
	* @param {*} args
	*/
	invoke(evtId, args) {
		if (evtId === void 0) return;
		const obj = this.callbacks[evtId];
		if (obj && isFunction$2(obj.callback)) {
			obj.callback(args);
			if (!obj.keep) delete this.callbacks[evtId];
		}
	}
	remove(evtId) {
		if (evtId) Object.keys(this.callbacks).forEach((k) => {
			if (evtId === k) delete this.callbacks[k];
		});
		else Object.entries(this.callbacks).forEach(([k, v]) => {
			if (v.keep) delete this.callbacks[k];
		});
	}
};
var callback_default = new Callback$1();
var DATA_FUNCTION_REFERENCE_KEY = "__dimina_data_function_reference__";
var DATA_FUNCTION_REFERENCE_VERSION = 1;
function createDataFunctionReference(id) {
	return {
		[DATA_FUNCTION_REFERENCE_KEY]: id,
		version: DATA_FUNCTION_REFERENCE_VERSION
	};
}
function isDataFunctionReference(value) {
	return value !== null && typeof value === "object" && value.version === DATA_FUNCTION_REFERENCE_VERSION && typeof value[DATA_FUNCTION_REFERENCE_KEY] === "string" && Object.keys(value).length === 2;
}
function getDataFunctionReferenceId(value) {
	return isDataFunctionReference(value) ? value[DATA_FUNCTION_REFERENCE_KEY] : void 0;
}
/**
* Recursively transform functions and their bridge references without applying
* JSON semantics to the surrounding data. This keeps Dates, typed arrays and
* other bridge-supported values intact while making functions transferable.
*/
function transformDataFunctions(value, { mapFunction, mapReference } = {}, seen = /* @__PURE__ */ new WeakMap()) {
	if (typeof value === "function") return mapFunction ? mapFunction(value) : value;
	if (value === null || typeof value !== "object") return value;
	if (isDataFunctionReference(value)) return mapReference ? mapReference(value) : value;
	if (value instanceof Date || value instanceof RegExp || value instanceof ArrayBuffer || ArrayBuffer.isView(value)) return value;
	if (!Array.isArray(value)) {
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) return value;
	}
	if (seen.has(value)) return seen.get(value);
	const transformed = Array.isArray(value) ? [] : {};
	seen.set(value, transformed);
	for (const key of Object.keys(value)) transformed[key] = transformDataFunctions(value[key], {
		mapFunction,
		mapReference
	}, seen);
	return transformed;
}
var SUPPORTED_PROPERTY_TYPES = /* @__PURE__ */ new Set([
	String,
	Number,
	Boolean,
	Object,
	Array,
	null
]);
function isPropertyType(type) {
	return SUPPORTED_PROPERTY_TYPES.has(type);
}
function getImplicitDefault(type) {
	if (type === String) return "";
	if (type === Number) return 0;
	if (type === Boolean) return false;
	if (type === Array) return [];
	return null;
}
function normalizeOptionalTypes(optionalTypes) {
	if (!Array.isArray(optionalTypes)) return [];
	return optionalTypes.filter(isPropertyType);
}
/**
* 将小程序 properties 的简写/完整声明统一成可跨线程传输的语义结构。
* 微信在声明阶段会为未显式提供 value 的属性按主类型补默认值。
*/
function normalizePropertyDefinition(definition) {
	let type;
	let optionalTypes = [];
	let value;
	if (isPropertyType(definition)) type = definition;
	else if (definition && typeof definition === "object") {
		type = definition.type;
		optionalTypes = normalizeOptionalTypes(definition.optionalTypes);
		value = definition.value;
	}
	if (!isPropertyType(type)) type = optionalTypes[0] ?? null;
	if (value === void 0) value = getImplicitDefault(type);
	return {
		type,
		optionalTypes,
		value: cloneDeep(value)
	};
}
function isExparserArray(value) {
	return Array.isArray(value);
}
function isPlainArray(value) {
	return isExparserArray(value) && value?.constructor?.name === Array.name;
}
/**
* optionalTypes 只做严格类型匹配；命中后保持调用方传入值，不执行主类型转换。
*/
function matchesPropertyType(type, value) {
	if (type === String) return typeof value === "string";
	if (type === Number) return Number.isFinite(value);
	if (type === Boolean) return typeof value === "boolean";
	if (type === Object) return value !== null && value?.constructor === Object;
	if (type === Array) return isPlainArray(value);
	return value !== void 0;
}
function warnTypeConversion(warn, message) {
	if (typeof warn === "function") warn(message);
}
/**
* 对齐微信 exparser 的 property convertValueToType 行为。
* absent=true 表示模板没有传入该属性，此时使用组件声明的默认值。
*/
function resolvePropertyValue(schema, value, { absent = false, warn } = {}) {
	if (absent) return cloneDeep(schema.value);
	for (const optionalType of schema.optionalTypes || []) if (matchesPropertyType(optionalType, value)) return value;
	const type = schema.type;
	if (type === String) {
		if (value === null || value === void 0) {
			warnTypeConversion(warn, "property received type-uncompatible value: expected <String> but get null value. Used empty string instead.");
			return "";
		}
		if (typeof value === "object") warnTypeConversion(warn, "property received type-uncompatible value: expected <String> but got object-typed value. Forcely converted.");
		return String(value);
	}
	if (type === Number) {
		try {
			if (Number.isFinite(Number(value))) return Number(value);
		} catch {}
		warnTypeConversion(warn, `property received type-uncompatible value: expected <Number> but ${typeof value === "number" ? "got NaN or Infinity" : "got non-number value"}. Used 0 instead.`);
		return 0;
	}
	if (type === Boolean) return !!value;
	if (type === Array) {
		if (isExparserArray(value)) return value;
		warnTypeConversion(warn, "property received type-uncompatible value: expected <Array> but got non-array value. Used empty array instead.");
		return [];
	}
	if (type === Object) {
		if (typeof value === "object") return value;
		warnTypeConversion(warn, "property received type-uncompatible value: expected <Object> but got non-object value. Used null instead.");
		return null;
	}
	if (value === void 0) return null;
	return value;
}
function normalizePropertyValues(schemas, values = {}, { isAbsent, warn } = {}) {
	const normalized = {};
	for (const [name, schema] of Object.entries(schemas || {})) {
		const absent = typeof isAbsent === "function" ? isAbsent(name) : !Object.prototype.hasOwnProperty.call(values, name);
		normalized[name] = resolvePropertyValue(schema, values[name], {
			absent,
			warn
		});
	}
	return normalized;
}
function mitt_default(n) {
	return {
		all: n = n || /* @__PURE__ */ new Map(),
		on: function(t, e) {
			var i = n.get(t);
			i ? i.push(e) : n.set(t, [e]);
		},
		off: function(t, e) {
			var i = n.get(t);
			i && (e ? i.splice(i.indexOf(e) >>> 0, 1) : n.set(t, []));
		},
		emit: function(t, e) {
			var i = n.get(t);
			i && i.slice().map(function(n) {
				n(e);
			}), (i = n.get("*")) && i.slice().map(function(n) {
				n(t, e);
			});
		}
	};
}
var proxyByReference = /* @__PURE__ */ new Map();
function getDataFunctionProxy(reference) {
	if (proxyByReference.has(reference)) return proxyByReference.get(reference);
	const proxy = function dataFunctionReference() {};
	Object.defineProperty(proxy, "toJSON", { value: () => createDataFunctionReference(reference) });
	proxyByReference.set(reference, proxy);
	return proxy;
}
function decodeDataFunctions(value) {
	return transformDataFunctions(value, { mapReference(dataFunctionReference) {
		return getDataFunctionProxy(getDataFunctionReferenceId(dataFunctionReference));
	} });
}
var message_default = new class Message {
	constructor() {
		this.event = mitt_default();
		this.init();
	}
	init() {
		if (!window.DiminaRenderBridge) window.DiminaRenderBridge = {};
		window.DiminaRenderBridge.onMessage = (msg) => {
			const decodedMsg = decodeDataFunctions(msg);
			console.log("[system]", "[render]", "receive msg: ", decodedMsg);
			const { type, body } = decodedMsg;
			this.event.emit(type, body);
		};
	}
	on(type, callback) {
		this.event.on(type, callback);
	}
	send(msg) {
		window.DiminaRenderBridge.publish(JSON.stringify(msg));
	}
	invoke(msg) {
		if (isAndroid$1 || isIOS$1) Message.prototype.invoke = function(msg) {
			window.DiminaRenderBridge.invoke(JSON.stringify(msg));
		};
		else Message.prototype.invoke = function(msg) {
			window.DiminaRenderBridge.invoke(msg);
		};
		return this.invoke(msg);
	}
	off(type, callback) {
		this.event.off(type, callback);
	}
	wait(eventName) {
		return new Promise((resolve) => {
			this.on(eventName, (msg) => {
				resolve(msg.data);
				this.off(eventName);
			});
		});
	}
	waitAndSend(eventName, msg) {
		const response = this.wait(eventName);
		this.send(msg);
		return response;
	}
}();
var TYPE_MAPS = {
	s: String,
	n: Number,
	b: Boolean,
	o: Object,
	a: Array
};
var Module = class {
	constructor(moduleInfo) {
		this.moduleInfo = moduleInfo;
	}
	setInitialData(props) {
		this.builtinBehaviors = new Set(props?.__diminaMeta?.builtinBehaviors || []);
		const serializedProps = props ? { ...props } : props;
		if (serializedProps) delete serializedProps.__diminaMeta;
		const { propertySchemas, vueProps } = this.unSerializeProps(serializedProps);
		this.propertySchemas = propertySchemas;
		this.props = vueProps;
	}
	unSerializeProps(properties) {
		if (!properties) return {
			propertySchemas: {},
			vueProps: {}
		};
		const propertySchemas = {};
		const vueProps = {};
		for (const key in properties) {
			const property = properties[key];
			const types = (Array.isArray(property.type) ? property.type : [property.type]).map((item) => this.convertStringToType(item));
			propertySchemas[key] = normalizePropertyDefinition({
				type: types[0],
				optionalTypes: types.slice(1),
				value: property.default
			});
			vueProps[key] = { type: null };
			if (property.cls) vueProps[key].cls = true;
		}
		return {
			propertySchemas,
			vueProps
		};
	}
	/**
	* 将字符串转换成实际类型
	* @param {*} type
	*/
	convertStringToType(type) {
		if (type === null) return null;
		const result = TYPE_MAPS[type];
		if (!result) console.warn("[system]", "[render]", `unknown props type ${type}`);
		return result;
	}
};
var Loader = class {
	constructor() {
		this.staticModules = {};
	}
	async loadResource(opts) {
		const { bridgeId, appId, pagePath, root, baseUrl, resourceLoadId } = opts;
		const filename = pagePath.replace(/\//g, "_");
		const appStyleResourcePath = `${baseUrl}${appId}/main/app.css`;
		const styleResourcePath = `${baseUrl}${appId}/${root}/${filename}.css`;
		const viewResourcePath = `${baseUrl}${appId}/${root}/${filename}.js`;
		const errors = (await Promise.allSettled([
			this.loadStyleFile(appStyleResourcePath),
			this.loadStyleFile(styleResourcePath),
			this.loadScriptFile(viewResourcePath)
		])).filter((result) => result.status === "rejected").map((result) => result.reason instanceof Error ? result.reason.message : String(result.reason));
		if (errors.length) {
			this.reportResourceLoadFailed({
				bridgeId,
				pagePath,
				errors,
				resourceLoadId
			});
			return false;
		}
		try {
			window.modRequire(pagePath);
		} catch (error) {
			this.reportResourceLoadFailed({
				bridgeId,
				pagePath,
				resourceLoadId,
				errors: [error instanceof Error ? error.message : String(error)]
			});
			return false;
		}
		message_default.invoke({
			type: "renderResourceLoaded",
			target: "service",
			body: {
				bridgeId,
				resourceLoadId
			}
		});
		return true;
	}
	reportResourceLoadFailed({ bridgeId, pagePath, errors, resourceLoadId }) {
		console.error("[system]", "[render]", `资源加载失败: ${errors.join("; ")}`);
		message_default.invoke({
			type: "renderResourceLoadFailed",
			target: "service",
			body: {
				bridgeId,
				resourceLoadId,
				pagePath,
				errors
			}
		});
	}
	loadStyleFile(path) {
		return new Promise((resolve, reject) => {
			const style = document.createElement("link");
			style.rel = "stylesheet";
			style.href = path;
			style.onload = () => {
				resolve();
			};
			style.onerror = () => {
				reject(/* @__PURE__ */ new Error(`样式文件加载失败: ${path}`));
			};
			document.head.append(style);
		});
	}
	loadScriptFile(path) {
		return new Promise((resolve, reject) => {
			const script = document.createElement("script");
			script.src = path;
			script.onload = () => {
				resolve();
			};
			script.onerror = () => {
				reject(/* @__PURE__ */ new Error(`脚本文件加载失败: ${path}`));
			};
			document.head.append(script);
		});
	}
	/**
	* 创建渲染层映射实例
	* window.Module -> create
	* @param {{path: string, scopeId: string, usingComponents: object, render: Function}} moduleInfo
	*/
	createModule(moduleInfo) {
		const { path, usingComponents, componentPlaceholder = {} } = moduleInfo;
		if (this.staticModules[path]) return;
		this.staticModules[path] = new Module(moduleInfo);
		for (const [componentName, componentPath] of Object.entries(usingComponents)) try {
			window.modRequire(componentPath);
		} catch (error) {
			const placeholderName = componentPlaceholder[componentName];
			const placeholderPath = placeholderName && usingComponents[placeholderName];
			if (!placeholderPath) throw error;
			window.modRequire(placeholderPath);
		}
	}
	/**
	* serviceResourceLoaded && renderResourceLoaded ->
	* [Container]resourceLoaded -> [Service]resourceLoaded -> [Service]initialDataReady -> [Container]initialDataReady -> [Render]setInitialData
	* @param {*} initialData
	*/
	setInitialData(initialData) {
		for (const [path, data] of Object.entries(initialData)) {
			if (!data) continue;
			const module = this.staticModules[path];
			if (!module) continue;
			module.setInitialData(data);
		}
	}
	getModuleByPath(path) {
		return this.staticModules[path];
	}
};
var loader_default = new Loader();
var Env = class {
	constructor() {
		this.init();
	}
	init() {
		window.Module = (moduleInfo) => loader_default.createModule(moduleInfo);
	}
};
var env_default = new Env();
/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
// @__NO_SIDE_EFFECTS__
function makeMap(str) {
	const map = /* @__PURE__ */ Object.create(null);
	for (const key of str.split(",")) map[key] = 1;
	return (val) => val in map;
}
var EMPTY_OBJ = {};
var EMPTY_ARR = [];
var NOOP = () => {};
var NO = () => false;
var isOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && (key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
var isModelListener = (key) => key.startsWith("onUpdate:");
var extend = Object.assign;
var remove = (arr, el) => {
	const i = arr.indexOf(el);
	if (i > -1) arr.splice(i, 1);
};
var hasOwnProperty$1 = Object.prototype.hasOwnProperty;
var hasOwn = (val, key) => hasOwnProperty$1.call(val, key);
var isArray = Array.isArray;
var isMap = (val) => toTypeString(val) === "[object Map]";
var isSet = (val) => toTypeString(val) === "[object Set]";
var isDate = (val) => toTypeString(val) === "[object Date]";
var isFunction$1 = (val) => typeof val === "function";
var isString$1 = (val) => typeof val === "string";
var isSymbol = (val) => typeof val === "symbol";
var isObject = (val) => val !== null && typeof val === "object";
var isPromise = (val) => {
	return (isObject(val) || isFunction$1(val)) && isFunction$1(val.then) && isFunction$1(val.catch);
};
var objectToString$1 = Object.prototype.toString;
var toTypeString = (value) => objectToString$1.call(value);
var toRawType = (value) => {
	return toTypeString(value).slice(8, -1);
};
var isPlainObject = (val) => toTypeString(val) === "[object Object]";
var isIntegerKey = (key) => isString$1(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
var isReservedProp = /* @__PURE__ */ makeMap(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted");
var cacheStringFunction = (fn) => {
	const cache = /* @__PURE__ */ Object.create(null);
	return ((str) => {
		return cache[str] || (cache[str] = fn(str));
	});
};
var camelizeRE = /-\w/g;
var camelize = cacheStringFunction((str) => {
	return str.replace(camelizeRE, (c) => c.slice(1).toUpperCase());
});
var hyphenateRE = /\B([A-Z])/g;
var hyphenate = cacheStringFunction((str) => str.replace(hyphenateRE, "-$1").toLowerCase());
var capitalize = cacheStringFunction((str) => {
	return str.charAt(0).toUpperCase() + str.slice(1);
});
var toHandlerKey = cacheStringFunction((str) => {
	return str ? `on${capitalize(str)}` : ``;
});
var hasChanged = (value, oldValue) => !Object.is(value, oldValue);
var invokeArrayFns = (fns, ...arg) => {
	for (let i = 0; i < fns.length; i++) fns[i](...arg);
};
var def = (obj, key, value, writable = false) => {
	Object.defineProperty(obj, key, {
		configurable: true,
		enumerable: false,
		writable,
		value
	});
};
var looseToNumber = (val) => {
	const n = parseFloat(val);
	return isNaN(n) ? val : n;
};
var toNumber = (val) => {
	const n = isString$1(val) ? Number(val) : NaN;
	return isNaN(n) ? val : n;
};
var _globalThis;
var getGlobalThis = () => {
	return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
};
function normalizeStyle(value) {
	if (isArray(value)) {
		const res = {};
		for (let i = 0; i < value.length; i++) {
			const item = value[i];
			const normalized = isString$1(item) ? parseStringStyle(item) : normalizeStyle(item);
			if (normalized) for (const key in normalized) res[key] = normalized[key];
		}
		return res;
	} else if (isString$1(value) || isObject(value)) return value;
}
var listDelimiterRE = /;(?![^(]*\))/g;
var propertyDelimiterRE = /:([^]+)/;
var styleCommentRE = /\/\*[^]*?\*\//g;
function parseStringStyle(cssText) {
	const ret = {};
	cssText.replace(styleCommentRE, "").split(listDelimiterRE).forEach((item) => {
		if (item) {
			const tmp = item.split(propertyDelimiterRE);
			tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
		}
	});
	return ret;
}
function normalizeClass(value) {
	let res = "";
	if (isString$1(value)) res = value;
	else if (isArray(value)) for (let i = 0; i < value.length; i++) {
		const normalized = normalizeClass(value[i]);
		if (normalized) res += normalized + " ";
	}
	else if (isObject(value)) {
		for (const name in value) if (value[name]) res += name + " ";
	}
	return res.trim();
}
function normalizeProps(props) {
	if (!props) return null;
	let { class: klass, style } = props;
	if (klass && !isString$1(klass)) props.class = normalizeClass(klass);
	if (style) props.style = normalizeStyle(style);
	return props;
}
var specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
var isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
specialBooleanAttrs + "";
function includeBooleanAttr(value) {
	return !!value || value === "";
}
function looseCompareArrays(a, b) {
	if (a.length !== b.length) return false;
	let equal = true;
	for (let i = 0; equal && i < a.length; i++) equal = looseEqual(a[i], b[i]);
	return equal;
}
function looseEqual(a, b) {
	if (a === b) return true;
	let aValidType = isDate(a);
	let bValidType = isDate(b);
	if (aValidType || bValidType) return aValidType && bValidType ? a.getTime() === b.getTime() : false;
	aValidType = isSymbol(a);
	bValidType = isSymbol(b);
	if (aValidType || bValidType) return a === b;
	aValidType = isArray(a);
	bValidType = isArray(b);
	if (aValidType || bValidType) return aValidType && bValidType ? looseCompareArrays(a, b) : false;
	aValidType = isObject(a);
	bValidType = isObject(b);
	if (aValidType || bValidType) {
		if (!aValidType || !bValidType) return false;
		if (Object.keys(a).length !== Object.keys(b).length) return false;
		for (const key in a) {
			const aHasKey = a.hasOwnProperty(key);
			const bHasKey = b.hasOwnProperty(key);
			if (aHasKey && !bHasKey || !aHasKey && bHasKey || !looseEqual(a[key], b[key])) return false;
		}
	}
	return String(a) === String(b);
}
var isRef$1 = (val) => {
	return !!(val && val["__v_isRef"] === true);
};
var toDisplayString = (val) => {
	return isString$1(val) ? val : val == null ? "" : isArray(val) || isObject(val) && (val.toString === objectToString$1 || !isFunction$1(val.toString)) ? isRef$1(val) ? toDisplayString(val.value) : JSON.stringify(val, replacer, 2) : String(val);
};
var replacer = (_key, val) => {
	if (isRef$1(val)) return replacer(_key, val.value);
	else if (isMap(val)) return { [`Map(${val.size})`]: [...val.entries()].reduce((entries, [key, val2], i) => {
		entries[stringifySymbol(key, i) + " =>"] = val2;
		return entries;
	}, {}) };
	else if (isSet(val)) return { [`Set(${val.size})`]: [...val.values()].map((v) => stringifySymbol(v)) };
	else if (isSymbol(val)) return stringifySymbol(val);
	else if (isObject(val) && !isArray(val) && !isPlainObject(val)) return String(val);
	return val;
};
var stringifySymbol = (v, i = "") => {
	var _a;
	return isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v;
};
function normalizeCssVarValue(value) {
	if (value == null) return "initial";
	if (typeof value === "string") return value === "" ? " " : value;
	if (typeof value !== "number" || !Number.isFinite(value)) {}
	return String(value);
}
/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
var activeEffectScope;
var EffectScope = class {
	constructor(detached = false) {
		this.detached = detached;
		/**
		* @internal
		*/
		this._active = true;
		/**
		* @internal track `on` calls, allow `on` call multiple times
		*/
		this._on = 0;
		/**
		* @internal
		*/
		this.effects = [];
		/**
		* @internal
		*/
		this.cleanups = [];
		this._isPaused = false;
		this._warnOnRun = true;
		this.__v_skip = true;
		if (!detached && activeEffectScope) if (activeEffectScope.active) {
			this.parent = activeEffectScope;
			this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(this) - 1;
		} else {
			this._active = false;
			this._warnOnRun = false;
		}
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = true;
			let i, l;
			if (this.scopes) {
				const scopes = this.scopes.slice();
				for (i = 0, l = scopes.length; i < l; i++) scopes[i].pause();
			}
			for (i = 0, l = this.effects.length; i < l; i++) this.effects[i].pause();
		}
	}
	/**
	* Resumes the effect scope, including all child scopes and effects.
	*/
	resume() {
		if (this._active) {
			if (this._isPaused) {
				this._isPaused = false;
				let i, l;
				if (this.scopes) {
					const scopes = this.scopes.slice();
					for (i = 0, l = scopes.length; i < l; i++) scopes[i].resume();
				}
				const effects = this.effects.slice();
				for (i = 0, l = effects.length; i < l; i++) effects[i].resume();
			}
		}
	}
	run(fn) {
		if (this._active) {
			const currentEffectScope = activeEffectScope;
			try {
				activeEffectScope = this;
				return fn();
			} finally {
				activeEffectScope = currentEffectScope;
			}
		}
	}
	/**
	* This should only be called on non-detached scopes
	* @internal
	*/
	on() {
		if (++this._on === 1) {
			this.prevScope = activeEffectScope;
			activeEffectScope = this;
		}
	}
	/**
	* This should only be called on non-detached scopes
	* @internal
	*/
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (activeEffectScope === this) activeEffectScope = this.prevScope;
			else {
				let current = activeEffectScope;
				while (current) {
					if (current.prevScope === this) {
						current.prevScope = this.prevScope;
						break;
					}
					current = current.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(fromParent) {
		if (this._active) {
			this._active = false;
			let i, l;
			for (i = 0, l = this.effects.length; i < l; i++) this.effects[i].stop();
			this.effects.length = 0;
			for (i = 0, l = this.cleanups.length; i < l; i++) this.cleanups[i]();
			this.cleanups.length = 0;
			if (this.scopes) {
				const scopes = this.scopes.slice();
				for (i = 0, l = scopes.length; i < l; i++) scopes[i].stop(true);
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !fromParent) {
				const last = this.parent.scopes.pop();
				if (last && last !== this) {
					this.parent.scopes[this.index] = last;
					last.index = this.index;
				}
			}
			this.parent = void 0;
		}
	}
};
function getCurrentScope() {
	return activeEffectScope;
}
var activeSub;
var pausedQueueEffects = /* @__PURE__ */ new WeakSet();
var ReactiveEffect = class {
	constructor(fn) {
		this.fn = fn;
		/**
		* @internal
		*/
		this.deps = void 0;
		/**
		* @internal
		*/
		this.depsTail = void 0;
		/**
		* @internal
		*/
		this.flags = 5;
		/**
		* @internal
		*/
		this.next = void 0;
		/**
		* @internal
		*/
		this.cleanup = void 0;
		this.scheduler = void 0;
		if (activeEffectScope) if (activeEffectScope.active) activeEffectScope.effects.push(this);
		else this.flags &= -2;
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		if (this.flags & 64) {
			this.flags &= -65;
			if (pausedQueueEffects.has(this)) {
				pausedQueueEffects.delete(this);
				this.trigger();
			}
		}
	}
	/**
	* @internal
	*/
	notify() {
		if (this.flags & 2 && !(this.flags & 32)) return;
		if (!(this.flags & 8)) batch(this);
	}
	run() {
		if (!(this.flags & 1)) return this.fn();
		this.flags |= 2;
		cleanupEffect(this);
		prepareDeps(this);
		const prevEffect = activeSub;
		const prevShouldTrack = shouldTrack;
		activeSub = this;
		shouldTrack = true;
		try {
			return this.fn();
		} finally {
			cleanupDeps(this);
			activeSub = prevEffect;
			shouldTrack = prevShouldTrack;
			this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let link = this.deps; link; link = link.nextDep) removeSub(link);
			this.deps = this.depsTail = void 0;
			cleanupEffect(this);
			this.onStop && this.onStop();
			this.flags &= -2;
		}
	}
	trigger() {
		if (this.flags & 64) pausedQueueEffects.add(this);
		else if (this.scheduler) this.scheduler();
		else this.runIfDirty();
	}
	/**
	* @internal
	*/
	runIfDirty() {
		if (isDirty(this)) this.run();
	}
	get dirty() {
		return isDirty(this);
	}
};
var batchDepth = 0;
var batchedSub;
var batchedComputed;
function batch(sub, isComputed = false) {
	sub.flags |= 8;
	if (isComputed) {
		sub.next = batchedComputed;
		batchedComputed = sub;
		return;
	}
	sub.next = batchedSub;
	batchedSub = sub;
}
function startBatch() {
	batchDepth++;
}
function endBatch() {
	if (--batchDepth > 0) return;
	if (batchedComputed) {
		let e = batchedComputed;
		batchedComputed = void 0;
		while (e) {
			const next = e.next;
			e.next = void 0;
			e.flags &= -9;
			e = next;
		}
	}
	let error;
	while (batchedSub) {
		let e = batchedSub;
		batchedSub = void 0;
		while (e) {
			const next = e.next;
			e.next = void 0;
			e.flags &= -9;
			if (e.flags & 1) try {
				e.trigger();
			} catch (err) {
				if (!error) error = err;
			}
			e = next;
		}
	}
	if (error) throw error;
}
function prepareDeps(sub) {
	for (let link = sub.deps; link; link = link.nextDep) {
		link.version = -1;
		link.prevActiveLink = link.dep.activeLink;
		link.dep.activeLink = link;
	}
}
function cleanupDeps(sub) {
	let head;
	let tail = sub.depsTail;
	let link = tail;
	while (link) {
		const prev = link.prevDep;
		if (link.version === -1) {
			if (link === tail) tail = prev;
			removeSub(link);
			removeDep(link);
		} else head = link;
		link.dep.activeLink = link.prevActiveLink;
		link.prevActiveLink = void 0;
		link = prev;
	}
	sub.deps = head;
	sub.depsTail = tail;
}
function isDirty(sub) {
	for (let link = sub.deps; link; link = link.nextDep) if (link.dep.version !== link.version || link.dep.computed && (refreshComputed(link.dep.computed) || link.dep.version !== link.version)) return true;
	if (sub._dirty) return true;
	return false;
}
function refreshComputed(computed) {
	if (computed.flags & 4 && !(computed.flags & 16)) return;
	computed.flags &= -17;
	if (computed.globalVersion === globalVersion) return;
	computed.globalVersion = globalVersion;
	if (!computed.isSSR && computed.flags & 128 && (!computed.deps && !computed._dirty || !isDirty(computed))) return;
	computed.flags |= 2;
	const dep = computed.dep;
	const prevSub = activeSub;
	const prevShouldTrack = shouldTrack;
	activeSub = computed;
	shouldTrack = true;
	try {
		prepareDeps(computed);
		const value = computed.fn(computed._value);
		if (dep.version === 0 || hasChanged(value, computed._value)) {
			computed.flags |= 128;
			computed._value = value;
			dep.version++;
		}
	} catch (err) {
		dep.version++;
		throw err;
	} finally {
		activeSub = prevSub;
		shouldTrack = prevShouldTrack;
		cleanupDeps(computed);
		computed.flags &= -3;
	}
}
function removeSub(link, soft = false) {
	const { dep, prevSub, nextSub } = link;
	if (prevSub) {
		prevSub.nextSub = nextSub;
		link.prevSub = void 0;
	}
	if (nextSub) {
		nextSub.prevSub = prevSub;
		link.nextSub = void 0;
	}
	if (dep.subs === link) {
		dep.subs = prevSub;
		if (!prevSub && dep.computed) {
			dep.computed.flags &= -5;
			for (let l = dep.computed.deps; l; l = l.nextDep) removeSub(l, true);
		}
	}
	if (!soft && !--dep.sc && dep.map) dep.map.delete(dep.key);
}
function removeDep(link) {
	const { prevDep, nextDep } = link;
	if (prevDep) {
		prevDep.nextDep = nextDep;
		link.prevDep = void 0;
	}
	if (nextDep) {
		nextDep.prevDep = prevDep;
		link.nextDep = void 0;
	}
}
var shouldTrack = true;
var trackStack = [];
function pauseTracking() {
	trackStack.push(shouldTrack);
	shouldTrack = false;
}
function resetTracking() {
	const last = trackStack.pop();
	shouldTrack = last === void 0 ? true : last;
}
function cleanupEffect(e) {
	const { cleanup } = e;
	e.cleanup = void 0;
	if (cleanup) {
		const prevSub = activeSub;
		activeSub = void 0;
		try {
			cleanup();
		} finally {
			activeSub = prevSub;
		}
	}
}
var globalVersion = 0;
var Link = class {
	constructor(sub, dep) {
		this.sub = sub;
		this.dep = dep;
		this.version = dep.version;
		this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
};
var Dep = class {
	constructor(computed) {
		this.computed = computed;
		this.version = 0;
		/**
		* Link between this dep and the current active effect
		*/
		this.activeLink = void 0;
		/**
		* Doubly linked list representing the subscribing effects (tail)
		*/
		this.subs = void 0;
		/**
		* For object property deps cleanup
		*/
		this.map = void 0;
		this.key = void 0;
		/**
		* Subscriber counter
		*/
		this.sc = 0;
		/**
		* @internal
		*/
		this.__v_skip = true;
	}
	track(debugInfo) {
		if (!activeSub || !shouldTrack || activeSub === this.computed) return;
		let link = this.activeLink;
		if (link === void 0 || link.sub !== activeSub) {
			link = this.activeLink = new Link(activeSub, this);
			if (!activeSub.deps) activeSub.deps = activeSub.depsTail = link;
			else {
				link.prevDep = activeSub.depsTail;
				activeSub.depsTail.nextDep = link;
				activeSub.depsTail = link;
			}
			addSub(link);
		} else if (link.version === -1) {
			link.version = this.version;
			if (link.nextDep) {
				const next = link.nextDep;
				next.prevDep = link.prevDep;
				if (link.prevDep) link.prevDep.nextDep = next;
				link.prevDep = activeSub.depsTail;
				link.nextDep = void 0;
				activeSub.depsTail.nextDep = link;
				activeSub.depsTail = link;
				if (activeSub.deps === link) activeSub.deps = next;
			}
		}
		return link;
	}
	trigger(debugInfo) {
		this.version++;
		globalVersion++;
		this.notify(debugInfo);
	}
	notify(debugInfo) {
		startBatch();
		try {
			for (let link = this.subs; link; link = link.prevSub) if (link.sub.notify()) link.sub.dep.notify();
		} finally {
			endBatch();
		}
	}
};
function addSub(link) {
	link.dep.sc++;
	if (link.sub.flags & 4) {
		const computed = link.dep.computed;
		if (computed && !link.dep.subs) {
			computed.flags |= 20;
			for (let l = computed.deps; l; l = l.nextDep) addSub(l);
		}
		const currentTail = link.dep.subs;
		if (currentTail !== link) {
			link.prevSub = currentTail;
			if (currentTail) currentTail.nextSub = link;
		}
		link.dep.subs = link;
	}
}
var targetMap = /* @__PURE__ */ new WeakMap();
var ITERATE_KEY = /* @__PURE__ */ Symbol("");
var MAP_KEY_ITERATE_KEY = /* @__PURE__ */ Symbol("");
var ARRAY_ITERATE_KEY = /* @__PURE__ */ Symbol("");
function track(target, type, key) {
	if (shouldTrack && activeSub) {
		let depsMap = targetMap.get(target);
		if (!depsMap) targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
		let dep = depsMap.get(key);
		if (!dep) {
			depsMap.set(key, dep = new Dep());
			dep.map = depsMap;
			dep.key = key;
		}
		dep.track();
	}
}
function trigger(target, type, key, newValue, oldValue, oldTarget) {
	const depsMap = targetMap.get(target);
	if (!depsMap) {
		globalVersion++;
		return;
	}
	const run = (dep) => {
		if (dep) dep.trigger();
	};
	startBatch();
	if (type === "clear") depsMap.forEach(run);
	else {
		const targetIsArray = isArray(target);
		const isArrayIndex = targetIsArray && isIntegerKey(key);
		if (targetIsArray && key === "length") {
			const newLength = Number(newValue);
			depsMap.forEach((dep, key2) => {
				if (key2 === "length" || key2 === ARRAY_ITERATE_KEY || !isSymbol(key2) && key2 >= newLength) run(dep);
			});
		} else {
			if (key !== void 0 || depsMap.has(void 0)) run(depsMap.get(key));
			if (isArrayIndex) run(depsMap.get(ARRAY_ITERATE_KEY));
			switch (type) {
				case "add":
					if (!targetIsArray) {
						run(depsMap.get(ITERATE_KEY));
						if (isMap(target)) run(depsMap.get(MAP_KEY_ITERATE_KEY));
					} else if (isArrayIndex) run(depsMap.get("length"));
					break;
				case "delete":
					if (!targetIsArray) {
						run(depsMap.get(ITERATE_KEY));
						if (isMap(target)) run(depsMap.get(MAP_KEY_ITERATE_KEY));
					}
					break;
				case "set":
					if (isMap(target)) run(depsMap.get(ITERATE_KEY));
					break;
			}
		}
	}
	endBatch();
}
function reactiveReadArray(array) {
	const raw = /* @__PURE__ */ toRaw(array);
	if (raw === array) return raw;
	track(raw, "iterate", ARRAY_ITERATE_KEY);
	return /* @__PURE__ */ isShallow(array) ? raw : raw.map(toReactive);
}
function shallowReadArray(arr) {
	track(arr = /* @__PURE__ */ toRaw(arr), "iterate", ARRAY_ITERATE_KEY);
	return arr;
}
function toWrapped(target, item) {
	if (/* @__PURE__ */ isReadonly(target)) return /* @__PURE__ */ isReactive(target) ? toReadonly(toReactive(item)) : toReadonly(item);
	return toReactive(item);
}
var arrayInstrumentations = {
	__proto__: null,
	[Symbol.iterator]() {
		return iterator(this, Symbol.iterator, (item) => toWrapped(this, item));
	},
	concat(...args) {
		return reactiveReadArray(this).concat(...args.map((x) => isArray(x) ? reactiveReadArray(x) : x));
	},
	entries() {
		return iterator(this, "entries", (value) => {
			value[1] = toWrapped(this, value[1]);
			return value;
		});
	},
	every(fn, thisArg) {
		return apply$1(this, "every", fn, thisArg, void 0, arguments);
	},
	filter(fn, thisArg) {
		return apply$1(this, "filter", fn, thisArg, (v) => v.map((item) => toWrapped(this, item)), arguments);
	},
	find(fn, thisArg) {
		return apply$1(this, "find", fn, thisArg, (item) => toWrapped(this, item), arguments);
	},
	findIndex(fn, thisArg) {
		return apply$1(this, "findIndex", fn, thisArg, void 0, arguments);
	},
	findLast(fn, thisArg) {
		return apply$1(this, "findLast", fn, thisArg, (item) => toWrapped(this, item), arguments);
	},
	findLastIndex(fn, thisArg) {
		return apply$1(this, "findLastIndex", fn, thisArg, void 0, arguments);
	},
	forEach(fn, thisArg) {
		return apply$1(this, "forEach", fn, thisArg, void 0, arguments);
	},
	includes(...args) {
		return searchProxy(this, "includes", args);
	},
	indexOf(...args) {
		return searchProxy(this, "indexOf", args);
	},
	join(separator) {
		return reactiveReadArray(this).join(separator);
	},
	lastIndexOf(...args) {
		return searchProxy(this, "lastIndexOf", args);
	},
	map(fn, thisArg) {
		return apply$1(this, "map", fn, thisArg, void 0, arguments);
	},
	pop() {
		return noTracking(this, "pop");
	},
	push(...args) {
		return noTracking(this, "push", args);
	},
	reduce(fn, ...args) {
		return reduce(this, "reduce", fn, args);
	},
	reduceRight(fn, ...args) {
		return reduce(this, "reduceRight", fn, args);
	},
	shift() {
		return noTracking(this, "shift");
	},
	some(fn, thisArg) {
		return apply$1(this, "some", fn, thisArg, void 0, arguments);
	},
	splice(...args) {
		return noTracking(this, "splice", args);
	},
	toReversed() {
		return reactiveReadArray(this).toReversed();
	},
	toSorted(comparer) {
		return reactiveReadArray(this).toSorted(comparer);
	},
	toSpliced(...args) {
		return reactiveReadArray(this).toSpliced(...args);
	},
	unshift(...args) {
		return noTracking(this, "unshift", args);
	},
	values() {
		return iterator(this, "values", (item) => toWrapped(this, item));
	}
};
function iterator(self, method, wrapValue) {
	const arr = shallowReadArray(self);
	const iter = arr[method]();
	if (arr !== self && !/* @__PURE__ */ isShallow(self)) {
		iter._next = iter.next;
		iter.next = () => {
			const result = iter._next();
			if (!result.done) result.value = wrapValue(result.value);
			return result;
		};
	}
	return iter;
}
var arrayProto = Array.prototype;
function apply$1(self, method, fn, thisArg, wrappedRetFn, args) {
	const arr = shallowReadArray(self);
	const needsWrap = arr !== self && !/* @__PURE__ */ isShallow(self);
	const methodFn = arr[method];
	if (methodFn !== arrayProto[method]) {
		const result2 = methodFn.apply(self, args);
		return needsWrap ? toReactive(result2) : result2;
	}
	let wrappedFn = fn;
	if (arr !== self) {
		if (needsWrap) wrappedFn = function(item, index) {
			return fn.call(this, toWrapped(self, item), index, self);
		};
		else if (fn.length > 2) wrappedFn = function(item, index) {
			return fn.call(this, item, index, self);
		};
	}
	const result = methodFn.call(arr, wrappedFn, thisArg);
	return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
}
function reduce(self, method, fn, args) {
	const arr = shallowReadArray(self);
	const needsWrap = arr !== self && !/* @__PURE__ */ isShallow(self);
	let wrappedFn = fn;
	let wrapInitialAccumulator = false;
	if (arr !== self) {
		if (needsWrap) {
			wrapInitialAccumulator = args.length === 0;
			wrappedFn = function(acc, item, index) {
				if (wrapInitialAccumulator) {
					wrapInitialAccumulator = false;
					acc = toWrapped(self, acc);
				}
				return fn.call(this, acc, toWrapped(self, item), index, self);
			};
		} else if (fn.length > 3) wrappedFn = function(acc, item, index) {
			return fn.call(this, acc, item, index, self);
		};
	}
	const result = arr[method](wrappedFn, ...args);
	return wrapInitialAccumulator ? toWrapped(self, result) : result;
}
function searchProxy(self, method, args) {
	const arr = /* @__PURE__ */ toRaw(self);
	track(arr, "iterate", ARRAY_ITERATE_KEY);
	const res = arr[method](...args);
	if ((res === -1 || res === false) && /* @__PURE__ */ isProxy(args[0])) {
		args[0] = /* @__PURE__ */ toRaw(args[0]);
		return arr[method](...args);
	}
	return res;
}
function noTracking(self, method, args = []) {
	pauseTracking();
	startBatch();
	const res = (/* @__PURE__ */ toRaw(self))[method].apply(self, args);
	endBatch();
	resetTracking();
	return res;
}
var isNonTrackableKeys = /* @__PURE__ */ makeMap(`__proto__,__v_isRef,__isVue`);
var builtInSymbols = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol));
function hasOwnProperty(key) {
	if (!isSymbol(key)) key = String(key);
	const obj = /* @__PURE__ */ toRaw(this);
	track(obj, "has", key);
	return obj.hasOwnProperty(key);
}
var BaseReactiveHandler = class {
	constructor(_isReadonly = false, _isShallow = false) {
		this._isReadonly = _isReadonly;
		this._isShallow = _isShallow;
	}
	get(target, key, receiver) {
		if (key === "__v_skip") return target["__v_skip"];
		const isReadonly2 = this._isReadonly, isShallow2 = this._isShallow;
		if (key === "__v_isReactive") return !isReadonly2;
		else if (key === "__v_isReadonly") return isReadonly2;
		else if (key === "__v_isShallow") return isShallow2;
		else if (key === "__v_raw") {
			if (receiver === (isReadonly2 ? isShallow2 ? shallowReadonlyMap : readonlyMap : isShallow2 ? shallowReactiveMap : reactiveMap).get(target) || Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) return target;
			return;
		}
		const targetIsArray = isArray(target);
		if (!isReadonly2) {
			let fn;
			if (targetIsArray && (fn = arrayInstrumentations[key])) return fn;
			if (key === "hasOwnProperty") return hasOwnProperty;
		}
		const res = Reflect.get(target, key, /* @__PURE__ */ isRef(target) ? target : receiver);
		if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) return res;
		if (!isReadonly2) track(target, "get", key);
		if (isShallow2) return res;
		if (/* @__PURE__ */ isRef(res)) {
			const value = targetIsArray && isIntegerKey(key) ? res : res.value;
			return isReadonly2 && isObject(value) ? /* @__PURE__ */ readonly(value) : value;
		}
		if (isObject(res)) return isReadonly2 ? /* @__PURE__ */ readonly(res) : /* @__PURE__ */ reactive(res);
		return res;
	}
};
var MutableReactiveHandler = class extends BaseReactiveHandler {
	constructor(isShallow2 = false) {
		super(false, isShallow2);
	}
	set(target, key, value, receiver) {
		let oldValue = target[key];
		const isArrayWithIntegerKey = isArray(target) && isIntegerKey(key);
		if (!this._isShallow) {
			const isOldValueReadonly = /* @__PURE__ */ isReadonly(oldValue);
			if (!/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value)) {
				oldValue = /* @__PURE__ */ toRaw(oldValue);
				value = /* @__PURE__ */ toRaw(value);
			}
			if (!isArrayWithIntegerKey && /* @__PURE__ */ isRef(oldValue) && !/* @__PURE__ */ isRef(value)) if (isOldValueReadonly) return true;
			else {
				oldValue.value = value;
				return true;
			}
		}
		const hadKey = isArrayWithIntegerKey ? Number(key) < target.length : hasOwn(target, key);
		const result = Reflect.set(target, key, value, /* @__PURE__ */ isRef(target) ? target : receiver);
		if (target === /* @__PURE__ */ toRaw(receiver) && result) {
			if (!hadKey) trigger(target, "add", key, value);
			else if (hasChanged(value, oldValue)) trigger(target, "set", key, value, oldValue);
		}
		return result;
	}
	deleteProperty(target, key) {
		const hadKey = hasOwn(target, key);
		const oldValue = target[key];
		const result = Reflect.deleteProperty(target, key);
		if (result && hadKey) trigger(target, "delete", key, void 0, oldValue);
		return result;
	}
	has(target, key) {
		const result = Reflect.has(target, key);
		if (!isSymbol(key) || !builtInSymbols.has(key)) track(target, "has", key);
		return result;
	}
	ownKeys(target) {
		track(target, "iterate", isArray(target) ? "length" : ITERATE_KEY);
		return Reflect.ownKeys(target);
	}
};
var ReadonlyReactiveHandler = class extends BaseReactiveHandler {
	constructor(isShallow2 = false) {
		super(true, isShallow2);
	}
	set(target, key) {
		return true;
	}
	deleteProperty(target, key) {
		return true;
	}
};
var mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
var readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
var shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(true);
var toShallow = (value) => value;
var getProto = (v) => Reflect.getPrototypeOf(v);
function createIterableMethod(method, isReadonly2, isShallow2) {
	return function(...args) {
		const target = this["__v_raw"];
		const rawTarget = /* @__PURE__ */ toRaw(target);
		const targetIsMap = isMap(rawTarget);
		const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
		const isKeyOnly = method === "keys" && targetIsMap;
		const innerIterator = target[method](...args);
		const wrap = isShallow2 ? toShallow : isReadonly2 ? toReadonly : toReactive;
		!isReadonly2 && track(rawTarget, "iterate", isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY);
		return extend(Object.create(innerIterator), { next() {
			const { value, done } = innerIterator.next();
			return done ? {
				value,
				done
			} : {
				value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
				done
			};
		} });
	};
}
function createReadonlyMethod(type) {
	return function(...args) {
		return type === "delete" ? false : type === "clear" ? void 0 : this;
	};
}
function createInstrumentations(readonly, shallow) {
	const instrumentations = {
		get(key) {
			const target = this["__v_raw"];
			const rawTarget = /* @__PURE__ */ toRaw(target);
			const rawKey = /* @__PURE__ */ toRaw(key);
			if (!readonly) {
				if (hasChanged(key, rawKey)) track(rawTarget, "get", key);
				track(rawTarget, "get", rawKey);
			}
			const { has } = getProto(rawTarget);
			const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
			if (has.call(rawTarget, key)) return wrap(target.get(key));
			else if (has.call(rawTarget, rawKey)) return wrap(target.get(rawKey));
			else if (target !== rawTarget) target.get(key);
		},
		get size() {
			const target = this["__v_raw"];
			!readonly && track(/* @__PURE__ */ toRaw(target), "iterate", ITERATE_KEY);
			return target.size;
		},
		has(key) {
			const target = this["__v_raw"];
			const rawTarget = /* @__PURE__ */ toRaw(target);
			const rawKey = /* @__PURE__ */ toRaw(key);
			if (!readonly) {
				if (hasChanged(key, rawKey)) track(rawTarget, "has", key);
				track(rawTarget, "has", rawKey);
			}
			return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
		},
		forEach(callback, thisArg) {
			const observed = this;
			const target = observed["__v_raw"];
			const rawTarget = /* @__PURE__ */ toRaw(target);
			const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
			!readonly && track(rawTarget, "iterate", ITERATE_KEY);
			return target.forEach((value, key) => {
				return callback.call(thisArg, wrap(value), wrap(key), observed);
			});
		}
	};
	extend(instrumentations, readonly ? {
		add: createReadonlyMethod("add"),
		set: createReadonlyMethod("set"),
		delete: createReadonlyMethod("delete"),
		clear: createReadonlyMethod("clear")
	} : {
		add(value) {
			const target = /* @__PURE__ */ toRaw(this);
			const proto = getProto(target);
			const rawValue = /* @__PURE__ */ toRaw(value);
			const valueToAdd = !shallow && !/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value) ? rawValue : value;
			if (!(proto.has.call(target, valueToAdd) || hasChanged(value, valueToAdd) && proto.has.call(target, value) || hasChanged(rawValue, valueToAdd) && proto.has.call(target, rawValue))) {
				target.add(valueToAdd);
				trigger(target, "add", valueToAdd, valueToAdd);
			}
			return this;
		},
		set(key, value) {
			if (!shallow && !/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value)) value = /* @__PURE__ */ toRaw(value);
			const target = /* @__PURE__ */ toRaw(this);
			const { has, get } = getProto(target);
			let hadKey = has.call(target, key);
			if (!hadKey) {
				key = /* @__PURE__ */ toRaw(key);
				hadKey = has.call(target, key);
			}
			const oldValue = get.call(target, key);
			target.set(key, value);
			if (!hadKey) trigger(target, "add", key, value);
			else if (hasChanged(value, oldValue)) trigger(target, "set", key, value, oldValue);
			return this;
		},
		delete(key) {
			const target = /* @__PURE__ */ toRaw(this);
			const { has, get } = getProto(target);
			let hadKey = has.call(target, key);
			if (!hadKey) {
				key = /* @__PURE__ */ toRaw(key);
				hadKey = has.call(target, key);
			}
			const oldValue = get ? get.call(target, key) : void 0;
			const result = target.delete(key);
			if (hadKey) trigger(target, "delete", key, void 0, oldValue);
			return result;
		},
		clear() {
			const target = /* @__PURE__ */ toRaw(this);
			const hadItems = target.size !== 0;
			const oldTarget = void 0;
			const result = target.clear();
			if (hadItems) trigger(target, "clear", void 0, void 0, oldTarget);
			return result;
		}
	});
	[
		"keys",
		"values",
		"entries",
		Symbol.iterator
	].forEach((method) => {
		instrumentations[method] = createIterableMethod(method, readonly, shallow);
	});
	return instrumentations;
}
function createInstrumentationGetter(isReadonly2, shallow) {
	const instrumentations = createInstrumentations(isReadonly2, shallow);
	return (target, key, receiver) => {
		if (key === "__v_isReactive") return !isReadonly2;
		else if (key === "__v_isReadonly") return isReadonly2;
		else if (key === "__v_raw") return target;
		return Reflect.get(hasOwn(instrumentations, key) && key in target ? instrumentations : target, key, receiver);
	};
}
var mutableCollectionHandlers = { get: /* @__PURE__ */ createInstrumentationGetter(false, false) };
var shallowCollectionHandlers = { get: /* @__PURE__ */ createInstrumentationGetter(false, true) };
var readonlyCollectionHandlers = { get: /* @__PURE__ */ createInstrumentationGetter(true, false) };
var reactiveMap = /* @__PURE__ */ new WeakMap();
var shallowReactiveMap = /* @__PURE__ */ new WeakMap();
var readonlyMap = /* @__PURE__ */ new WeakMap();
var shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
function targetTypeMap(rawType) {
	switch (rawType) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
// @__NO_SIDE_EFFECTS__
function reactive(target) {
	if (/* @__PURE__ */ isReadonly(target)) return target;
	return createReactiveObject(target, false, mutableHandlers, mutableCollectionHandlers, reactiveMap);
}
// @__NO_SIDE_EFFECTS__
function shallowReactive(target) {
	return createReactiveObject(target, false, shallowReactiveHandlers, shallowCollectionHandlers, shallowReactiveMap);
}
// @__NO_SIDE_EFFECTS__
function readonly(target) {
	return createReactiveObject(target, true, readonlyHandlers, readonlyCollectionHandlers, readonlyMap);
}
function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
	if (!isObject(target)) return target;
	if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) return target;
	if (target["__v_skip"] || !Object.isExtensible(target)) return target;
	const existingProxy = proxyMap.get(target);
	if (existingProxy) return existingProxy;
	const targetType = targetTypeMap(toRawType(target));
	if (targetType === 0) return target;
	const proxy = new Proxy(target, targetType === 2 ? collectionHandlers : baseHandlers);
	proxyMap.set(target, proxy);
	return proxy;
}
// @__NO_SIDE_EFFECTS__
function isReactive(value) {
	if (/* @__PURE__ */ isReadonly(value)) return /* @__PURE__ */ isReactive(value["__v_raw"]);
	return !!(value && value["__v_isReactive"]);
}
// @__NO_SIDE_EFFECTS__
function isReadonly(value) {
	return !!(value && value["__v_isReadonly"]);
}
// @__NO_SIDE_EFFECTS__
function isShallow(value) {
	return !!(value && value["__v_isShallow"]);
}
// @__NO_SIDE_EFFECTS__
function isProxy(value) {
	return value ? !!value["__v_raw"] : false;
}
// @__NO_SIDE_EFFECTS__
function toRaw(observed) {
	const raw = observed && observed["__v_raw"];
	return raw ? /* @__PURE__ */ toRaw(raw) : observed;
}
function markRaw(value) {
	if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) def(value, "__v_skip", true);
	return value;
}
var toReactive = (value) => isObject(value) ? /* @__PURE__ */ reactive(value) : value;
var toReadonly = (value) => isObject(value) ? /* @__PURE__ */ readonly(value) : value;
// @__NO_SIDE_EFFECTS__
function isRef(r) {
	return r ? r["__v_isRef"] === true : false;
}
// @__NO_SIDE_EFFECTS__
function ref(value) {
	return createRef(value, false);
}
function createRef(rawValue, shallow) {
	if (/* @__PURE__ */ isRef(rawValue)) return rawValue;
	return new RefImpl(rawValue, shallow);
}
var RefImpl = class {
	constructor(value, isShallow2) {
		this.dep = new Dep();
		this["__v_isRef"] = true;
		this["__v_isShallow"] = false;
		this._rawValue = isShallow2 ? value : /* @__PURE__ */ toRaw(value);
		this._value = isShallow2 ? value : toReactive(value);
		this["__v_isShallow"] = isShallow2;
	}
	get value() {
		this.dep.track();
		return this._value;
	}
	set value(newValue) {
		const oldValue = this._rawValue;
		const useDirectValue = this["__v_isShallow"] || /* @__PURE__ */ isShallow(newValue) || /* @__PURE__ */ isReadonly(newValue);
		newValue = useDirectValue ? newValue : /* @__PURE__ */ toRaw(newValue);
		if (hasChanged(newValue, oldValue)) {
			this._rawValue = newValue;
			this._value = useDirectValue ? newValue : toReactive(newValue);
			this.dep.trigger();
		}
	}
};
function unref(ref2) {
	return /* @__PURE__ */ isRef(ref2) ? ref2.value : ref2;
}
var shallowUnwrapHandlers = {
	get: (target, key, receiver) => key === "__v_raw" ? target : unref(Reflect.get(target, key, receiver)),
	set: (target, key, value, receiver) => {
		const oldValue = target[key];
		if (/* @__PURE__ */ isRef(oldValue) && !/* @__PURE__ */ isRef(value)) {
			oldValue.value = value;
			return true;
		} else return Reflect.set(target, key, value, receiver);
	}
};
function proxyRefs(objectWithRefs) {
	return /* @__PURE__ */ isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
}
var ComputedRefImpl = class {
	constructor(fn, setter, isSSR) {
		this.fn = fn;
		this.setter = setter;
		/**
		* @internal
		*/
		this._value = void 0;
		/**
		* @internal
		*/
		this.dep = new Dep(this);
		/**
		* @internal
		*/
		this.__v_isRef = true;
		/**
		* @internal
		*/
		this.deps = void 0;
		/**
		* @internal
		*/
		this.depsTail = void 0;
		/**
		* @internal
		*/
		this.flags = 16;
		/**
		* @internal
		*/
		this.globalVersion = globalVersion - 1;
		/**
		* @internal
		*/
		this.next = void 0;
		this.effect = this;
		this["__v_isReadonly"] = !setter;
		this.isSSR = isSSR;
	}
	/**
	* @internal
	*/
	notify() {
		this.flags |= 16;
		if (!(this.flags & 8) && activeSub !== this) {
			batch(this, true);
			return true;
		}
	}
	get value() {
		const link = this.dep.track();
		refreshComputed(this);
		if (link) link.version = this.dep.version;
		return this._value;
	}
	set value(newValue) {
		if (this.setter) this.setter(newValue);
	}
};
// @__NO_SIDE_EFFECTS__
function computed$1(getterOrOptions, debugOptions, isSSR = false) {
	let getter;
	let setter;
	if (isFunction$1(getterOrOptions)) getter = getterOrOptions;
	else {
		getter = getterOrOptions.get;
		setter = getterOrOptions.set;
	}
	return new ComputedRefImpl(getter, setter, isSSR);
}
var INITIAL_WATCHER_VALUE = {};
var cleanupMap = /* @__PURE__ */ new WeakMap();
var activeWatcher = void 0;
function onWatcherCleanup(cleanupFn, failSilently = false, owner = activeWatcher) {
	if (owner) {
		let cleanups = cleanupMap.get(owner);
		if (!cleanups) cleanupMap.set(owner, cleanups = []);
		cleanups.push(cleanupFn);
	}
}
function watch$1(source, cb, options = EMPTY_OBJ) {
	const { immediate, deep, once, scheduler, augmentJob, call } = options;
	const reactiveGetter = (source2) => {
		if (deep) return source2;
		if (/* @__PURE__ */ isShallow(source2) || deep === false || deep === 0) return traverse(source2, 1);
		return traverse(source2);
	};
	let effect;
	let getter;
	let cleanup;
	let boundCleanup;
	let forceTrigger = false;
	let isMultiSource = false;
	if (/* @__PURE__ */ isRef(source)) {
		getter = () => source.value;
		forceTrigger = /* @__PURE__ */ isShallow(source);
	} else if (/* @__PURE__ */ isReactive(source)) {
		getter = () => reactiveGetter(source);
		forceTrigger = true;
	} else if (isArray(source)) {
		isMultiSource = true;
		forceTrigger = source.some((s) => /* @__PURE__ */ isReactive(s) || /* @__PURE__ */ isShallow(s));
		getter = () => source.map((s) => {
			if (/* @__PURE__ */ isRef(s)) return s.value;
			else if (/* @__PURE__ */ isReactive(s)) return reactiveGetter(s);
			else if (isFunction$1(s)) return call ? call(s, 2) : s();
		});
	} else if (isFunction$1(source)) if (cb) getter = call ? () => call(source, 2) : source;
	else getter = () => {
		if (cleanup) {
			pauseTracking();
			try {
				cleanup();
			} finally {
				resetTracking();
			}
		}
		const currentEffect = activeWatcher;
		activeWatcher = effect;
		try {
			return call ? call(source, 3, [boundCleanup]) : source(boundCleanup);
		} finally {
			activeWatcher = currentEffect;
		}
	};
	else getter = NOOP;
	if (cb && deep) {
		const baseGetter = getter;
		const depth = deep === true ? Infinity : deep;
		getter = () => traverse(baseGetter(), depth);
	}
	const scope = getCurrentScope();
	const watchHandle = () => {
		effect.stop();
		if (scope && scope.active) remove(scope.effects, effect);
	};
	if (once && cb) {
		const _cb = cb;
		cb = (...args) => {
			const res = _cb(...args);
			watchHandle();
			return res;
		};
	}
	let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
	const job = (immediateFirstRun) => {
		if (!(effect.flags & 1) || !effect.dirty && !immediateFirstRun) return;
		if (cb) {
			const newValue = effect.run();
			if (immediateFirstRun || deep || forceTrigger || (isMultiSource ? newValue.some((v, i) => hasChanged(v, oldValue[i])) : hasChanged(newValue, oldValue))) {
				if (cleanup) cleanup();
				const currentWatcher = activeWatcher;
				activeWatcher = effect;
				try {
					const args = [
						newValue,
						oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
						boundCleanup
					];
					oldValue = newValue;
					call ? call(cb, 3, args) : cb(...args);
				} finally {
					activeWatcher = currentWatcher;
				}
			}
		} else effect.run();
	};
	if (augmentJob) augmentJob(job);
	effect = new ReactiveEffect(getter);
	effect.scheduler = scheduler ? () => scheduler(job, false) : job;
	boundCleanup = (fn) => onWatcherCleanup(fn, false, effect);
	cleanup = effect.onStop = () => {
		const cleanups = cleanupMap.get(effect);
		if (cleanups) {
			if (call) call(cleanups, 4);
			else for (const cleanup2 of cleanups) cleanup2();
			cleanupMap.delete(effect);
		}
	};
	if (cb) if (immediate) job(true);
	else oldValue = effect.run();
	else if (scheduler) scheduler(job.bind(null, true), true);
	else effect.run();
	watchHandle.pause = effect.pause.bind(effect);
	watchHandle.resume = effect.resume.bind(effect);
	watchHandle.stop = watchHandle;
	return watchHandle;
}
function traverse(value, depth = Infinity, seen) {
	if (depth <= 0 || !isObject(value) || value["__v_skip"]) return value;
	seen = seen || /* @__PURE__ */ new Map();
	if ((seen.get(value) || 0) >= depth) return value;
	seen.set(value, depth);
	depth--;
	if (/* @__PURE__ */ isRef(value)) traverse(value.value, depth, seen);
	else if (isArray(value)) for (let i = 0; i < value.length; i++) traverse(value[i], depth, seen);
	else if (isSet(value) || isMap(value)) value.forEach((v) => {
		traverse(v, depth, seen);
	});
	else if (isPlainObject(value)) {
		for (const key in value) traverse(value[key], depth, seen);
		for (const key of Object.getOwnPropertySymbols(value)) if (Object.prototype.propertyIsEnumerable.call(value, key)) traverse(value[key], depth, seen);
	}
	return value;
}
/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function callWithErrorHandling(fn, instance, type, args) {
	try {
		return args ? fn(...args) : fn();
	} catch (err) {
		handleError(err, instance, type);
	}
}
function callWithAsyncErrorHandling(fn, instance, type, args) {
	if (isFunction$1(fn)) {
		const res = callWithErrorHandling(fn, instance, type, args);
		if (res && isPromise(res)) res.catch((err) => {
			handleError(err, instance, type);
		});
		return res;
	}
	if (isArray(fn)) {
		const values = [];
		for (let i = 0; i < fn.length; i++) values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
		return values;
	}
}
function handleError(err, instance, type, throwInDev = true) {
	const contextVNode = instance ? instance.vnode : null;
	const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
	if (instance) {
		let cur = instance.parent;
		const exposedInstance = instance.proxy;
		const errorInfo = `https://vuejs.org/error-reference/#runtime-${type}`;
		while (cur) {
			const errorCapturedHooks = cur.ec;
			if (errorCapturedHooks) {
				for (let i = 0; i < errorCapturedHooks.length; i++) if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) return;
			}
			cur = cur.parent;
		}
		if (errorHandler) {
			pauseTracking();
			callWithErrorHandling(errorHandler, null, 10, [
				err,
				exposedInstance,
				errorInfo
			]);
			resetTracking();
			return;
		}
	}
	logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
}
function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
	if (throwInProd) throw err;
	else console.error(err);
}
var queue = [];
var flushIndex = -1;
var pendingPostFlushCbs = [];
var activePostFlushCbs = null;
var postFlushIndex = 0;
var resolvedPromise = /* @__PURE__ */ Promise.resolve();
var currentFlushPromise = null;
function nextTick(fn) {
	const p = currentFlushPromise || resolvedPromise;
	return fn ? p.then(this ? fn.bind(this) : fn) : p;
}
function findInsertionIndex(id) {
	let start = flushIndex + 1;
	let end = queue.length;
	while (start < end) {
		const middle = start + end >>> 1;
		const middleJob = queue[middle];
		const middleJobId = getId(middleJob);
		if (middleJobId < id || middleJobId === id && middleJob.flags & 2) start = middle + 1;
		else end = middle;
	}
	return start;
}
function queueJob(job) {
	if (!(job.flags & 1)) {
		const jobId = getId(job);
		const lastJob = queue[queue.length - 1];
		if (!lastJob || !(job.flags & 2) && jobId >= getId(lastJob)) queue.push(job);
		else queue.splice(findInsertionIndex(jobId), 0, job);
		job.flags |= 1;
		queueFlush();
	}
}
function queueFlush() {
	if (!currentFlushPromise) currentFlushPromise = resolvedPromise.then(flushJobs);
}
function queuePostFlushCb(cb) {
	if (!isArray(cb)) {
		if (activePostFlushCbs && cb.id === -1) activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
		else if (!(cb.flags & 1)) {
			pendingPostFlushCbs.push(cb);
			cb.flags |= 1;
		}
	} else pendingPostFlushCbs.push(...cb);
	queueFlush();
}
function flushPreFlushCbs(instance, seen, i = flushIndex + 1) {
	for (; i < queue.length; i++) {
		const cb = queue[i];
		if (cb && cb.flags & 2) {
			if (instance && cb.id !== instance.uid) continue;
			queue.splice(i, 1);
			i--;
			if (cb.flags & 4) cb.flags &= -2;
			cb();
			if (!(cb.flags & 4)) cb.flags &= -2;
		}
	}
}
function flushPostFlushCbs(seen) {
	if (pendingPostFlushCbs.length) {
		const deduped = [...new Set(pendingPostFlushCbs)].sort((a, b) => getId(a) - getId(b));
		pendingPostFlushCbs.length = 0;
		if (activePostFlushCbs) {
			activePostFlushCbs.push(...deduped);
			return;
		}
		activePostFlushCbs = deduped;
		for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
			const cb = activePostFlushCbs[postFlushIndex];
			if (cb.flags & 4) cb.flags &= -2;
			if (!(cb.flags & 8)) cb();
			cb.flags &= -2;
		}
		activePostFlushCbs = null;
		postFlushIndex = 0;
	}
}
var getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
function flushJobs(seen) {
	try {
		for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
			const job = queue[flushIndex];
			if (job && !(job.flags & 8)) {
				if (job.flags & 4) job.flags &= -2;
				callWithErrorHandling(job, job.i, job.i ? 15 : 14);
				if (!(job.flags & 4)) job.flags &= -2;
			}
		}
	} finally {
		for (; flushIndex < queue.length; flushIndex++) {
			const job = queue[flushIndex];
			if (job) job.flags &= -2;
		}
		flushIndex = -1;
		queue.length = 0;
		flushPostFlushCbs(seen);
		currentFlushPromise = null;
		if (queue.length || pendingPostFlushCbs.length) flushJobs(seen);
	}
}
var currentRenderingInstance = null;
var currentScopeId = null;
function setCurrentRenderingInstance(instance) {
	const prev = currentRenderingInstance;
	currentRenderingInstance = instance;
	currentScopeId = instance && instance.type.__scopeId || null;
	return prev;
}
function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
	if (!ctx) return fn;
	if (fn._n) return fn;
	const renderFnWithContext = (...args) => {
		if (renderFnWithContext._d) setBlockTracking(-1);
		const prevInstance = setCurrentRenderingInstance(ctx);
		const prevStackSize = blockStack.length;
		let res;
		try {
			res = fn(...args);
		} finally {
			for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
			setCurrentRenderingInstance(prevInstance);
			if (renderFnWithContext._d) setBlockTracking(1);
		}
		return res;
	};
	renderFnWithContext._n = true;
	renderFnWithContext._c = true;
	renderFnWithContext._d = true;
	return renderFnWithContext;
}
function withDirectives(vnode, directives) {
	if (currentRenderingInstance === null) return vnode;
	const instance = getComponentPublicInstance(currentRenderingInstance);
	const bindings = vnode.dirs || (vnode.dirs = []);
	for (let i = 0; i < directives.length; i++) {
		let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
		if (dir) {
			if (isFunction$1(dir)) dir = {
				mounted: dir,
				updated: dir
			};
			if (dir.deep) traverse(value);
			bindings.push({
				dir,
				instance,
				value,
				oldValue: void 0,
				arg,
				modifiers
			});
		}
	}
	return vnode;
}
function invokeDirectiveHook(vnode, prevVNode, instance, name) {
	const bindings = vnode.dirs;
	const oldBindings = prevVNode && prevVNode.dirs;
	for (let i = 0; i < bindings.length; i++) {
		const binding = bindings[i];
		if (oldBindings) binding.oldValue = oldBindings[i].value;
		let hook = binding.dir[name];
		if (hook) {
			pauseTracking();
			callWithAsyncErrorHandling(hook, instance, 8, [
				vnode.el,
				binding,
				vnode,
				prevVNode
			]);
			resetTracking();
		}
	}
}
function provide(key, value) {
	if (currentInstance) {
		let provides = currentInstance.provides;
		const parentProvides = currentInstance.parent && currentInstance.parent.provides;
		if (parentProvides === provides) provides = currentInstance.provides = Object.create(parentProvides);
		provides[key] = value;
	}
}
function inject(key, defaultValue, treatDefaultAsFactory = false) {
	const instance = getCurrentInstance();
	if (instance || currentApp) {
		let provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null || instance.ce ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
		if (provides && key in provides) return provides[key];
		else if (arguments.length > 1) return treatDefaultAsFactory && isFunction$1(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
	}
}
var ssrContextKey = /* @__PURE__ */ Symbol.for("v-scx");
var useSSRContext = () => {
	{
		const ctx = inject(ssrContextKey);
		if (!ctx);
		return ctx;
	}
};
function watchEffect(effect, options) {
	return doWatch(effect, null, options);
}
function watch(source, cb, options) {
	return doWatch(source, cb, options);
}
function doWatch(source, cb, options = EMPTY_OBJ) {
	const { immediate, deep, flush, once } = options;
	const baseWatchOptions = extend({}, options);
	const runsImmediately = cb && immediate || !cb && flush !== "post";
	let ssrCleanup;
	if (isInSSRComponentSetup) {
		if (flush === "sync") {
			const ctx = useSSRContext();
			ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
		} else if (!runsImmediately) {
			const watchStopHandle = () => {};
			watchStopHandle.stop = NOOP;
			watchStopHandle.resume = NOOP;
			watchStopHandle.pause = NOOP;
			return watchStopHandle;
		}
	}
	const instance = currentInstance;
	baseWatchOptions.call = (fn, type, args) => callWithAsyncErrorHandling(fn, instance, type, args);
	let isPre = false;
	if (flush === "post") baseWatchOptions.scheduler = (job) => {
		queuePostRenderEffect(job, instance && instance.suspense);
	};
	else if (flush !== "sync") {
		isPre = true;
		baseWatchOptions.scheduler = (job, isFirstRun) => {
			if (isFirstRun) job();
			else queueJob(job);
		};
	}
	baseWatchOptions.augmentJob = (job) => {
		if (cb) job.flags |= 4;
		if (isPre) {
			job.flags |= 2;
			if (instance) {
				job.id = instance.uid;
				job.i = instance;
			}
		}
	};
	const watchHandle = watch$1(source, cb, baseWatchOptions);
	if (isInSSRComponentSetup) {
		if (ssrCleanup) ssrCleanup.push(watchHandle);
		else if (runsImmediately) watchHandle();
	}
	return watchHandle;
}
function instanceWatch(source, value, options) {
	const publicThis = this.proxy;
	const getter = isString$1(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
	let cb;
	if (isFunction$1(value)) cb = value;
	else {
		cb = value.handler;
		options = value;
	}
	const reset = setCurrentInstance(this);
	const res = doWatch(getter, cb.bind(publicThis), options);
	reset();
	return res;
}
function createPathGetter(ctx, path) {
	const segments = path.split(".");
	return () => {
		let cur = ctx;
		for (let i = 0; i < segments.length && cur; i++) cur = cur[segments[i]];
		return cur;
	};
}
var pendingMounts = /* @__PURE__ */ new WeakMap();
var TeleportEndKey = /* @__PURE__ */ Symbol("_vte");
var isTeleport = (type) => type.__isTeleport;
var isTeleportDisabled = (props) => props && (props.disabled || props.disabled === "");
var isTeleportDeferred = (props) => props && (props.defer || props.defer === "");
var isTargetSVG = (target) => typeof SVGElement !== "undefined" && target instanceof SVGElement;
var isTargetMathML = (target) => typeof MathMLElement === "function" && target instanceof MathMLElement;
var resolveTarget = (props, select) => {
	const targetSelector = props && props.to;
	if (isString$1(targetSelector)) if (!select) return null;
	else return select(targetSelector);
	else return targetSelector;
};
var TeleportImpl = {
	name: "Teleport",
	__isTeleport: true,
	process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals) {
		const { mc: mountChildren, pc: patchChildren, pbc: patchBlockChildren, o: { insert, querySelector, createText, createComment, parentNode } } = internals;
		const disabled = isTeleportDisabled(n2.props);
		let { dynamicChildren } = n2;
		const mount = (vnode, container2, anchor2) => {
			if (vnode.shapeFlag & 16) mountChildren(vnode.children, container2, anchor2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		};
		const mountToTarget = (vnode = n2) => {
			const disabled2 = isTeleportDisabled(vnode.props);
			const target = vnode.target = resolveTarget(vnode.props, querySelector);
			const targetAnchor = prepareAnchor(target, vnode, createText, insert);
			if (target) {
				if (namespace !== "svg" && isTargetSVG(target)) namespace = "svg";
				else if (namespace !== "mathml" && isTargetMathML(target)) namespace = "mathml";
				if (parentComponent && parentComponent.isCE) (parentComponent.ce._teleportTargets || (parentComponent.ce._teleportTargets = /* @__PURE__ */ new Set())).add(target);
				if (!disabled2) {
					mount(vnode, target, targetAnchor);
					updateCssVars(vnode, false);
				}
			}
		};
		const queuePendingMount = (vnode) => {
			const mountJob = () => {
				if (pendingMounts.get(vnode) !== mountJob) return;
				pendingMounts.delete(vnode);
				if (isTeleportDisabled(vnode.props)) {
					const mountContainer = parentNode(vnode.el) || container;
					mount(vnode, mountContainer, vnode.anchor);
					updateCssVars(vnode, true);
				}
				mountToTarget(vnode);
			};
			pendingMounts.set(vnode, mountJob);
			queuePostRenderEffect(mountJob, parentSuspense);
		};
		if (n1 == null) {
			const placeholder = n2.el = createText("");
			const mainAnchor = n2.anchor = createText("");
			insert(placeholder, container, anchor);
			insert(mainAnchor, container, anchor);
			if (isTeleportDeferred(n2.props) || parentSuspense && parentSuspense.pendingBranch) {
				queuePendingMount(n2);
				return;
			}
			if (disabled) {
				mount(n2, container, mainAnchor);
				updateCssVars(n2, true);
			}
			mountToTarget();
		} else {
			n2.el = n1.el;
			const mainAnchor = n2.anchor = n1.anchor;
			const pendingMount = pendingMounts.get(n1);
			if (pendingMount) {
				pendingMount.flags |= 8;
				pendingMounts.delete(n1);
				queuePendingMount(n2);
				return;
			}
			n2.targetStart = n1.targetStart;
			const target = n2.target = n1.target;
			const targetAnchor = n2.targetAnchor = n1.targetAnchor;
			const wasDisabled = isTeleportDisabled(n1.props);
			const currentContainer = wasDisabled ? container : target;
			const currentAnchor = wasDisabled ? mainAnchor : targetAnchor;
			if (namespace === "svg" || isTargetSVG(target)) namespace = "svg";
			else if (namespace === "mathml" || isTargetMathML(target)) namespace = "mathml";
			if (dynamicChildren) {
				patchBlockChildren(n1.dynamicChildren, dynamicChildren, currentContainer, parentComponent, parentSuspense, namespace, slotScopeIds);
				traverseStaticChildren(n1, n2, true);
			} else if (!optimized) patchChildren(n1, n2, currentContainer, currentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, false);
			if (disabled) {
				if (!wasDisabled) moveTeleport(n2, container, mainAnchor, internals, 1);
				else if (n2.props && n1.props && n2.props.to !== n1.props.to) n2.props.to = n1.props.to;
			} else if ((n2.props && n2.props.to) !== (n1.props && n1.props.to)) {
				const nextTarget = resolveTarget(n2.props, querySelector);
				if (nextTarget) {
					n2.target = nextTarget;
					moveTeleport(n2, nextTarget, null, internals, 0);
				}
			} else if (wasDisabled) moveTeleport(n2, target, targetAnchor, internals, 1);
			updateCssVars(n2, disabled);
		}
	},
	remove(vnode, parentComponent, parentSuspense, { um: unmount, o: { remove: hostRemove } }, doRemove) {
		const { shapeFlag, children, anchor, targetStart, targetAnchor, target, props } = vnode;
		const disabled = isTeleportDisabled(props);
		const shouldRemove = doRemove || !disabled;
		const pendingMount = pendingMounts.get(vnode);
		if (pendingMount) {
			pendingMount.flags |= 8;
			pendingMounts.delete(vnode);
		}
		if (target) {
			hostRemove(targetStart);
			hostRemove(targetAnchor);
		}
		doRemove && hostRemove(anchor);
		if (!pendingMount && (disabled || target) && shapeFlag & 16) for (let i = 0; i < children.length; i++) {
			const child = children[i];
			unmount(child, parentComponent, parentSuspense, shouldRemove, !!child.dynamicChildren);
		}
	},
	move: moveTeleport,
	hydrate: hydrateTeleport
};
function moveTeleport(vnode, container, parentAnchor, { o: { insert }, m: move }, moveType = 2) {
	if (moveType === 0) insert(vnode.targetAnchor, container, parentAnchor);
	const { el, anchor, shapeFlag, children, props } = vnode;
	const isReorder = moveType === 2;
	if (isReorder) insert(el, container, parentAnchor);
	if (!pendingMounts.has(vnode) && (!isReorder || isTeleportDisabled(props))) {
		if (shapeFlag & 16) for (let i = 0; i < children.length; i++) move(children[i], container, parentAnchor, 2);
	}
	if (isReorder) insert(anchor, container, parentAnchor);
}
function hydrateTeleport(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, { o: { nextSibling, parentNode, querySelector, insert, createText } }, hydrateChildren) {
	function hydrateAnchor(target2, targetNode) {
		let targetAnchor = targetNode;
		while (targetAnchor) {
			if (targetAnchor && targetAnchor.nodeType === 8) {
				if (targetAnchor.data === "teleport start anchor") vnode.targetStart = targetAnchor;
				else if (targetAnchor.data === "teleport anchor") {
					vnode.targetAnchor = targetAnchor;
					target2._lpa = vnode.targetAnchor && nextSibling(vnode.targetAnchor);
					break;
				}
			}
			targetAnchor = nextSibling(targetAnchor);
		}
	}
	function hydrateDisabledTeleport(node2, vnode2) {
		vnode2.anchor = hydrateChildren(nextSibling(node2), vnode2, parentNode(node2), parentComponent, parentSuspense, slotScopeIds, optimized);
	}
	const target = vnode.target = resolveTarget(vnode.props, querySelector);
	const disabled = isTeleportDisabled(vnode.props);
	if (target) {
		const targetNode = target._lpa || target.firstChild;
		if (vnode.shapeFlag & 16) if (disabled) {
			hydrateDisabledTeleport(node, vnode);
			hydrateAnchor(target, targetNode);
			if (!vnode.targetAnchor) prepareAnchor(target, vnode, createText, insert, parentNode(node) === target ? node : null);
		} else {
			vnode.anchor = nextSibling(node);
			hydrateAnchor(target, targetNode);
			if (!vnode.targetAnchor) prepareAnchor(target, vnode, createText, insert);
			hydrateChildren(targetNode && nextSibling(targetNode), vnode, target, parentComponent, parentSuspense, slotScopeIds, optimized);
		}
		updateCssVars(vnode, disabled);
	} else if (disabled) {
		if (vnode.shapeFlag & 16) {
			hydrateDisabledTeleport(node, vnode);
			vnode.targetStart = node;
			vnode.targetAnchor = nextSibling(node);
		}
	}
	return vnode.anchor && nextSibling(vnode.anchor);
}
var Teleport = TeleportImpl;
function updateCssVars(vnode, isDisabled) {
	const ctx = vnode.ctx;
	if (ctx && ctx.ut) {
		let node, anchor;
		if (isDisabled) {
			node = vnode.el;
			anchor = vnode.anchor;
		} else {
			node = vnode.targetStart;
			anchor = vnode.targetAnchor;
		}
		while (node && node !== anchor) {
			if (node.nodeType === 1) node.setAttribute("data-v-owner", ctx.uid);
			node = node.nextSibling;
		}
		ctx.ut();
	}
}
function prepareAnchor(target, vnode, createText, insert, anchor = null) {
	const targetStart = vnode.targetStart = createText("");
	const targetAnchor = vnode.targetAnchor = createText("");
	targetStart[TeleportEndKey] = targetAnchor;
	if (target) {
		insert(targetStart, target, anchor);
		insert(targetAnchor, target, anchor);
	}
	return targetAnchor;
}
var leaveCbKey = /* @__PURE__ */ Symbol("_leaveCb");
function setTransitionHooks(vnode, hooks) {
	if (vnode.shapeFlag & 6 && vnode.component) {
		vnode.transition = hooks;
		setTransitionHooks(vnode.component.subTree, hooks);
	} else if (vnode.shapeFlag & 128) {
		vnode.ssContent.transition = hooks.clone(vnode.ssContent);
		vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
	} else vnode.transition = hooks;
}
function useId() {
	const i = getCurrentInstance();
	if (i) return (i.appContext.config.idPrefix || "v") + "-" + i.ids[0] + i.ids[1]++;
	return "";
}
function markAsyncBoundary(instance) {
	instance.ids = [
		instance.ids[0] + instance.ids[2]++ + "-",
		0,
		0
	];
}
function isTemplateRefKey(refs, key) {
	let desc;
	return !!((desc = Object.getOwnPropertyDescriptor(refs, key)) && !desc.configurable);
}
var pendingSetRefMap = /* @__PURE__ */ new WeakMap();
function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
	if (isArray(rawRef)) {
		rawRef.forEach((r, i) => setRef(r, oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef), parentSuspense, vnode, isUnmount));
		return;
	}
	if (isAsyncWrapper(vnode) && !isUnmount) {
		if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
		return;
	}
	const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
	const value = isUnmount ? null : refValue;
	const { i: owner, r: ref } = rawRef;
	const oldRef = oldRawRef && oldRawRef.r;
	const refs = owner.refs === EMPTY_OBJ ? owner.refs = {} : owner.refs;
	const setupState = owner.setupState;
	const rawSetupState = /* @__PURE__ */ toRaw(setupState);
	const canSetSetupRef = setupState === EMPTY_OBJ ? NO : (key) => {
		if (isTemplateRefKey(refs, key)) return false;
		return hasOwn(rawSetupState, key);
	};
	const canSetRef = (ref2, key) => {
		if (key && isTemplateRefKey(refs, key)) return false;
		return true;
	};
	if (oldRef != null && oldRef !== ref) {
		invalidatePendingSetRef(oldRawRef);
		if (isString$1(oldRef)) {
			refs[oldRef] = null;
			if (canSetSetupRef(oldRef)) setupState[oldRef] = null;
		} else if (/* @__PURE__ */ isRef(oldRef)) {
			const oldRawRefAtom = oldRawRef;
			if (canSetRef(oldRef, oldRawRefAtom.k)) oldRef.value = null;
			if (oldRawRefAtom.k) refs[oldRawRefAtom.k] = null;
		}
	}
	if (isFunction$1(ref)) callWithErrorHandling(ref, owner, 12, [value, refs]);
	else {
		const _isString = isString$1(ref);
		const _isRef = /* @__PURE__ */ isRef(ref);
		if (_isString || _isRef) {
			const doSet = () => {
				if (rawRef.f) {
					const existing = _isString ? canSetSetupRef(ref) ? setupState[ref] : refs[ref] : canSetRef(ref) || !rawRef.k ? ref.value : refs[rawRef.k];
					if (isUnmount) isArray(existing) && remove(existing, refValue);
					else if (!isArray(existing)) if (_isString) {
						refs[ref] = [refValue];
						if (canSetSetupRef(ref)) setupState[ref] = refs[ref];
					} else {
						const newVal = [refValue];
						if (canSetRef(ref, rawRef.k)) ref.value = newVal;
						if (rawRef.k) refs[rawRef.k] = newVal;
					}
					else if (!existing.includes(refValue)) existing.push(refValue);
				} else if (_isString) {
					refs[ref] = value;
					if (canSetSetupRef(ref)) setupState[ref] = value;
				} else if (_isRef) {
					if (canSetRef(ref, rawRef.k)) ref.value = value;
					if (rawRef.k) refs[rawRef.k] = value;
				}
			};
			if (value) {
				const job = () => {
					doSet();
					pendingSetRefMap.delete(rawRef);
				};
				job.id = -1;
				pendingSetRefMap.set(rawRef, job);
				queuePostRenderEffect(job, parentSuspense);
			} else {
				invalidatePendingSetRef(rawRef);
				doSet();
			}
		}
	}
}
function invalidatePendingSetRef(rawRef) {
	const pendingSetRef = pendingSetRefMap.get(rawRef);
	if (pendingSetRef) {
		pendingSetRef.flags |= 8;
		pendingSetRefMap.delete(rawRef);
	}
}
getGlobalThis().requestIdleCallback;
getGlobalThis().cancelIdleCallback;
var isAsyncWrapper = (i) => !!i.type.__asyncLoader;
var isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
function onActivated(hook, target) {
	registerKeepAliveHook(hook, "a", target);
}
function onDeactivated(hook, target) {
	registerKeepAliveHook(hook, "da", target);
}
function registerKeepAliveHook(hook, type, target = currentInstance) {
	const wrappedHook = hook.__wdc || (hook.__wdc = () => {
		let current = target;
		while (current) {
			if (current.isDeactivated) return;
			current = current.parent;
		}
		return hook();
	});
	injectHook(type, wrappedHook, target);
	if (target) {
		let current = target.parent;
		while (current && current.parent) {
			if (isKeepAlive(current.parent.vnode)) injectToKeepAliveRoot(wrappedHook, type, target, current);
			current = current.parent;
		}
	}
}
function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
	const injected = injectHook(type, hook, keepAliveRoot, true);
	onUnmounted(() => {
		remove(keepAliveRoot[type], injected);
	}, target);
}
function injectHook(type, hook, target = currentInstance, prepend = false) {
	if (target) {
		const hooks = target[type] || (target[type] = []);
		const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
			pauseTracking();
			const reset = setCurrentInstance(target);
			const res = callWithAsyncErrorHandling(hook, target, type, args);
			reset();
			resetTracking();
			return res;
		});
		if (prepend) hooks.unshift(wrappedHook);
		else hooks.push(wrappedHook);
		return wrappedHook;
	}
}
var createHook = (lifecycle) => (hook, target = currentInstance) => {
	if (!isInSSRComponentSetup || lifecycle === "sp") injectHook(lifecycle, (...args) => hook(...args), target);
};
var onBeforeMount = createHook("bm");
var onMounted = createHook("m");
var onBeforeUpdate = createHook("bu");
var onUpdated = createHook("u");
var onBeforeUnmount = createHook("bum");
var onUnmounted = createHook("um");
var onServerPrefetch = createHook("sp");
var onRenderTriggered = createHook("rtg");
var onRenderTracked = createHook("rtc");
function onErrorCaptured(hook, target = currentInstance) {
	injectHook("ec", hook, target);
}
var COMPONENTS = "components";
var DIRECTIVES = "directives";
function resolveComponent(name, maybeSelfReference) {
	return resolveAsset(COMPONENTS, name, true, maybeSelfReference) || name;
}
var NULL_DYNAMIC_COMPONENT = /* @__PURE__ */ Symbol.for("v-ndc");
function resolveDynamicComponent(component) {
	if (isString$1(component)) return resolveAsset(COMPONENTS, component, false) || component;
	else return component || NULL_DYNAMIC_COMPONENT;
}
function resolveDirective(name) {
	return resolveAsset(DIRECTIVES, name);
}
function resolveAsset(type, name, warnMissing = true, maybeSelfReference = false) {
	const instance = currentRenderingInstance || currentInstance;
	if (instance) {
		const Component = instance.type;
		if (type === COMPONENTS) {
			const selfName = getComponentName(Component, false);
			if (selfName && (selfName === name || selfName === camelize(name) || selfName === capitalize(camelize(name)))) return Component;
		}
		const res = resolve(instance[type] || Component[type], name) || resolve(instance.appContext[type], name);
		if (!res && maybeSelfReference) return Component;
		return res;
	}
}
function resolve(registry, name) {
	return registry && (registry[name] || registry[camelize(name)] || registry[capitalize(camelize(name))]);
}
function renderList(source, renderItem, cache, index) {
	let ret;
	const cached = cache && cache[index];
	const sourceIsArray = isArray(source);
	if (sourceIsArray || isString$1(source)) {
		const sourceIsReactiveArray = sourceIsArray && /* @__PURE__ */ isReactive(source);
		let needsWrap = false;
		let isReadonlySource = false;
		if (sourceIsReactiveArray) {
			needsWrap = !/* @__PURE__ */ isShallow(source);
			isReadonlySource = /* @__PURE__ */ isReadonly(source);
			source = shallowReadArray(source);
		}
		ret = new Array(source.length);
		for (let i = 0, l = source.length; i < l; i++) ret[i] = renderItem(needsWrap ? isReadonlySource ? toReadonly(toReactive(source[i])) : toReactive(source[i]) : source[i], i, void 0, cached && cached[i]);
	} else if (typeof source === "number") {
		ret = new Array(source);
		for (let i = 0; i < source; i++) ret[i] = renderItem(i + 1, i, void 0, cached && cached[i]);
	} else if (isObject(source)) if (source[Symbol.iterator]) ret = Array.from(source, (item, i) => renderItem(item, i, void 0, cached && cached[i]));
	else {
		const keys = Object.keys(source);
		ret = new Array(keys.length);
		for (let i = 0, l = keys.length; i < l; i++) {
			const key = keys[i];
			ret[i] = renderItem(source[key], key, i, cached && cached[i]);
		}
	}
	else ret = [];
	if (cache) cache[index] = ret;
	return ret;
}
function renderSlot(slots, name, props = {}, fallback, noSlotted, branchKey) {
	if (currentRenderingInstance.ce || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.ce) {
		const slotProps = branchKey != null && props.key == null ? extend({}, props, { key: branchKey }) : props;
		const hasProps = Object.keys(slotProps).length > 0;
		if (name !== "default") slotProps.name = name;
		return openBlock(), createBlock(Fragment, null, [createVNode("slot", slotProps, fallback && fallback())], hasProps ? -2 : 64);
	}
	let slot = slots[name];
	if (slot && slot._c) slot._d = false;
	const prevStackSize = blockStack.length;
	openBlock();
	let rendered;
	try {
		const validSlotContent = slot && ensureValidVNode(slot(props));
		const slotKey = props.key || branchKey || validSlotContent && validSlotContent.key;
		rendered = createBlock(Fragment, { key: (slotKey && !isSymbol(slotKey) ? slotKey : `_${name}`) + (!validSlotContent && fallback ? "_fb" : "") }, validSlotContent || (fallback ? fallback() : []), validSlotContent && slots._ === 1 ? 64 : -2);
	} catch (err) {
		for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
		throw err;
	} finally {
		if (slot && slot._c) slot._d = true;
	}
	if (!noSlotted && rendered.scopeId) rendered.slotScopeIds = [rendered.scopeId + "-s"];
	return rendered;
}
function ensureValidVNode(vnodes) {
	return vnodes.some((child) => {
		if (!isVNode(child)) return true;
		if (child.type === Comment) return false;
		if (child.type === Fragment && !ensureValidVNode(child.children)) return false;
		return true;
	}) ? vnodes : null;
}
var getPublicInstance = (i) => {
	if (!i) return null;
	if (isStatefulComponent(i)) return getComponentPublicInstance(i);
	return getPublicInstance(i.parent);
};
var publicPropertiesMap = /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
	$: (i) => i,
	$el: (i) => i.vnode.el,
	$data: (i) => i.data,
	$props: (i) => i.props,
	$attrs: (i) => i.attrs,
	$slots: (i) => i.slots,
	$refs: (i) => i.refs,
	$parent: (i) => getPublicInstance(i.parent),
	$root: (i) => getPublicInstance(i.root),
	$host: (i) => i.ce,
	$emit: (i) => i.emit,
	$options: (i) => resolveMergedOptions(i),
	$forceUpdate: (i) => i.f || (i.f = () => {
		queueJob(i.update);
	}),
	$nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
	$watch: (i) => instanceWatch.bind(i)
});
var hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
var PublicInstanceProxyHandlers = {
	get({ _: instance }, key) {
		if (key === "__v_skip") return true;
		const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
		if (key[0] !== "$") {
			const n = accessCache[key];
			if (n !== void 0) switch (n) {
				case 1: return setupState[key];
				case 2: return data[key];
				case 4: return ctx[key];
				case 3: return props[key];
			}
			else if (hasSetupBinding(setupState, key)) {
				accessCache[key] = 1;
				return setupState[key];
			} else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
				accessCache[key] = 2;
				return data[key];
			} else if (hasOwn(props, key)) {
				accessCache[key] = 3;
				return props[key];
			} else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
				accessCache[key] = 4;
				return ctx[key];
			} else if (shouldCacheAccess) accessCache[key] = 0;
		}
		const publicGetter = publicPropertiesMap[key];
		let cssModule, globalProperties;
		if (publicGetter) {
			if (key === "$attrs") track(instance.attrs, "get", "");
			return publicGetter(instance);
		} else if ((cssModule = type.__cssModules) && (cssModule = cssModule[key])) return cssModule;
		else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
			accessCache[key] = 4;
			return ctx[key];
		} else if (globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)) return globalProperties[key];
	},
	set({ _: instance }, key, value) {
		const { data, setupState, ctx } = instance;
		if (hasSetupBinding(setupState, key)) {
			setupState[key] = value;
			return true;
		} else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
			data[key] = value;
			return true;
		} else if (hasOwn(instance.props, key)) return false;
		if (key[0] === "$" && key.slice(1) in instance) return false;
		else ctx[key] = value;
		return true;
	},
	has({ _: { data, setupState, accessCache, ctx, appContext, props, type } }, key) {
		let cssModules;
		return !!(accessCache[key] || data !== EMPTY_OBJ && key[0] !== "$" && hasOwn(data, key) || hasSetupBinding(setupState, key) || hasOwn(props, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key) || (cssModules = type.__cssModules) && cssModules[key]);
	},
	defineProperty(target, key, descriptor) {
		if (descriptor.get != null) target._.accessCache[key] = 0;
		else if (hasOwn(descriptor, "value")) this.set(target, key, descriptor.value, null);
		return Reflect.defineProperty(target, key, descriptor);
	}
};
function useSlots() {
	return getContext("useSlots").slots;
}
function useAttrs() {
	return getContext("useAttrs").attrs;
}
function getContext(calledFunctionName) {
	const i = getCurrentInstance();
	return i.setupContext || (i.setupContext = createSetupContext(i));
}
function normalizePropsOrEmits(props) {
	return isArray(props) ? props.reduce((normalized, p) => (normalized[p] = null, normalized), {}) : props;
}
var shouldCacheAccess = true;
function applyOptions(instance) {
	const options = resolveMergedOptions(instance);
	const publicThis = instance.proxy;
	const ctx = instance.ctx;
	shouldCacheAccess = false;
	if (options.beforeCreate) callHook(options.beforeCreate, instance, "bc");
	const { data: dataOptions, computed: computedOptions, methods, watch: watchOptions, provide: provideOptions, inject: injectOptions, created, beforeMount, mounted, beforeUpdate, updated, activated, deactivated, beforeDestroy, beforeUnmount, destroyed, unmounted, render, renderTracked, renderTriggered, errorCaptured, serverPrefetch, expose, inheritAttrs, components, directives, filters } = options;
	const checkDuplicateProperties = null;
	if (injectOptions) resolveInjections(injectOptions, ctx, checkDuplicateProperties);
	if (methods) for (const key in methods) {
		const methodHandler = methods[key];
		if (isFunction$1(methodHandler)) ctx[key] = methodHandler.bind(publicThis);
	}
	if (dataOptions) {
		const data = dataOptions.call(publicThis, publicThis);
		if (!isObject(data));
		else instance.data = /* @__PURE__ */ reactive(data);
	}
	shouldCacheAccess = true;
	if (computedOptions) for (const key in computedOptions) {
		const opt = computedOptions[key];
		const c = computed({
			get: isFunction$1(opt) ? opt.bind(publicThis, publicThis) : isFunction$1(opt.get) ? opt.get.bind(publicThis, publicThis) : NOOP,
			set: !isFunction$1(opt) && isFunction$1(opt.set) ? opt.set.bind(publicThis) : NOOP
		});
		Object.defineProperty(ctx, key, {
			enumerable: true,
			configurable: true,
			get: () => c.value,
			set: (v) => c.value = v
		});
	}
	if (watchOptions) for (const key in watchOptions) createWatcher(watchOptions[key], ctx, publicThis, key);
	if (provideOptions) {
		const provides = isFunction$1(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
		Reflect.ownKeys(provides).forEach((key) => {
			provide(key, provides[key]);
		});
	}
	if (created) callHook(created, instance, "c");
	function registerLifecycleHook(register, hook) {
		if (isArray(hook)) hook.forEach((_hook) => register(_hook.bind(publicThis)));
		else if (hook) register(hook.bind(publicThis));
	}
	registerLifecycleHook(onBeforeMount, beforeMount);
	registerLifecycleHook(onMounted, mounted);
	registerLifecycleHook(onBeforeUpdate, beforeUpdate);
	registerLifecycleHook(onUpdated, updated);
	registerLifecycleHook(onActivated, activated);
	registerLifecycleHook(onDeactivated, deactivated);
	registerLifecycleHook(onErrorCaptured, errorCaptured);
	registerLifecycleHook(onRenderTracked, renderTracked);
	registerLifecycleHook(onRenderTriggered, renderTriggered);
	registerLifecycleHook(onBeforeUnmount, beforeUnmount);
	registerLifecycleHook(onUnmounted, unmounted);
	registerLifecycleHook(onServerPrefetch, serverPrefetch);
	if (isArray(expose)) {
		if (expose.length) {
			const exposed = instance.exposed || (instance.exposed = {});
			expose.forEach((key) => {
				Object.defineProperty(exposed, key, {
					get: () => publicThis[key],
					set: (val) => publicThis[key] = val,
					enumerable: true
				});
			});
		} else if (!instance.exposed) instance.exposed = {};
	}
	if (render && instance.render === NOOP) instance.render = render;
	if (inheritAttrs != null) instance.inheritAttrs = inheritAttrs;
	if (components) instance.components = components;
	if (directives) instance.directives = directives;
	if (serverPrefetch) markAsyncBoundary(instance);
}
function resolveInjections(injectOptions, ctx, checkDuplicateProperties = NOOP) {
	if (isArray(injectOptions)) injectOptions = normalizeInject(injectOptions);
	for (const key in injectOptions) {
		const opt = injectOptions[key];
		let injected;
		if (isObject(opt)) if ("default" in opt) injected = inject(opt.from || key, opt.default, true);
		else injected = inject(opt.from || key);
		else injected = inject(opt);
		if (/* @__PURE__ */ isRef(injected)) Object.defineProperty(ctx, key, {
			enumerable: true,
			configurable: true,
			get: () => injected.value,
			set: (v) => injected.value = v
		});
		else ctx[key] = injected;
	}
}
function callHook(hook, instance, type) {
	callWithAsyncErrorHandling(isArray(hook) ? hook.map((h) => h.bind(instance.proxy)) : hook.bind(instance.proxy), instance, type);
}
function createWatcher(raw, ctx, publicThis, key) {
	let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
	if (isString$1(raw)) {
		const handler = ctx[raw];
		if (isFunction$1(handler)) watch(getter, handler);
	} else if (isFunction$1(raw)) watch(getter, raw.bind(publicThis));
	else if (isObject(raw)) if (isArray(raw)) raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
	else {
		const handler = isFunction$1(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
		if (isFunction$1(handler)) watch(getter, handler, raw);
	}
}
function resolveMergedOptions(instance) {
	const base = instance.type;
	const { mixins, extends: extendsOptions } = base;
	const { mixins: globalMixins, optionsCache: cache, config: { optionMergeStrategies } } = instance.appContext;
	const cached = cache.get(base);
	let resolved;
	if (cached) resolved = cached;
	else if (!globalMixins.length && !mixins && !extendsOptions) resolved = base;
	else {
		resolved = {};
		if (globalMixins.length) globalMixins.forEach((m) => mergeOptions(resolved, m, optionMergeStrategies, true));
		mergeOptions(resolved, base, optionMergeStrategies);
	}
	if (isObject(base)) cache.set(base, resolved);
	return resolved;
}
function mergeOptions(to, from, strats, asMixin = false) {
	const { mixins, extends: extendsOptions } = from;
	if (extendsOptions) mergeOptions(to, extendsOptions, strats, true);
	if (mixins) mixins.forEach((m) => mergeOptions(to, m, strats, true));
	for (const key in from) if (asMixin && key === "expose");
	else {
		const strat = internalOptionMergeStrats[key] || strats && strats[key];
		to[key] = strat ? strat(to[key], from[key]) : from[key];
	}
	return to;
}
var internalOptionMergeStrats = {
	data: mergeDataFn,
	props: mergeEmitsOrPropsOptions,
	emits: mergeEmitsOrPropsOptions,
	methods: mergeObjectOptions,
	computed: mergeObjectOptions,
	beforeCreate: mergeAsArray,
	created: mergeAsArray,
	beforeMount: mergeAsArray,
	mounted: mergeAsArray,
	beforeUpdate: mergeAsArray,
	updated: mergeAsArray,
	beforeDestroy: mergeAsArray,
	beforeUnmount: mergeAsArray,
	destroyed: mergeAsArray,
	unmounted: mergeAsArray,
	activated: mergeAsArray,
	deactivated: mergeAsArray,
	errorCaptured: mergeAsArray,
	serverPrefetch: mergeAsArray,
	components: mergeObjectOptions,
	directives: mergeObjectOptions,
	watch: mergeWatchOptions,
	provide: mergeDataFn,
	inject: mergeInject
};
function mergeDataFn(to, from) {
	if (!from) return to;
	if (!to) return from;
	return function mergedDataFn() {
		return extend(isFunction$1(to) ? to.call(this, this) : to, isFunction$1(from) ? from.call(this, this) : from);
	};
}
function mergeInject(to, from) {
	return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
}
function normalizeInject(raw) {
	if (isArray(raw)) {
		const res = {};
		for (let i = 0; i < raw.length; i++) res[raw[i]] = raw[i];
		return res;
	}
	return raw;
}
function mergeAsArray(to, from) {
	return to ? [...new Set([].concat(to, from))] : from;
}
function mergeObjectOptions(to, from) {
	return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
}
function mergeEmitsOrPropsOptions(to, from) {
	if (to) {
		if (isArray(to) && isArray(from)) return [.../* @__PURE__ */ new Set([...to, ...from])];
		return extend(/* @__PURE__ */ Object.create(null), normalizePropsOrEmits(to), normalizePropsOrEmits(from != null ? from : {}));
	} else return from;
}
function mergeWatchOptions(to, from) {
	if (!to) return from;
	if (!from) return to;
	const merged = extend(/* @__PURE__ */ Object.create(null), to);
	for (const key in from) merged[key] = mergeAsArray(to[key], from[key]);
	return merged;
}
function createAppContext() {
	return {
		app: null,
		config: {
			isNativeTag: NO,
			performance: false,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
var uid$1 = 0;
function createAppAPI(render, hydrate) {
	return function createApp(rootComponent, rootProps = null) {
		if (!isFunction$1(rootComponent)) rootComponent = extend({}, rootComponent);
		if (rootProps != null && !isObject(rootProps)) rootProps = null;
		const context = createAppContext();
		const installedPlugins = /* @__PURE__ */ new WeakSet();
		const pluginCleanupFns = [];
		let isMounted = false;
		const app = context.app = {
			_uid: uid$1++,
			_component: rootComponent,
			_props: rootProps,
			_container: null,
			_context: context,
			_instance: null,
			version,
			get config() {
				return context.config;
			},
			set config(v) {},
			use(plugin, ...options) {
				if (installedPlugins.has(plugin));
				else if (plugin && isFunction$1(plugin.install)) {
					installedPlugins.add(plugin);
					plugin.install(app, ...options);
				} else if (isFunction$1(plugin)) {
					installedPlugins.add(plugin);
					plugin(app, ...options);
				}
				return app;
			},
			mixin(mixin) {
				if (!context.mixins.includes(mixin)) context.mixins.push(mixin);
				return app;
			},
			component(name, component) {
				if (!component) return context.components[name];
				context.components[name] = component;
				return app;
			},
			directive(name, directive) {
				if (!directive) return context.directives[name];
				context.directives[name] = directive;
				return app;
			},
			mount(rootContainer, isHydrate, namespace) {
				if (!isMounted) {
					const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
					vnode.appContext = context;
					if (namespace === true) namespace = "svg";
					else if (namespace === false) namespace = void 0;
					if (isHydrate && hydrate) hydrate(vnode, rootContainer);
					else render(vnode, rootContainer, namespace);
					isMounted = true;
					app._container = rootContainer;
					rootContainer.__vue_app__ = app;
					return getComponentPublicInstance(vnode.component);
				}
			},
			onUnmount(cleanupFn) {
				pluginCleanupFns.push(cleanupFn);
			},
			unmount() {
				if (isMounted) {
					callWithAsyncErrorHandling(pluginCleanupFns, app._instance, 16);
					render(null, app._container);
					delete app._container.__vue_app__;
				}
			},
			provide(key, value) {
				context.provides[key] = value;
				return app;
			},
			runWithContext(fn) {
				const lastApp = currentApp;
				currentApp = app;
				try {
					return fn();
				} finally {
					currentApp = lastApp;
				}
			}
		};
		return app;
	};
}
var currentApp = null;
var getModelModifiers = (props, modelName) => {
	return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${camelize(modelName)}Modifiers`] || props[`${hyphenate(modelName)}Modifiers`];
};
function emit(instance, event, ...rawArgs) {
	if (instance.isUnmounted) return;
	const props = instance.vnode.props || EMPTY_OBJ;
	let args = rawArgs;
	const isModelListener = event.startsWith("update:");
	const modifiers = isModelListener && getModelModifiers(props, event.slice(7));
	if (modifiers) {
		if (modifiers.trim) args = rawArgs.map((a) => isString$1(a) ? a.trim() : a);
		if (modifiers.number) args = rawArgs.map(looseToNumber);
	}
	let handlerName;
	let handler = props[handlerName = toHandlerKey(event)] || props[handlerName = toHandlerKey(camelize(event))];
	if (!handler && isModelListener) handler = props[handlerName = toHandlerKey(hyphenate(event))];
	if (handler) callWithAsyncErrorHandling(handler, instance, 6, args);
	const onceHandler = props[handlerName + `Once`];
	if (onceHandler) {
		if (!instance.emitted) instance.emitted = {};
		else if (instance.emitted[handlerName]) return;
		instance.emitted[handlerName] = true;
		callWithAsyncErrorHandling(onceHandler, instance, 6, args);
	}
}
var mixinEmitsCache = /* @__PURE__ */ new WeakMap();
function normalizeEmitsOptions(comp, appContext, asMixin = false) {
	const cache = asMixin ? mixinEmitsCache : appContext.emitsCache;
	const cached = cache.get(comp);
	if (cached !== void 0) return cached;
	const raw = comp.emits;
	let normalized = {};
	let hasExtends = false;
	if (!isFunction$1(comp)) {
		const extendEmits = (raw2) => {
			const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
			if (normalizedFromExtend) {
				hasExtends = true;
				extend(normalized, normalizedFromExtend);
			}
		};
		if (!asMixin && appContext.mixins.length) appContext.mixins.forEach(extendEmits);
		if (comp.extends) extendEmits(comp.extends);
		if (comp.mixins) comp.mixins.forEach(extendEmits);
	}
	if (!raw && !hasExtends) {
		if (isObject(comp)) cache.set(comp, null);
		return null;
	}
	if (isArray(raw)) raw.forEach((key) => normalized[key] = null);
	else extend(normalized, raw);
	if (isObject(comp)) cache.set(comp, normalized);
	return normalized;
}
function isEmitListener(options, key) {
	if (!options || !isOn(key)) return false;
	key = key.slice(2);
	key = key === "Once" ? key : key.replace(/Once$/, "");
	return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, hyphenate(key)) || hasOwn(options, key);
}
function renderComponentRoot(instance) {
	const { type: Component, vnode, proxy, withProxy, propsOptions: [propsOptions], slots, attrs, emit, render, renderCache, props, data, setupState, ctx, inheritAttrs } = instance;
	const prev = setCurrentRenderingInstance(instance);
	let result;
	let fallthroughAttrs;
	try {
		if (vnode.shapeFlag & 4) {
			const proxyToUse = withProxy || proxy;
			const thisProxy = proxyToUse;
			result = normalizeVNode(render.call(thisProxy, proxyToUse, renderCache, props, setupState, data, ctx));
			fallthroughAttrs = attrs;
		} else {
			const render2 = Component;
			result = normalizeVNode(render2.length > 1 ? render2(props, {
				attrs,
				slots,
				emit
			}) : render2(props, null));
			fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
		}
	} catch (err) {
		blockStack.length = 0;
		handleError(err, instance, 1);
		result = createVNode(Comment);
	}
	let root = result;
	if (fallthroughAttrs && inheritAttrs !== false) {
		const keys = Object.keys(fallthroughAttrs);
		const { shapeFlag } = root;
		if (keys.length) {
			if (shapeFlag & 7) {
				if (propsOptions && keys.some(isModelListener)) fallthroughAttrs = filterModelListeners(fallthroughAttrs, propsOptions);
				root = cloneVNode(root, fallthroughAttrs, false, true);
			}
		}
	}
	if (vnode.dirs) {
		root = cloneVNode(root, null, false, true);
		root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
	}
	if (vnode.transition) setTransitionHooks(root, vnode.transition);
	result = root;
	setCurrentRenderingInstance(prev);
	return result;
}
function filterSingleRoot(children, recurse = true) {
	let singleRoot;
	for (let i = 0; i < children.length; i++) {
		const child = children[i];
		if (isVNode(child)) {
			if (child.type !== Comment || child.children === "v-if") if (singleRoot) return;
			else singleRoot = child;
		} else return;
	}
	return singleRoot;
}
var getFunctionalFallthrough = (attrs) => {
	let res;
	for (const key in attrs) if (key === "class" || key === "style" || isOn(key)) (res || (res = {}))[key] = attrs[key];
	return res;
};
var filterModelListeners = (attrs, props) => {
	const res = {};
	for (const key in attrs) if (!isModelListener(key) || !(key.slice(9) in props)) res[key] = attrs[key];
	return res;
};
function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
	const { props: prevProps, children: prevChildren, component } = prevVNode;
	const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
	const emits = component.emitsOptions;
	if (nextVNode.dirs || nextVNode.transition) return true;
	if (optimized && patchFlag >= 0) {
		if (patchFlag & 1024) return true;
		if (patchFlag & 16) {
			if (!prevProps) return !!nextProps;
			return hasPropsChanged(prevProps, nextProps, emits);
		} else if (patchFlag & 8) {
			const dynamicProps = nextVNode.dynamicProps;
			for (let i = 0; i < dynamicProps.length; i++) {
				const key = dynamicProps[i];
				if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emits, key)) return true;
			}
		}
	} else {
		if (prevChildren || nextChildren) {
			if (!nextChildren || !nextChildren.$stable) return true;
		}
		if (prevProps === nextProps) return false;
		if (!prevProps) return !!nextProps;
		if (!nextProps) return true;
		return hasPropsChanged(prevProps, nextProps, emits);
	}
	return false;
}
function hasPropsChanged(prevProps, nextProps, emitsOptions) {
	const nextKeys = Object.keys(nextProps);
	if (nextKeys.length !== Object.keys(prevProps).length) return true;
	for (let i = 0; i < nextKeys.length; i++) {
		const key = nextKeys[i];
		if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emitsOptions, key)) return true;
	}
	return false;
}
function hasPropValueChanged(nextProps, prevProps, key) {
	const nextProp = nextProps[key];
	const prevProp = prevProps[key];
	if (key === "style" && isObject(nextProp) && isObject(prevProp)) return !looseEqual(nextProp, prevProp);
	return nextProp !== prevProp;
}
function updateHOCHostEl({ vnode, parent, suspense }, el) {
	while (parent) {
		const root = parent.subTree;
		if (root.suspense && root.suspense.activeBranch === vnode) {
			root.suspense.vnode.el = root.el = el;
			vnode = root;
		}
		if (root === vnode) {
			(vnode = parent.vnode).el = el;
			parent = parent.parent;
		} else break;
	}
	if (suspense && suspense.activeBranch === vnode) suspense.vnode.el = el;
}
var internalObjectProto = {};
var createInternalObject = () => Object.create(internalObjectProto);
var isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;
function initProps(instance, rawProps, isStateful, isSSR = false) {
	const props = {};
	const attrs = createInternalObject();
	instance.propsDefaults = /* @__PURE__ */ Object.create(null);
	setFullProps(instance, rawProps, props, attrs);
	for (const key in instance.propsOptions[0]) if (!(key in props)) props[key] = void 0;
	if (isStateful) instance.props = isSSR ? props : /* @__PURE__ */ shallowReactive(props);
	else if (!instance.type.props) instance.props = attrs;
	else instance.props = props;
	instance.attrs = attrs;
}
function updateProps(instance, rawProps, rawPrevProps, optimized) {
	const { props, attrs, vnode: { patchFlag } } = instance;
	const rawCurrentProps = /* @__PURE__ */ toRaw(props);
	const [options] = instance.propsOptions;
	let hasAttrsChanged = false;
	if ((optimized || patchFlag > 0) && !(patchFlag & 16)) {
		if (patchFlag & 8) {
			const propsToUpdate = instance.vnode.dynamicProps;
			for (let i = 0; i < propsToUpdate.length; i++) {
				let key = propsToUpdate[i];
				if (isEmitListener(instance.emitsOptions, key)) continue;
				const value = rawProps[key];
				if (options) if (hasOwn(attrs, key)) {
					if (value !== attrs[key]) {
						attrs[key] = value;
						hasAttrsChanged = true;
					}
				} else {
					const camelizedKey = camelize(key);
					props[camelizedKey] = resolvePropValue(options, rawCurrentProps, camelizedKey, value, instance, false);
				}
				else if (value !== attrs[key]) {
					attrs[key] = value;
					hasAttrsChanged = true;
				}
			}
		}
	} else {
		if (setFullProps(instance, rawProps, props, attrs)) hasAttrsChanged = true;
		let kebabKey;
		for (const key in rawCurrentProps) if (!rawProps || !hasOwn(rawProps, key) && ((kebabKey = hyphenate(key)) === key || !hasOwn(rawProps, kebabKey))) if (options) {
			if (rawPrevProps && (rawPrevProps[key] !== void 0 || rawPrevProps[kebabKey] !== void 0)) props[key] = resolvePropValue(options, rawCurrentProps, key, void 0, instance, true);
		} else delete props[key];
		if (attrs !== rawCurrentProps) {
			for (const key in attrs) if (!rawProps || !hasOwn(rawProps, key) && true) {
				delete attrs[key];
				hasAttrsChanged = true;
			}
		}
	}
	if (hasAttrsChanged) trigger(instance.attrs, "set", "");
}
function setFullProps(instance, rawProps, props, attrs) {
	const [options, needCastKeys] = instance.propsOptions;
	let hasAttrsChanged = false;
	let rawCastValues;
	if (rawProps) for (let key in rawProps) {
		if (isReservedProp(key)) continue;
		const value = rawProps[key];
		let camelKey;
		if (options && hasOwn(options, camelKey = camelize(key))) if (!needCastKeys || !needCastKeys.includes(camelKey)) props[camelKey] = value;
		else (rawCastValues || (rawCastValues = {}))[camelKey] = value;
		else if (!isEmitListener(instance.emitsOptions, key)) {
			if (!(key in attrs) || value !== attrs[key]) {
				attrs[key] = value;
				hasAttrsChanged = true;
			}
		}
	}
	if (needCastKeys) {
		const rawCurrentProps = /* @__PURE__ */ toRaw(props);
		const castValues = rawCastValues || EMPTY_OBJ;
		for (let i = 0; i < needCastKeys.length; i++) {
			const key = needCastKeys[i];
			props[key] = resolvePropValue(options, rawCurrentProps, key, castValues[key], instance, !hasOwn(castValues, key));
		}
	}
	return hasAttrsChanged;
}
function resolvePropValue(options, props, key, value, instance, isAbsent) {
	const opt = options[key];
	if (opt != null) {
		const hasDefault = hasOwn(opt, "default");
		if (hasDefault && value === void 0) {
			const defaultValue = opt.default;
			if (opt.type !== Function && !opt.skipFactory && isFunction$1(defaultValue)) {
				const { propsDefaults } = instance;
				if (key in propsDefaults) value = propsDefaults[key];
				else {
					const reset = setCurrentInstance(instance);
					value = propsDefaults[key] = defaultValue.call(null, props);
					reset();
				}
			} else value = defaultValue;
			if (instance.ce) instance.ce._setProp(key, value);
		}
		if (opt[0]) {
			if (isAbsent && !hasDefault) value = false;
			else if (opt[1] && (value === "" || value === hyphenate(key))) value = true;
		}
	}
	return value;
}
var mixinPropsCache = /* @__PURE__ */ new WeakMap();
function normalizePropsOptions(comp, appContext, asMixin = false) {
	const cache = asMixin ? mixinPropsCache : appContext.propsCache;
	const cached = cache.get(comp);
	if (cached) return cached;
	const raw = comp.props;
	const normalized = {};
	const needCastKeys = [];
	let hasExtends = false;
	if (!isFunction$1(comp)) {
		const extendProps = (raw2) => {
			hasExtends = true;
			const [props, keys] = normalizePropsOptions(raw2, appContext, true);
			extend(normalized, props);
			if (keys) needCastKeys.push(...keys);
		};
		if (!asMixin && appContext.mixins.length) appContext.mixins.forEach(extendProps);
		if (comp.extends) extendProps(comp.extends);
		if (comp.mixins) comp.mixins.forEach(extendProps);
	}
	if (!raw && !hasExtends) {
		if (isObject(comp)) cache.set(comp, EMPTY_ARR);
		return EMPTY_ARR;
	}
	if (isArray(raw)) for (let i = 0; i < raw.length; i++) {
		const normalizedKey = camelize(raw[i]);
		if (validatePropName(normalizedKey)) normalized[normalizedKey] = EMPTY_OBJ;
	}
	else if (raw) for (const key in raw) {
		const normalizedKey = camelize(key);
		if (validatePropName(normalizedKey)) {
			const opt = raw[key];
			const prop = normalized[normalizedKey] = isArray(opt) || isFunction$1(opt) ? { type: opt } : extend({}, opt);
			const propType = prop.type;
			let shouldCast = false;
			let shouldCastTrue = true;
			if (isArray(propType)) for (let index = 0; index < propType.length; ++index) {
				const type = propType[index];
				const typeName = isFunction$1(type) && type.name;
				if (typeName === "Boolean") {
					shouldCast = true;
					break;
				} else if (typeName === "String") shouldCastTrue = false;
			}
			else shouldCast = isFunction$1(propType) && propType.name === "Boolean";
			prop[0] = shouldCast;
			prop[1] = shouldCastTrue;
			if (shouldCast || hasOwn(prop, "default")) needCastKeys.push(normalizedKey);
		}
	}
	const res = [normalized, needCastKeys];
	if (isObject(comp)) cache.set(comp, res);
	return res;
}
function validatePropName(key) {
	if (key[0] !== "$" && !isReservedProp(key)) return true;
	return false;
}
var isInternalKey = (key) => key === "_" || key === "_ctx" || key === "$stable";
var normalizeSlotValue = (value) => isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
var normalizeSlot = (key, rawSlot, ctx) => {
	if (rawSlot._n) return rawSlot;
	const normalized = withCtx((...args) => {
		return normalizeSlotValue(rawSlot(...args));
	}, ctx);
	normalized._c = false;
	return normalized;
};
var normalizeObjectSlots = (rawSlots, slots, instance) => {
	const ctx = rawSlots._ctx;
	for (const key in rawSlots) {
		if (isInternalKey(key)) continue;
		const value = rawSlots[key];
		if (isFunction$1(value)) slots[key] = normalizeSlot(key, value, ctx);
		else if (value != null) {
			const normalized = normalizeSlotValue(value);
			slots[key] = () => normalized;
		}
	}
};
var normalizeVNodeSlots = (instance, children) => {
	const normalized = normalizeSlotValue(children);
	instance.slots.default = () => normalized;
};
var assignSlots = (slots, children, optimized) => {
	for (const key in children) if (optimized || !isInternalKey(key)) slots[key] = children[key];
};
var initSlots = (instance, children, optimized) => {
	const slots = instance.slots = createInternalObject();
	if (instance.vnode.shapeFlag & 32) {
		const type = children._;
		if (type) {
			assignSlots(slots, children, optimized);
			if (optimized) def(slots, "_", type, true);
		} else normalizeObjectSlots(children, slots);
	} else if (children) normalizeVNodeSlots(instance, children);
};
var updateSlots = (instance, children, optimized) => {
	const { vnode, slots } = instance;
	let needDeletionCheck = true;
	let deletionComparisonTarget = EMPTY_OBJ;
	if (vnode.shapeFlag & 32) {
		const type = children._;
		if (type) if (optimized && type === 1) needDeletionCheck = false;
		else assignSlots(slots, children, optimized);
		else {
			needDeletionCheck = !children.$stable;
			normalizeObjectSlots(children, slots);
		}
		deletionComparisonTarget = children;
	} else if (children) {
		normalizeVNodeSlots(instance, children);
		deletionComparisonTarget = { default: 1 };
	}
	if (needDeletionCheck) {
		for (const key in slots) if (!isInternalKey(key) && deletionComparisonTarget[key] == null) delete slots[key];
	}
};
var queuePostRenderEffect = queueEffectWithSuspense;
function createRenderer(options) {
	return baseCreateRenderer(options);
}
function baseCreateRenderer(options, createHydrationFns) {
	const target = getGlobalThis();
	target.__VUE__ = true;
	const { insert: hostInsert, remove: hostRemove, patchProp: hostPatchProp, createElement: hostCreateElement, createText: hostCreateText, createComment: hostCreateComment, setText: hostSetText, setElementText: hostSetElementText, parentNode: hostParentNode, nextSibling: hostNextSibling, setScopeId: hostSetScopeId = NOOP, insertStaticContent: hostInsertStaticContent } = options;
	const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized = !!n2.dynamicChildren) => {
		if (n1 === n2) return;
		if (n1 && !isSameVNodeType(n1, n2)) {
			anchor = getNextHostNode(n1);
			unmount(n1, parentComponent, parentSuspense, true);
			n1 = null;
		}
		if (n2.patchFlag === -2) {
			optimized = false;
			n2.dynamicChildren = null;
		}
		const { type, ref, shapeFlag } = n2;
		switch (type) {
			case Text:
				processText(n1, n2, container, anchor);
				break;
			case Comment:
				processCommentNode(n1, n2, container, anchor);
				break;
			case Static:
				if (n1 == null) mountStaticNode(n2, container, anchor, namespace);
				break;
			case Fragment:
				processFragment(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				break;
			default: if (shapeFlag & 1) processElement(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			else if (shapeFlag & 6) processComponent(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			else if (shapeFlag & 64) type.process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals);
			else if (shapeFlag & 128) type.process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals);
		}
		if (ref != null && parentComponent) setRef(ref, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
		else if (ref == null && n1 && n1.ref != null) setRef(n1.ref, null, parentSuspense, n1, true);
	};
	const processText = (n1, n2, container, anchor) => {
		if (n1 == null) hostInsert(n2.el = hostCreateText(n2.children), container, anchor);
		else {
			const el = n2.el = n1.el;
			if (n2.children !== n1.children) hostSetText(el, n2.children);
		}
	};
	const processCommentNode = (n1, n2, container, anchor) => {
		if (n1 == null) hostInsert(n2.el = hostCreateComment(n2.children || ""), container, anchor);
		else n2.el = n1.el;
	};
	const mountStaticNode = (n2, container, anchor, namespace) => {
		[n2.el, n2.anchor] = hostInsertStaticContent(n2.children, container, anchor, namespace, n2.el, n2.anchor);
	};
	const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
		let next;
		while (el && el !== anchor) {
			next = hostNextSibling(el);
			hostInsert(el, container, nextSibling);
			el = next;
		}
		hostInsert(anchor, container, nextSibling);
	};
	const removeStaticNode = ({ el, anchor }) => {
		let next;
		while (el && el !== anchor) {
			next = hostNextSibling(el);
			hostRemove(el);
			el = next;
		}
		hostRemove(anchor);
	};
	const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		if (n2.type === "svg") namespace = "svg";
		else if (n2.type === "math") namespace = "mathml";
		if (n1 == null) mountElement(n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		else {
			const customElement = n1.el && n1.el._isVueCE ? n1.el : null;
			try {
				if (customElement) customElement._beginPatch();
				patchElement(n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			} finally {
				if (customElement) customElement._endPatch();
			}
		}
	};
	const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		let el;
		let vnodeHook;
		const { props, shapeFlag, transition, dirs } = vnode;
		el = vnode.el = hostCreateElement(vnode.type, namespace, props && props.is, props);
		if (shapeFlag & 8) hostSetElementText(el, vnode.children);
		else if (shapeFlag & 16) mountChildren(vnode.children, el, null, parentComponent, parentSuspense, resolveChildrenNamespace(vnode, namespace), slotScopeIds, optimized);
		if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "created");
		setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
		if (props) {
			for (const key in props) if (key !== "value" && !isReservedProp(key)) hostPatchProp(el, key, null, props[key], namespace, parentComponent);
			if ("value" in props) hostPatchProp(el, "value", null, props.value, namespace);
			if (vnodeHook = props.onVnodeBeforeMount) invokeVNodeHook(vnodeHook, parentComponent, vnode);
		}
		if (dirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
		const needCallTransitionHooks = needTransition(parentSuspense, transition);
		if (needCallTransitionHooks) transition.beforeEnter(el);
		hostInsert(el, container, anchor);
		if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) queuePostRenderEffect(() => {
			try {
				vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
				needCallTransitionHooks && transition.enter(el);
				dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
			} finally {}
		}, parentSuspense);
	};
	const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
		if (scopeId) hostSetScopeId(el, scopeId);
		if (slotScopeIds) for (let i = 0; i < slotScopeIds.length; i++) hostSetScopeId(el, slotScopeIds[i]);
		if (parentComponent) {
			let subTree = parentComponent.subTree;
			if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
				const parentVNode = parentComponent.vnode;
				setScopeId(el, parentVNode, parentVNode.scopeId, parentVNode.slotScopeIds, parentComponent.parent);
			}
		}
	};
	const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
		for (let i = start; i < children.length; i++) {
			const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
			patch(null, child, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		}
	};
	const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		const el = n2.el = n1.el;
		let { patchFlag, dynamicChildren, dirs } = n2;
		patchFlag |= n1.patchFlag & 16;
		const oldProps = n1.props || EMPTY_OBJ;
		const newProps = n2.props || EMPTY_OBJ;
		let vnodeHook;
		parentComponent && toggleRecurse(parentComponent, false);
		if (vnodeHook = newProps.onVnodeBeforeUpdate) invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
		if (dirs) invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
		parentComponent && toggleRecurse(parentComponent, true);
		if (dynamicChildren && (!n1.dynamicChildren || n1.dynamicChildren.length !== dynamicChildren.length)) {
			patchFlag = 0;
			optimized = false;
			dynamicChildren = null;
		}
		if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) hostSetElementText(el, "");
		if (dynamicChildren) patchBlockChildren(n1.dynamicChildren, dynamicChildren, el, parentComponent, parentSuspense, resolveChildrenNamespace(n2, namespace), slotScopeIds);
		else if (!optimized) patchChildren(n1, n2, el, null, parentComponent, parentSuspense, resolveChildrenNamespace(n2, namespace), slotScopeIds, false);
		if (patchFlag > 0) {
			if (patchFlag & 16) patchProps(el, oldProps, newProps, parentComponent, namespace);
			else {
				if (patchFlag & 2) {
					if (oldProps.class !== newProps.class) hostPatchProp(el, "class", null, newProps.class, namespace);
				}
				if (patchFlag & 4) hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
				if (patchFlag & 8) {
					const propsToUpdate = n2.dynamicProps;
					for (let i = 0; i < propsToUpdate.length; i++) {
						const key = propsToUpdate[i];
						const prev = oldProps[key];
						const next = newProps[key];
						if (next !== prev || key === "value") hostPatchProp(el, key, prev, next, namespace, parentComponent);
					}
				}
			}
			if (patchFlag & 1) {
				if (n1.children !== n2.children) hostSetElementText(el, n2.children);
			}
		} else if (!optimized && dynamicChildren == null) patchProps(el, oldProps, newProps, parentComponent, namespace);
		if ((vnodeHook = newProps.onVnodeUpdated) || dirs) queuePostRenderEffect(() => {
			vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
			dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
		}, parentSuspense);
	};
	const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
		for (let i = 0; i < newChildren.length; i++) {
			const oldVNode = oldChildren[i];
			const newVNode = newChildren[i];
			const container = oldVNode.el && (oldVNode.type === Fragment || !isSameVNodeType(oldVNode, newVNode) || oldVNode.shapeFlag & 198) ? hostParentNode(oldVNode.el) : fallbackContainer;
			patch(oldVNode, newVNode, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, true);
		}
	};
	const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
		if (oldProps !== newProps) {
			if (oldProps !== EMPTY_OBJ) {
				for (const key in oldProps) if (!isReservedProp(key) && !(key in newProps)) hostPatchProp(el, key, oldProps[key], null, namespace, parentComponent);
			}
			for (const key in newProps) {
				if (isReservedProp(key)) continue;
				const next = newProps[key];
				const prev = oldProps[key];
				if (next !== prev && key !== "value") hostPatchProp(el, key, prev, next, namespace, parentComponent);
			}
			if ("value" in newProps) hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
		}
	};
	const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
		const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
		let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
		if (fragmentSlotScopeIds) slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
		if (n1 == null) {
			hostInsert(fragmentStartAnchor, container, anchor);
			hostInsert(fragmentEndAnchor, container, anchor);
			mountChildren(n2.children || [], container, fragmentEndAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		} else if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && n1.dynamicChildren && n1.dynamicChildren.length === dynamicChildren.length) {
			patchBlockChildren(n1.dynamicChildren, dynamicChildren, container, parentComponent, parentSuspense, namespace, slotScopeIds);
			if (n2.key != null || parentComponent && n2 === parentComponent.subTree) traverseStaticChildren(n1, n2, true);
		} else patchChildren(n1, n2, container, fragmentEndAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
	};
	const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		n2.slotScopeIds = slotScopeIds;
		if (n1 == null) if (n2.shapeFlag & 512) parentComponent.ctx.activate(n2, container, anchor, namespace, optimized);
		else mountComponent(n2, container, anchor, parentComponent, parentSuspense, namespace, optimized);
		else updateComponent(n1, n2, optimized);
	};
	const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
		const instance = initialVNode.component = createComponentInstance(initialVNode, parentComponent, parentSuspense);
		if (isKeepAlive(initialVNode)) instance.ctx.renderer = internals;
		setupComponent(instance, false, optimized);
		if (instance.asyncDep) {
			parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized);
			if (!initialVNode.el) {
				const placeholder = instance.subTree = createVNode(Comment);
				processCommentNode(null, placeholder, container, anchor);
				initialVNode.placeholder = placeholder.el;
			}
		} else setupRenderEffect(instance, initialVNode, container, anchor, parentSuspense, namespace, optimized);
	};
	const updateComponent = (n1, n2, optimized) => {
		const instance = n2.component = n1.component;
		if (shouldUpdateComponent(n1, n2, optimized)) if (instance.asyncDep && !instance.asyncResolved) {
			updateComponentPreRender(instance, n2, optimized);
			return;
		} else {
			instance.next = n2;
			instance.update();
		}
		else {
			n2.el = n1.el;
			instance.vnode = n2;
		}
	};
	const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
		const componentUpdateFn = () => {
			if (!instance.isMounted) {
				let vnodeHook;
				const { el, props } = initialVNode;
				const { bm, m, parent, root, type } = instance;
				const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
				toggleRecurse(instance, false);
				if (bm) invokeArrayFns(bm);
				if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) invokeVNodeHook(vnodeHook, parent, initialVNode);
				toggleRecurse(instance, true);
				if (el && hydrateNode) {
					const hydrateSubTree = () => {
						instance.subTree = renderComponentRoot(instance);
						hydrateNode(el, instance.subTree, instance, parentSuspense, null);
					};
					if (isAsyncWrapperVNode && type.__asyncHydrate) type.__asyncHydrate(el, instance, hydrateSubTree);
					else hydrateSubTree();
				} else {
					if (root.ce && root.ce._hasShadowRoot()) root.ce._injectChildStyle(type, instance.parent ? instance.parent.type : void 0);
					const subTree = instance.subTree = renderComponentRoot(instance);
					patch(null, subTree, container, anchor, instance, parentSuspense, namespace);
					initialVNode.el = subTree.el;
				}
				if (m) queuePostRenderEffect(m, parentSuspense);
				if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
					const scopedInitialVNode = initialVNode;
					queuePostRenderEffect(() => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode), parentSuspense);
				}
				if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) instance.a && queuePostRenderEffect(instance.a, parentSuspense);
				instance.isMounted = true;
				initialVNode = container = anchor = null;
			} else {
				let { next, bu, u, parent, vnode } = instance;
				{
					const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
					if (nonHydratedAsyncRoot) {
						if (next) {
							next.el = vnode.el;
							updateComponentPreRender(instance, next, optimized);
						}
						nonHydratedAsyncRoot.asyncDep.then(() => {
							queuePostRenderEffect(() => {
								if (!instance.isUnmounted) update();
							}, parentSuspense);
						});
						return;
					}
				}
				let originNext = next;
				let vnodeHook;
				toggleRecurse(instance, false);
				if (next) {
					next.el = vnode.el;
					updateComponentPreRender(instance, next, optimized);
				} else next = vnode;
				if (bu) invokeArrayFns(bu);
				if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) invokeVNodeHook(vnodeHook, parent, next, vnode);
				toggleRecurse(instance, true);
				const nextTree = renderComponentRoot(instance);
				const prevTree = instance.subTree;
				instance.subTree = nextTree;
				patch(prevTree, nextTree, hostParentNode(prevTree.el), getNextHostNode(prevTree), instance, parentSuspense, namespace);
				next.el = nextTree.el;
				if (originNext === null) updateHOCHostEl(instance, nextTree.el);
				if (u) queuePostRenderEffect(u, parentSuspense);
				if (vnodeHook = next.props && next.props.onVnodeUpdated) queuePostRenderEffect(() => invokeVNodeHook(vnodeHook, parent, next, vnode), parentSuspense);
			}
		};
		instance.scope.on();
		const effect = instance.effect = new ReactiveEffect(componentUpdateFn);
		instance.scope.off();
		const update = instance.update = effect.run.bind(effect);
		const job = instance.job = effect.runIfDirty.bind(effect);
		job.i = instance;
		job.id = instance.uid;
		effect.scheduler = () => queueJob(job);
		toggleRecurse(instance, true);
		update();
	};
	const updateComponentPreRender = (instance, nextVNode, optimized) => {
		nextVNode.component = instance;
		const prevProps = instance.vnode.props;
		instance.vnode = nextVNode;
		instance.next = null;
		updateProps(instance, nextVNode.props, prevProps, optimized);
		updateSlots(instance, nextVNode.children, optimized);
		pauseTracking();
		flushPreFlushCbs(instance);
		resetTracking();
	};
	const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
		const c1 = n1 && n1.children;
		const prevShapeFlag = n1 ? n1.shapeFlag : 0;
		const c2 = n2.children;
		const { patchFlag, shapeFlag } = n2;
		if (patchFlag > 0) {
			if (patchFlag & 128) {
				patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				return;
			} else if (patchFlag & 256) {
				patchUnkeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				return;
			}
		}
		if (shapeFlag & 8) {
			if (prevShapeFlag & 16) unmountChildren(c1, parentComponent, parentSuspense);
			if (c2 !== c1) hostSetElementText(container, c2);
		} else if (prevShapeFlag & 16) if (shapeFlag & 16) patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		else unmountChildren(c1, parentComponent, parentSuspense, true);
		else {
			if (prevShapeFlag & 8) hostSetElementText(container, "");
			if (shapeFlag & 16) mountChildren(c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		}
	};
	const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		c1 = c1 || EMPTY_ARR;
		c2 = c2 || EMPTY_ARR;
		const oldLength = c1.length;
		const newLength = c2.length;
		const commonLength = Math.min(oldLength, newLength);
		let i;
		for (i = 0; i < commonLength; i++) {
			const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
			patch(c1[i], nextChild, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		}
		if (oldLength > newLength) unmountChildren(c1, parentComponent, parentSuspense, true, false, commonLength);
		else mountChildren(c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, commonLength);
	};
	const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		let i = 0;
		const l2 = c2.length;
		let e1 = c1.length - 1;
		let e2 = l2 - 1;
		while (i <= e1 && i <= e2) {
			const n1 = c1[i];
			const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
			if (isSameVNodeType(n1, n2)) patch(n1, n2, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			else break;
			i++;
		}
		while (i <= e1 && i <= e2) {
			const n1 = c1[e1];
			const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
			if (isSameVNodeType(n1, n2)) patch(n1, n2, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			else break;
			e1--;
			e2--;
		}
		if (i > e1) {
			if (i <= e2) {
				const nextPos = e2 + 1;
				const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
				while (i <= e2) {
					patch(null, c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]), container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					i++;
				}
			}
		} else if (i > e2) while (i <= e1) {
			unmount(c1[i], parentComponent, parentSuspense, true);
			i++;
		}
		else {
			const s1 = i;
			const s2 = i;
			const keyToNewIndexMap = /* @__PURE__ */ new Map();
			for (i = s2; i <= e2; i++) {
				const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
				if (nextChild.key != null) keyToNewIndexMap.set(nextChild.key, i);
			}
			let j;
			let patched = 0;
			const toBePatched = e2 - s2 + 1;
			let moved = false;
			let maxNewIndexSoFar = 0;
			const newIndexToOldIndexMap = new Array(toBePatched);
			for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
			for (i = s1; i <= e1; i++) {
				const prevChild = c1[i];
				if (patched >= toBePatched) {
					unmount(prevChild, parentComponent, parentSuspense, true);
					continue;
				}
				let newIndex;
				if (prevChild.key != null) newIndex = keyToNewIndexMap.get(prevChild.key);
				else for (j = s2; j <= e2; j++) if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
					newIndex = j;
					break;
				}
				if (newIndex === void 0) unmount(prevChild, parentComponent, parentSuspense, true);
				else {
					newIndexToOldIndexMap[newIndex - s2] = i + 1;
					if (newIndex >= maxNewIndexSoFar) maxNewIndexSoFar = newIndex;
					else moved = true;
					patch(prevChild, c2[newIndex], container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					patched++;
				}
			}
			const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
			j = increasingNewIndexSequence.length - 1;
			for (i = toBePatched - 1; i >= 0; i--) {
				const nextIndex = s2 + i;
				const nextChild = c2[nextIndex];
				const anchorVNode = c2[nextIndex + 1];
				const anchor = nextIndex + 1 < l2 ? anchorVNode.el || resolveAsyncComponentPlaceholder(anchorVNode) : parentAnchor;
				if (newIndexToOldIndexMap[i] === 0) patch(null, nextChild, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				else if (moved) if (j < 0 || i !== increasingNewIndexSequence[j]) move(nextChild, container, anchor, 2);
				else j--;
			}
		}
	};
	const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
		const { el, type, transition, children, shapeFlag } = vnode;
		if (shapeFlag & 6) {
			move(vnode.component.subTree, container, anchor, moveType);
			return;
		}
		if (shapeFlag & 128) {
			vnode.suspense.move(container, anchor, moveType);
			return;
		}
		if (shapeFlag & 64) {
			type.move(vnode, container, anchor, internals);
			return;
		}
		if (type === Fragment) {
			hostInsert(el, container, anchor);
			for (let i = 0; i < children.length; i++) move(children[i], container, anchor, moveType);
			hostInsert(vnode.anchor, container, anchor);
			return;
		}
		if (type === Static) {
			moveStaticNode(vnode, container, anchor);
			return;
		}
		if (moveType !== 2 && shapeFlag & 1 && transition) if (moveType === 0) if (transition.persisted && !el[leaveCbKey]) hostInsert(el, container, anchor);
		else {
			transition.beforeEnter(el);
			hostInsert(el, container, anchor);
			queuePostRenderEffect(() => transition.enter(el), parentSuspense);
		}
		else {
			const { leave, delayLeave, afterLeave } = transition;
			const remove2 = () => {
				if (vnode.ctx.isUnmounted) hostRemove(el);
				else hostInsert(el, container, anchor);
			};
			const performLeave = () => {
				const wasLeaving = el._isLeaving || !!el[leaveCbKey];
				if (el._isLeaving) el[leaveCbKey](true);
				if (transition.persisted && !wasLeaving) remove2();
				else leave(el, () => {
					remove2();
					afterLeave && afterLeave();
				});
			};
			if (delayLeave) delayLeave(el, remove2, performLeave);
			else performLeave();
		}
		else hostInsert(el, container, anchor);
	};
	const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
		const { type, props, ref, children, dynamicChildren, shapeFlag, patchFlag, dirs, cacheIndex, memo } = vnode;
		if (patchFlag === -2) optimized = false;
		if (ref != null) {
			pauseTracking();
			setRef(ref, null, parentSuspense, vnode, true);
			resetTracking();
		}
		if (cacheIndex != null) parentComponent.renderCache[cacheIndex] = void 0;
		if (shapeFlag & 256) {
			parentComponent.ctx.deactivate(vnode);
			return;
		}
		const shouldInvokeDirs = shapeFlag & 1 && dirs;
		const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
		let vnodeHook;
		if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) invokeVNodeHook(vnodeHook, parentComponent, vnode);
		if (shapeFlag & 6) unmountComponent(vnode.component, parentSuspense, doRemove);
		else {
			if (shapeFlag & 128) {
				vnode.suspense.unmount(parentSuspense, doRemove);
				return;
			}
			if (shouldInvokeDirs) invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
			if (shapeFlag & 64) vnode.type.remove(vnode, parentComponent, parentSuspense, internals, doRemove);
			else if (dynamicChildren && !dynamicChildren.hasOnce && (type !== Fragment || patchFlag > 0 && patchFlag & 64)) unmountChildren(dynamicChildren, parentComponent, parentSuspense, false, true);
			else if (type === Fragment && patchFlag & 384 || !optimized && shapeFlag & 16) unmountChildren(children, parentComponent, parentSuspense);
			if (doRemove) remove(vnode);
		}
		const shouldInvalidateMemo = memo != null && cacheIndex == null;
		if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs || shouldInvalidateMemo) queuePostRenderEffect(() => {
			vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
			shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
			if (shouldInvalidateMemo) vnode.el = null;
		}, parentSuspense);
	};
	const remove = (vnode) => {
		const { type, el, anchor, transition } = vnode;
		if (type === Fragment) {
			removeFragment(el, anchor);
			return;
		}
		if (type === Static) {
			removeStaticNode(vnode);
			return;
		}
		const performRemove = () => {
			hostRemove(el);
			if (transition && !transition.persisted && transition.afterLeave) transition.afterLeave();
		};
		if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
			const { leave, delayLeave } = transition;
			const performLeave = () => leave(el, performRemove);
			if (delayLeave) delayLeave(vnode.el, performRemove, performLeave);
			else performLeave();
		} else performRemove();
	};
	const removeFragment = (cur, end) => {
		let next;
		while (cur !== end) {
			next = hostNextSibling(cur);
			hostRemove(cur);
			cur = next;
		}
		hostRemove(end);
	};
	const unmountComponent = (instance, parentSuspense, doRemove) => {
		const { bum, scope, job, subTree, um, m, a } = instance;
		invalidateMount(m);
		invalidateMount(a);
		if (bum) invokeArrayFns(bum);
		scope.stop();
		if (job) {
			job.flags |= 8;
			unmount(subTree, instance, parentSuspense, doRemove);
		}
		if (um) queuePostRenderEffect(um, parentSuspense);
		queuePostRenderEffect(() => {
			instance.isUnmounted = true;
		}, parentSuspense);
	};
	const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
		for (let i = start; i < children.length; i++) unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
	};
	const getNextHostNode = (vnode) => {
		if (vnode.shapeFlag & 6) return getNextHostNode(vnode.component.subTree);
		if (vnode.shapeFlag & 128) return vnode.suspense.next();
		const el = hostNextSibling(vnode.anchor || vnode.el);
		const teleportEnd = el && el[TeleportEndKey];
		return teleportEnd ? hostNextSibling(teleportEnd) : el;
	};
	let isFlushing = false;
	const render = (vnode, container, namespace) => {
		let instance;
		if (vnode == null) {
			if (container._vnode) {
				unmount(container._vnode, null, null, true);
				instance = container._vnode.component;
			}
		} else patch(container._vnode || null, vnode, container, null, null, null, namespace);
		container._vnode = vnode;
		if (!isFlushing) {
			isFlushing = true;
			flushPreFlushCbs(instance);
			flushPostFlushCbs();
			isFlushing = false;
		}
	};
	const internals = {
		p: patch,
		um: unmount,
		m: move,
		r: remove,
		mt: mountComponent,
		mc: mountChildren,
		pc: patchChildren,
		pbc: patchBlockChildren,
		n: getNextHostNode,
		o: options
	};
	let hydrate;
	let hydrateNode;
	if (createHydrationFns) [hydrate, hydrateNode] = createHydrationFns(internals);
	return {
		render,
		hydrate,
		createApp: createAppAPI(render, hydrate)
	};
}
function resolveChildrenNamespace({ type, props }, currentNamespace) {
	return currentNamespace === "svg" && type === "foreignObject" || currentNamespace === "mathml" && type === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
}
function toggleRecurse({ effect, job }, allowed) {
	if (allowed) {
		effect.flags |= 32;
		job.flags |= 4;
	} else {
		effect.flags &= -33;
		job.flags &= -5;
	}
}
function needTransition(parentSuspense, transition) {
	return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
}
function traverseStaticChildren(n1, n2, shallow = false) {
	const ch1 = n1.children;
	const ch2 = n2.children;
	if (isArray(ch1) && isArray(ch2)) for (let i = 0; i < ch1.length; i++) {
		const c1 = ch1[i];
		let c2 = ch2[i];
		if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
			if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
				c2 = ch2[i] = cloneIfMounted(ch2[i]);
				c2.el = c1.el;
			}
			if (!shallow && c2.patchFlag !== -2) traverseStaticChildren(c1, c2);
		}
		if (c2.type === Text) {
			if (c2.patchFlag === -1) c2 = ch2[i] = cloneIfMounted(c2);
			c2.el = c1.el;
		}
		if (c2.type === Comment && !c2.el) c2.el = c1.el;
	}
}
function getSequence(arr) {
	const p = arr.slice();
	const result = [0];
	let i, j, u, v, c;
	const len = arr.length;
	for (i = 0; i < len; i++) {
		const arrI = arr[i];
		if (arrI !== 0) {
			j = result[result.length - 1];
			if (arr[j] < arrI) {
				p[i] = j;
				result.push(i);
				continue;
			}
			u = 0;
			v = result.length - 1;
			while (u < v) {
				c = u + v >> 1;
				if (arr[result[c]] < arrI) u = c + 1;
				else v = c;
			}
			if (arrI < arr[result[u]]) {
				if (u > 0) p[i] = result[u - 1];
				result[u] = i;
			}
		}
	}
	u = result.length;
	v = result[u - 1];
	while (u-- > 0) {
		result[u] = v;
		v = p[v];
	}
	return result;
}
function locateNonHydratedAsyncRoot(instance) {
	const subComponent = instance.subTree.component;
	if (subComponent) if (subComponent.asyncDep && !subComponent.asyncResolved) return subComponent;
	else return locateNonHydratedAsyncRoot(subComponent);
}
function invalidateMount(hooks) {
	if (hooks) for (let i = 0; i < hooks.length; i++) hooks[i].flags |= 8;
}
function resolveAsyncComponentPlaceholder(anchorVnode) {
	if (anchorVnode.placeholder) return anchorVnode.placeholder;
	const instance = anchorVnode.component;
	if (instance) return resolveAsyncComponentPlaceholder(instance.subTree);
	return null;
}
var isSuspense = (type) => type.__isSuspense;
var suspenseId = 0;
var Suspense = {
	name: "Suspense",
	__isSuspense: true,
	process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
		if (n1 == null) mountSuspense(n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals);
		else {
			if (parentSuspense && parentSuspense.deps > 0 && !n1.suspense.isInFallback) {
				n2.suspense = n1.suspense;
				n2.suspense.vnode = n2;
				n2.el = n1.el;
				return;
			}
			patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, rendererInternals);
		}
	},
	hydrate: hydrateSuspense,
	normalize: normalizeSuspenseChildren
};
function triggerEvent$1(vnode, name) {
	const eventListener = vnode.props && vnode.props[name];
	if (isFunction$1(eventListener)) eventListener();
}
function mountSuspense(vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
	const { p: patch, o: { createElement } } = rendererInternals;
	const hiddenContainer = createElement("div");
	const suspense = vnode.suspense = createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals);
	patch(null, suspense.pendingBranch = vnode.ssContent, hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds);
	if (suspense.deps > 0) {
		triggerEvent$1(vnode, "onPending");
		triggerEvent$1(vnode, "onFallback");
		patch(null, vnode.ssFallback, container, anchor, parentComponent, null, namespace, slotScopeIds);
		setActiveBranch(suspense, vnode.ssFallback);
	} else suspense.resolve(false, true);
}
function patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, { p: patch, um: unmount, o: { createElement } }) {
	const suspense = n2.suspense = n1.suspense;
	suspense.vnode = n2;
	n2.el = n1.el;
	const newBranch = n2.ssContent;
	const newFallback = n2.ssFallback;
	const { activeBranch, pendingBranch, isInFallback, isHydrating } = suspense;
	if (pendingBranch) {
		suspense.pendingBranch = newBranch;
		if (isSameVNodeType(pendingBranch, newBranch)) {
			patch(pendingBranch, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
			if (suspense.deps <= 0) suspense.resolve();
			else if (isInFallback) {
				if (!isHydrating) {
					patch(activeBranch, newFallback, container, anchor, parentComponent, null, namespace, slotScopeIds, optimized);
					setActiveBranch(suspense, newFallback);
				}
			}
		} else {
			suspense.pendingId = suspenseId++;
			if (isHydrating) {
				suspense.isHydrating = false;
				suspense.activeBranch = pendingBranch;
			} else unmount(pendingBranch, parentComponent, suspense);
			suspense.deps = 0;
			suspense.effects.length = 0;
			suspense.hiddenContainer = createElement("div");
			if (isInFallback) {
				patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
				if (suspense.deps <= 0) suspense.resolve();
				else {
					patch(activeBranch, newFallback, container, anchor, parentComponent, null, namespace, slotScopeIds, optimized);
					setActiveBranch(suspense, newFallback);
				}
			} else if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
				patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, namespace, slotScopeIds, optimized);
				suspense.resolve(true);
			} else {
				patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
				if (suspense.deps <= 0) suspense.resolve();
			}
		}
	} else if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
		patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, namespace, slotScopeIds, optimized);
		setActiveBranch(suspense, newBranch);
	} else {
		triggerEvent$1(n2, "onPending");
		suspense.pendingBranch = newBranch;
		if (newBranch.shapeFlag & 512) suspense.pendingId = newBranch.component.suspenseId;
		else suspense.pendingId = suspenseId++;
		patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
		if (suspense.deps <= 0) suspense.resolve();
		else {
			const { timeout, pendingId } = suspense;
			if (timeout > 0) setTimeout(() => {
				if (suspense.pendingId === pendingId) suspense.fallback(newFallback);
			}, timeout);
			else if (timeout === 0) suspense.fallback(newFallback);
		}
	}
}
function createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals, isHydrating = false) {
	const { p: patch, m: move, um: unmount, n: next, o: { parentNode, remove } } = rendererInternals;
	let parentSuspenseId;
	const isSuspensible = isVNodeSuspensible(vnode);
	if (isSuspensible) {
		if (parentSuspense && parentSuspense.pendingBranch) {
			parentSuspenseId = parentSuspense.pendingId;
			parentSuspense.deps++;
		}
	}
	const timeout = vnode.props ? toNumber(vnode.props.timeout) : void 0;
	const initialAnchor = anchor;
	const suspense = {
		vnode,
		parent: parentSuspense,
		parentComponent,
		namespace,
		container,
		hiddenContainer,
		deps: 0,
		pendingId: suspenseId++,
		timeout: typeof timeout === "number" ? timeout : -1,
		activeBranch: null,
		isFallbackMountPending: false,
		pendingBranch: null,
		isInFallback: !isHydrating,
		isHydrating,
		isUnmounted: false,
		effects: [],
		resolve(resume = false, sync = false) {
			const { vnode: vnode2, activeBranch, pendingBranch, pendingId, effects, parentComponent: parentComponent2, container: container2, isInFallback } = suspense;
			let delayEnter = false;
			if (suspense.isHydrating) suspense.isHydrating = false;
			else if (!resume) {
				delayEnter = activeBranch && pendingBranch.transition && pendingBranch.transition.mode === "out-in";
				let hasUpdatedAnchor = false;
				if (delayEnter) activeBranch.transition.afterLeave = () => {
					if (pendingId === suspense.pendingId) {
						move(pendingBranch, container2, anchor === initialAnchor && !hasUpdatedAnchor ? next(activeBranch) : anchor, 0);
						queuePostFlushCb(effects);
						if (isInFallback && vnode2.ssFallback) vnode2.ssFallback.el = null;
					}
				};
				if (activeBranch && !suspense.isFallbackMountPending) {
					if (parentNode(activeBranch.el) === container2) {
						anchor = next(activeBranch);
						hasUpdatedAnchor = true;
					}
					unmount(activeBranch, parentComponent2, suspense, true);
					if (!delayEnter && isInFallback && vnode2.ssFallback) queuePostRenderEffect(() => vnode2.ssFallback.el = null, suspense);
				}
				if (!delayEnter) move(pendingBranch, container2, anchor, 0);
			}
			suspense.isFallbackMountPending = false;
			setActiveBranch(suspense, pendingBranch);
			suspense.pendingBranch = null;
			suspense.isInFallback = false;
			let parent = suspense.parent;
			let hasUnresolvedAncestor = false;
			while (parent) {
				if (parent.pendingBranch) {
					parent.effects.push(...effects);
					hasUnresolvedAncestor = true;
					break;
				}
				parent = parent.parent;
			}
			if (!hasUnresolvedAncestor && !delayEnter) queuePostFlushCb(effects);
			suspense.effects = [];
			if (isSuspensible) {
				if (parentSuspense && parentSuspense.pendingBranch && parentSuspenseId === parentSuspense.pendingId) {
					parentSuspense.deps--;
					if (parentSuspense.deps === 0 && !sync) parentSuspense.resolve();
				}
			}
			triggerEvent$1(vnode2, "onResolve");
		},
		fallback(fallbackVNode) {
			if (!suspense.pendingBranch) return;
			const { vnode: vnode2, activeBranch, parentComponent: parentComponent2, container: container2, namespace: namespace2 } = suspense;
			triggerEvent$1(vnode2, "onFallback");
			const anchor2 = next(activeBranch);
			const mountFallback = () => {
				suspense.isFallbackMountPending = false;
				if (!suspense.isInFallback) return;
				patch(null, fallbackVNode, container2, anchor2, parentComponent2, null, namespace2, slotScopeIds, optimized);
				setActiveBranch(suspense, fallbackVNode);
			};
			const delayEnter = fallbackVNode.transition && fallbackVNode.transition.mode === "out-in";
			if (delayEnter) {
				suspense.isFallbackMountPending = true;
				activeBranch.transition.afterLeave = mountFallback;
			}
			suspense.isInFallback = true;
			unmount(activeBranch, parentComponent2, null, true);
			if (!delayEnter) mountFallback();
		},
		move(container2, anchor2, type) {
			suspense.activeBranch && move(suspense.activeBranch, container2, anchor2, type);
			suspense.container = container2;
		},
		next() {
			return suspense.activeBranch && next(suspense.activeBranch);
		},
		registerDep(instance, setupRenderEffect, optimized2) {
			const isInPendingSuspense = !!suspense.pendingBranch;
			if (isInPendingSuspense) suspense.deps++;
			const hydratedEl = instance.vnode.el;
			instance.asyncDep.catch((err) => {
				handleError(err, instance, 0);
			}).then((asyncSetupResult) => {
				if (instance.isUnmounted || suspense.isUnmounted || suspense.pendingId !== instance.suspenseId) return;
				unsetCurrentInstance();
				instance.asyncResolved = true;
				const { vnode: vnode2 } = instance;
				handleSetupResult(instance, asyncSetupResult, false);
				if (hydratedEl) vnode2.el = hydratedEl;
				const placeholder = !hydratedEl && instance.subTree.el;
				setupRenderEffect(instance, vnode2, parentNode(hydratedEl || instance.subTree.el), hydratedEl ? null : next(instance.subTree), suspense, namespace, optimized2);
				if (placeholder) {
					vnode2.placeholder = null;
					remove(placeholder);
				}
				updateHOCHostEl(instance, vnode2.el);
				if (isInPendingSuspense && --suspense.deps === 0) suspense.resolve();
			});
		},
		unmount(parentSuspense2, doRemove) {
			suspense.isUnmounted = true;
			if (suspense.activeBranch) unmount(suspense.activeBranch, parentComponent, parentSuspense2, doRemove);
			if (suspense.pendingBranch) unmount(suspense.pendingBranch, parentComponent, parentSuspense2, doRemove);
		}
	};
	return suspense;
}
function hydrateSuspense(node, vnode, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals, hydrateNode) {
	const suspense = vnode.suspense = createSuspenseBoundary(vnode, parentSuspense, parentComponent, node.parentNode, document.createElement("div"), null, namespace, slotScopeIds, optimized, rendererInternals, true);
	const result = hydrateNode(node, suspense.pendingBranch = vnode.ssContent, parentComponent, suspense, slotScopeIds, optimized);
	if (suspense.deps === 0) suspense.resolve(false, true);
	return result;
}
function normalizeSuspenseChildren(vnode) {
	const { shapeFlag, children } = vnode;
	const isSlotChildren = shapeFlag & 32;
	vnode.ssContent = normalizeSuspenseSlot(isSlotChildren ? children.default : children);
	vnode.ssFallback = isSlotChildren ? normalizeSuspenseSlot(children.fallback) : createVNode(Comment);
}
function normalizeSuspenseSlot(s) {
	let block;
	if (isFunction$1(s)) {
		const trackBlock = isBlockTreeEnabled && s._c;
		if (trackBlock) {
			s._d = false;
			openBlock();
		}
		s = s();
		if (trackBlock) {
			s._d = true;
			block = currentBlock;
			closeBlock();
		}
	}
	if (isArray(s)) s = filterSingleRoot(s);
	s = normalizeVNode(s);
	if (block && !s.dynamicChildren) s.dynamicChildren = block.filter((c) => c !== s);
	return s;
}
function queueEffectWithSuspense(fn, suspense) {
	if (suspense && suspense.pendingBranch) if (isArray(fn)) suspense.effects.push(...fn);
	else suspense.effects.push(fn);
	else queuePostFlushCb(fn);
}
function setActiveBranch(suspense, branch) {
	suspense.activeBranch = branch;
	const { vnode, parentComponent } = suspense;
	let el = branch.el;
	while (!el && branch.component) {
		branch = branch.component.subTree;
		el = branch.el;
	}
	vnode.el = el;
	if (parentComponent && parentComponent.subTree === vnode) {
		parentComponent.vnode.el = el;
		updateHOCHostEl(parentComponent, el);
	}
}
function isVNodeSuspensible(vnode) {
	const suspensible = vnode.props && vnode.props.suspensible;
	return suspensible != null && suspensible !== false;
}
var Fragment = /* @__PURE__ */ Symbol.for("v-fgt");
var Text = /* @__PURE__ */ Symbol.for("v-txt");
var Comment = /* @__PURE__ */ Symbol.for("v-cmt");
var Static = /* @__PURE__ */ Symbol.for("v-stc");
var blockStack = [];
var currentBlock = null;
function openBlock(disableTracking = false) {
	blockStack.push(currentBlock = disableTracking ? null : []);
}
function closeBlock() {
	blockStack.pop();
	currentBlock = blockStack[blockStack.length - 1] || null;
}
var isBlockTreeEnabled = 1;
function setBlockTracking(value, inVOnce = false) {
	isBlockTreeEnabled += value;
	if (value < 0 && currentBlock && inVOnce) currentBlock.hasOnce = true;
}
function setupBlock(vnode) {
	vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
	closeBlock();
	if (isBlockTreeEnabled > 0 && currentBlock) currentBlock.push(vnode);
	return vnode;
}
function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
	return setupBlock(createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, true));
}
function createBlock(type, props, children, patchFlag, dynamicProps) {
	return setupBlock(createVNode(type, props, children, patchFlag, dynamicProps, true));
}
function isVNode(value) {
	return value ? value.__v_isVNode === true : false;
}
function isSameVNodeType(n1, n2) {
	return n1.type === n2.type && n1.key === n2.key;
}
var normalizeKey = ({ key }) => key != null ? key : null;
var normalizeRef = ({ ref, ref_key, ref_for }) => {
	if (typeof ref === "number") ref = "" + ref;
	return ref != null ? isString$1(ref) || /* @__PURE__ */ isRef(ref) || isFunction$1(ref) ? {
		i: currentRenderingInstance,
		r: ref,
		k: ref_key,
		f: !!ref_for
	} : ref : null;
};
function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
	const vnode = {
		__v_isVNode: true,
		__v_skip: true,
		type,
		props,
		key: props && normalizeKey(props),
		ref: props && normalizeRef(props),
		scopeId: currentScopeId,
		slotScopeIds: null,
		children,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag,
		patchFlag,
		dynamicProps,
		dynamicChildren: null,
		appContext: null,
		ctx: currentRenderingInstance
	};
	if (needFullChildrenNormalization) {
		normalizeChildren(vnode, children);
		if (shapeFlag & 128) type.normalize(vnode);
	} else if (children) vnode.shapeFlag |= isString$1(children) ? 8 : 16;
	if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock && (vnode.patchFlag > 0 || shapeFlag & 6) && vnode.patchFlag !== 32) currentBlock.push(vnode);
	return vnode;
}
var createVNode = _createVNode;
function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
	if (!type || type === NULL_DYNAMIC_COMPONENT) type = Comment;
	if (isVNode(type)) {
		const cloned = cloneVNode(type, props, true);
		if (children) normalizeChildren(cloned, children);
		if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) if (cloned.shapeFlag & 6) currentBlock[currentBlock.indexOf(type)] = cloned;
		else currentBlock.push(cloned);
		cloned.patchFlag = -2;
		return cloned;
	}
	if (isClassComponent(type)) type = type.__vccOpts;
	if (props) {
		props = guardReactiveProps(props);
		let { class: klass, style } = props;
		if (klass && !isString$1(klass)) props.class = normalizeClass(klass);
		if (isObject(style)) {
			if (/* @__PURE__ */ isProxy(style) && !isArray(style)) style = extend({}, style);
			props.style = normalizeStyle(style);
		}
	}
	const shapeFlag = isString$1(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : isObject(type) ? 4 : isFunction$1(type) ? 2 : 0;
	return createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, isBlockNode, true);
}
function guardReactiveProps(props) {
	if (!props) return null;
	return /* @__PURE__ */ isProxy(props) || isInternalObject(props) ? extend({}, props) : props;
}
function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
	const { props, ref, patchFlag, children, transition } = vnode;
	const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
	const cloned = {
		__v_isVNode: true,
		__v_skip: true,
		type: vnode.type,
		props: mergedProps,
		key: mergedProps && normalizeKey(mergedProps),
		ref: extraProps && extraProps.ref ? mergeRef && ref ? isArray(ref) ? ref.concat(normalizeRef(extraProps)) : [ref, normalizeRef(extraProps)] : normalizeRef(extraProps) : ref,
		scopeId: vnode.scopeId,
		slotScopeIds: vnode.slotScopeIds,
		children,
		target: vnode.target,
		targetStart: vnode.targetStart,
		targetAnchor: vnode.targetAnchor,
		staticCount: vnode.staticCount,
		shapeFlag: vnode.shapeFlag,
		patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
		dynamicProps: vnode.dynamicProps,
		dynamicChildren: vnode.dynamicChildren,
		appContext: vnode.appContext,
		dirs: vnode.dirs,
		transition,
		component: vnode.component,
		suspense: vnode.suspense,
		ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
		ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
		placeholder: vnode.placeholder,
		el: vnode.el,
		anchor: vnode.anchor,
		ctx: vnode.ctx,
		ce: vnode.ce
	};
	if (transition && cloneTransition) setTransitionHooks(cloned, transition.clone(cloned));
	return cloned;
}
function createTextVNode(text = " ", flag = 0) {
	return createVNode(Text, null, text, flag);
}
function createCommentVNode(text = "", asBlock = false) {
	return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
}
function normalizeVNode(child) {
	if (child == null || typeof child === "boolean") return createVNode(Comment);
	else if (isArray(child)) return createVNode(Fragment, null, child.slice());
	else if (isVNode(child)) return cloneIfMounted(child);
	else return createVNode(Text, null, String(child));
}
function cloneIfMounted(child) {
	return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
}
function normalizeChildren(vnode, children) {
	let type = 0;
	const { shapeFlag } = vnode;
	if (children == null) children = null;
	else if (isArray(children)) type = 16;
	else if (typeof children === "object") if (shapeFlag & 65) {
		const slot = children.default;
		if (slot) {
			slot._c && (slot._d = false);
			normalizeChildren(vnode, slot());
			slot._c && (slot._d = true);
		}
		return;
	} else {
		type = 32;
		const slotFlag = children._;
		if (!slotFlag && !isInternalObject(children)) children._ctx = currentRenderingInstance;
		else if (slotFlag === 3 && currentRenderingInstance) if (currentRenderingInstance.slots._ === 1) children._ = 1;
		else {
			children._ = 2;
			vnode.patchFlag |= 1024;
		}
	}
	else if (isFunction$1(children)) {
		if (shapeFlag & 65) {
			normalizeChildren(vnode, { default: children });
			return;
		}
		children = {
			default: children,
			_ctx: currentRenderingInstance
		};
		type = 32;
	} else {
		children = String(children);
		if (shapeFlag & 64) {
			type = 16;
			children = [createTextVNode(children)];
		} else type = 8;
	}
	vnode.children = children;
	vnode.shapeFlag |= type;
}
function mergeProps(...args) {
	const ret = {};
	for (let i = 0; i < args.length; i++) {
		const toMerge = args[i];
		for (const key in toMerge) if (key === "class") {
			if (ret.class !== toMerge.class) ret.class = normalizeClass([ret.class, toMerge.class]);
		} else if (key === "style") ret.style = normalizeStyle([ret.style, toMerge.style]);
		else if (isOn(key)) {
			const existing = ret[key];
			const incoming = toMerge[key];
			if (incoming && existing !== incoming && !(isArray(existing) && existing.includes(incoming))) ret[key] = existing ? [].concat(existing, incoming) : incoming;
			else if (incoming == null && existing == null && !isModelListener(key)) ret[key] = incoming;
		} else if (key !== "") ret[key] = toMerge[key];
	}
	return ret;
}
function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
	callWithAsyncErrorHandling(hook, instance, 7, [vnode, prevVNode]);
}
var emptyAppContext = createAppContext();
var uid = 0;
function createComponentInstance(vnode, parent, suspense) {
	const type = vnode.type;
	const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
	const instance = {
		uid: uid++,
		vnode,
		type,
		parent,
		appContext,
		root: null,
		next: null,
		subTree: null,
		effect: null,
		update: null,
		job: null,
		scope: new EffectScope(true),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: parent ? parent.provides : Object.create(appContext.provides),
		ids: parent ? parent.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		components: null,
		directives: null,
		propsOptions: normalizePropsOptions(type, appContext),
		emitsOptions: normalizeEmitsOptions(type, appContext),
		emit: null,
		emitted: null,
		propsDefaults: EMPTY_OBJ,
		inheritAttrs: type.inheritAttrs,
		ctx: EMPTY_OBJ,
		data: EMPTY_OBJ,
		props: EMPTY_OBJ,
		attrs: EMPTY_OBJ,
		slots: EMPTY_OBJ,
		refs: EMPTY_OBJ,
		setupState: EMPTY_OBJ,
		setupContext: null,
		suspense,
		suspenseId: suspense ? suspense.pendingId : 0,
		asyncDep: null,
		asyncResolved: false,
		isMounted: false,
		isUnmounted: false,
		isDeactivated: false,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	instance.ctx = { _: instance };
	instance.root = parent ? parent.root : instance;
	instance.emit = emit.bind(null, instance);
	if (vnode.ce) vnode.ce(instance);
	return instance;
}
var currentInstance = null;
var getCurrentInstance = () => currentInstance || currentRenderingInstance;
var internalSetCurrentInstance;
var setInSSRSetupState;
{
	const g = getGlobalThis();
	const registerGlobalSetter = (key, setter) => {
		let setters;
		if (!(setters = g[key])) setters = g[key] = [];
		setters.push(setter);
		return (v) => {
			if (setters.length > 1) setters.forEach((set) => set(v));
			else setters[0](v);
		};
	};
	internalSetCurrentInstance = registerGlobalSetter(`__VUE_INSTANCE_SETTERS__`, (v) => currentInstance = v);
	setInSSRSetupState = registerGlobalSetter(`__VUE_SSR_SETTERS__`, (v) => isInSSRComponentSetup = v);
}
var setCurrentInstance = (instance) => {
	const prev = currentInstance;
	internalSetCurrentInstance(instance);
	instance.scope.on();
	return () => {
		instance.scope.off();
		internalSetCurrentInstance(prev);
	};
};
var unsetCurrentInstance = () => {
	currentInstance && currentInstance.scope.off();
	internalSetCurrentInstance(null);
};
function isStatefulComponent(instance) {
	return instance.vnode.shapeFlag & 4;
}
var isInSSRComponentSetup = false;
function setupComponent(instance, isSSR = false, optimized = false) {
	isSSR && setInSSRSetupState(isSSR);
	const { props, children } = instance.vnode;
	const isStateful = isStatefulComponent(instance);
	initProps(instance, props, isStateful, isSSR);
	initSlots(instance, children, optimized || isSSR);
	const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
	isSSR && setInSSRSetupState(false);
	return setupResult;
}
function setupStatefulComponent(instance, isSSR) {
	const Component = instance.type;
	instance.accessCache = /* @__PURE__ */ Object.create(null);
	instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
	const { setup } = Component;
	if (setup) {
		pauseTracking();
		const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
		const reset = setCurrentInstance(instance);
		const setupResult = callWithErrorHandling(setup, instance, 0, [instance.props, setupContext]);
		const isAsyncSetup = isPromise(setupResult);
		resetTracking();
		reset();
		if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) markAsyncBoundary(instance);
		if (isAsyncSetup) {
			setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
			if (isSSR) return setupResult.then((resolvedResult) => {
				handleSetupResult(instance, resolvedResult, isSSR);
			}).catch((e) => {
				handleError(e, instance, 0);
			});
			else instance.asyncDep = setupResult;
		} else handleSetupResult(instance, setupResult, isSSR);
	} else finishComponentSetup(instance, isSSR);
}
function handleSetupResult(instance, setupResult, isSSR) {
	if (isFunction$1(setupResult)) if (instance.type.__ssrInlineRender) instance.ssrRender = setupResult;
	else instance.render = setupResult;
	else if (isObject(setupResult)) instance.setupState = proxyRefs(setupResult);
	finishComponentSetup(instance, isSSR);
}
var compile;
var installWithProxy;
function finishComponentSetup(instance, isSSR, skipOptions) {
	const Component = instance.type;
	if (!instance.render) {
		if (!isSSR && compile && !Component.render) {
			const template = Component.template || resolveMergedOptions(instance).template;
			if (template) {
				const { isCustomElement, compilerOptions } = instance.appContext.config;
				const { delimiters, compilerOptions: componentCompilerOptions } = Component;
				Component.render = compile(template, extend(extend({
					isCustomElement,
					delimiters
				}, compilerOptions), componentCompilerOptions));
			}
		}
		instance.render = Component.render || NOOP;
		if (installWithProxy) installWithProxy(instance);
	}
	{
		const reset = setCurrentInstance(instance);
		pauseTracking();
		try {
			applyOptions(instance);
		} finally {
			resetTracking();
			reset();
		}
	}
}
var attrsProxyHandlers = { get(target, key) {
	track(target, "get", "");
	return target[key];
} };
function createSetupContext(instance) {
	const expose = (exposed) => {
		instance.exposed = exposed || {};
	};
	return {
		attrs: new Proxy(instance.attrs, attrsProxyHandlers),
		slots: instance.slots,
		emit: instance.emit,
		expose
	};
}
function getComponentPublicInstance(instance) {
	if (instance.exposed) return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
		get(target, key) {
			if (key in target) return target[key];
			else if (key in publicPropertiesMap) return publicPropertiesMap[key](instance);
		},
		has(target, key) {
			return key in target || key in publicPropertiesMap;
		}
	}));
	else return instance.proxy;
}
function getComponentName(Component, includeInferred = true) {
	return isFunction$1(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
}
function isClassComponent(value) {
	return isFunction$1(value) && "__vccOpts" in value;
}
var computed = (getterOrOptions, debugOptions) => {
	return /* @__PURE__ */ computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
};
function h(type, propsOrChildren, children) {
	try {
		setBlockTracking(-1);
		const l = arguments.length;
		if (l === 2) if (isObject(propsOrChildren) && !isArray(propsOrChildren)) {
			if (isVNode(propsOrChildren)) return createVNode(type, null, [propsOrChildren]);
			return createVNode(type, propsOrChildren);
		} else return createVNode(type, null, propsOrChildren);
		else {
			if (l > 3) children = Array.prototype.slice.call(arguments, 2);
			else if (l === 3 && isVNode(children)) children = [children];
			return createVNode(type, propsOrChildren, children);
		}
	} finally {
		setBlockTracking(1);
	}
}
var version = "3.5.40";
/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
var policy = void 0;
var tt = typeof window !== "undefined" && window.trustedTypes;
if (tt) try {
	policy = /* @__PURE__ */ tt.createPolicy("vue", { createHTML: (val) => val });
} catch (e) {}
var unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
var svgNS = "http://www.w3.org/2000/svg";
var mathmlNS = "http://www.w3.org/1998/Math/MathML";
var doc = typeof document !== "undefined" ? document : null;
var templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
var nodeOps = {
	insert: (child, parent, anchor) => {
		parent.insertBefore(child, anchor || null);
	},
	remove: (child) => {
		const parent = child.parentNode;
		if (parent) parent.removeChild(child);
	},
	createElement: (tag, namespace, is, props) => {
		const el = namespace === "svg" ? doc.createElementNS(svgNS, tag) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag) : is ? doc.createElement(tag, { is }) : doc.createElement(tag);
		if (tag === "select" && props && props.multiple != null) el.setAttribute("multiple", props.multiple);
		return el;
	},
	createText: (text) => doc.createTextNode(text),
	createComment: (text) => doc.createComment(text),
	setText: (node, text) => {
		node.nodeValue = text;
	},
	setElementText: (el, text) => {
		el.textContent = text;
	},
	parentNode: (node) => node.parentNode,
	nextSibling: (node) => node.nextSibling,
	querySelector: (selector) => doc.querySelector(selector),
	setScopeId(el, id) {
		el.setAttribute(id, "");
	},
	insertStaticContent(content, parent, anchor, namespace, start, end) {
		const before = anchor ? anchor.previousSibling : parent.lastChild;
		if (start && (start === end || start.nextSibling)) while (true) {
			parent.insertBefore(start.cloneNode(true), anchor);
			if (start === end || !(start = start.nextSibling)) break;
		}
		else {
			templateContainer.innerHTML = unsafeToTrustedHTML(namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content);
			const template = templateContainer.content;
			if (namespace === "svg" || namespace === "mathml") {
				const wrapper = template.firstChild;
				while (wrapper.firstChild) template.appendChild(wrapper.firstChild);
				template.removeChild(wrapper);
			}
			parent.insertBefore(template, anchor);
		}
		return [before ? before.nextSibling : parent.firstChild, anchor ? anchor.previousSibling : parent.lastChild];
	}
};
var vtcKey = /* @__PURE__ */ Symbol("_vtc");
function patchClass(el, value, isSVG) {
	const transitionClasses = el[vtcKey];
	if (transitionClasses) value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
	if (value == null) el.removeAttribute("class");
	else if (isSVG) el.setAttribute("class", value);
	else el.className = value;
}
var vShowOriginalDisplay = /* @__PURE__ */ Symbol("_vod");
var vShowHidden = /* @__PURE__ */ Symbol("_vsh");
var vShow = {
	name: "show",
	beforeMount(el, { value }, { transition }) {
		el[vShowOriginalDisplay] = el.style.display === "none" ? "" : el.style.display;
		if (transition && value) transition.beforeEnter(el);
		else setDisplay(el, value);
	},
	mounted(el, { value }, { transition }) {
		if (transition && value) transition.enter(el);
	},
	updated(el, { value, oldValue }, { transition }) {
		if (!value === !oldValue) return;
		if (transition) if (value) {
			transition.beforeEnter(el);
			setDisplay(el, true);
			transition.enter(el);
		} else transition.leave(el, () => {
			setDisplay(el, false);
		});
		else setDisplay(el, value);
	},
	beforeUnmount(el, { value }) {
		setDisplay(el, value);
	}
};
function setDisplay(el, value) {
	el.style.display = value ? el[vShowOriginalDisplay] : "none";
	el[vShowHidden] = !value;
}
var CSS_VAR_TEXT = /* @__PURE__ */ Symbol("");
function useCssVars(getter) {
	const instance = getCurrentInstance();
	if (!instance) return;
	const updateTeleports = instance.ut = (vars = getter(instance.proxy)) => {
		Array.from(document.querySelectorAll(`[data-v-owner="${instance.uid}"]`)).forEach((node) => setVarsOnNode(node, vars));
	};
	const setVars = () => {
		const vars = getter(instance.proxy);
		if (instance.ce) setVarsOnNode(instance.ce, vars);
		else setVarsOnVNode(instance.subTree, vars);
		updateTeleports(vars);
	};
	onBeforeUpdate(() => {
		queuePostFlushCb(setVars);
	});
	onMounted(() => {
		watch(setVars, NOOP, { flush: "post" });
		const ob = new MutationObserver(setVars);
		ob.observe(instance.subTree.el.parentNode, { childList: true });
		onUnmounted(() => ob.disconnect());
	});
}
function setVarsOnVNode(vnode, vars) {
	if (vnode.shapeFlag & 128) {
		const suspense = vnode.suspense;
		vnode = suspense.activeBranch;
		if (suspense.pendingBranch && !suspense.isHydrating) suspense.effects.push(() => {
			setVarsOnVNode(suspense.activeBranch, vars);
		});
	}
	while (vnode.component) vnode = vnode.component.subTree;
	if (vnode.shapeFlag & 1 && vnode.el) setVarsOnNode(vnode.el, vars);
	else if (vnode.type === Fragment) vnode.children.forEach((c) => setVarsOnVNode(c, vars));
	else if (vnode.type === Static) {
		let { el, anchor } = vnode;
		while (el) {
			setVarsOnNode(el, vars);
			if (el === anchor) break;
			el = el.nextSibling;
		}
	}
}
function setVarsOnNode(el, vars) {
	if (el.nodeType === 1) {
		const style = el.style;
		let cssText = "";
		for (const key in vars) {
			const value = normalizeCssVarValue(vars[key]);
			style.setProperty(`--${key}`, value);
			cssText += `--${key}: ${value};`;
		}
		style[CSS_VAR_TEXT] = cssText;
	}
}
var displayRE = /(?:^|;)\s*display\s*:/;
function patchStyle(el, prev, next) {
	const style = el.style;
	const isCssString = isString$1(next);
	let hasControlledDisplay = false;
	if (next && !isCssString) {
		if (prev) if (!isString$1(prev)) {
			for (const key in prev) if (next[key] == null) setStyle(style, key, "");
		} else for (const prevStyle of prev.split(";")) {
			const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
			if (next[key] == null) setStyle(style, key, "");
		}
		for (const key in next) {
			if (key === "display") hasControlledDisplay = true;
			const value = next[key];
			if (value != null) {
				if (!shouldPreserveTextareaResizeStyle(el, key, !isString$1(prev) && prev ? prev[key] : void 0, value)) setStyle(style, key, value);
			} else setStyle(style, key, "");
		}
	} else if (isCssString) {
		if (prev !== next) {
			const cssVarText = style[CSS_VAR_TEXT];
			if (cssVarText) next += ";" + cssVarText;
			style.cssText = next;
			hasControlledDisplay = displayRE.test(next);
		}
	} else if (prev) el.removeAttribute("style");
	if (vShowOriginalDisplay in el) {
		el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
		if (el[vShowHidden]) style.display = "none";
	}
}
var importantRE = /\s*!important$/;
function setStyle(style, name, val) {
	if (isArray(val)) val.forEach((v) => setStyle(style, name, v));
	else {
		if (val == null) val = "";
		if (name.startsWith("--")) style.setProperty(name, val);
		else {
			const prefixed = autoPrefix(style, name);
			if (importantRE.test(val)) style.setProperty(hyphenate(prefixed), val.replace(importantRE, ""), "important");
			else style[prefixed] = val;
		}
	}
}
var prefixes = [
	"Webkit",
	"Moz",
	"ms"
];
var prefixCache = {};
function autoPrefix(style, rawName) {
	const cached = prefixCache[rawName];
	if (cached) return cached;
	let name = camelize(rawName);
	if (name !== "filter" && name in style) return prefixCache[rawName] = name;
	name = capitalize(name);
	for (let i = 0; i < prefixes.length; i++) {
		const prefixed = prefixes[i] + name;
		if (prefixed in style) return prefixCache[rawName] = prefixed;
	}
	return rawName;
}
function shouldPreserveTextareaResizeStyle(el, key, prev, next) {
	return el.tagName === "TEXTAREA" && (key === "width" || key === "height") && isString$1(next) && prev === next;
}
var xlinkNS = "http://www.w3.org/1999/xlink";
function patchAttr(el, key, value, isSVG, instance, isBoolean = isSpecialBooleanAttr(key)) {
	if (isSVG && key.startsWith("xlink:")) if (value == null) el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
	else el.setAttributeNS(xlinkNS, key, value);
	else if (value == null || isBoolean && !includeBooleanAttr(value)) el.removeAttribute(key);
	else el.setAttribute(key, isBoolean ? "" : isSymbol(value) ? String(value) : value);
}
function patchDOMProp(el, key, value, parentComponent, attrName) {
	if (key === "innerHTML" || key === "textContent") {
		if (value != null) el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
		return;
	}
	const tag = el.tagName;
	if (key === "value" && tag !== "PROGRESS" && !tag.includes("-")) {
		const oldValue = tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
		const newValue = value == null ? el.type === "checkbox" ? "on" : "" : String(value);
		if (oldValue !== newValue || !("_value" in el)) el.value = newValue;
		if (value == null) el.removeAttribute(key);
		el._value = value;
		return;
	}
	let needRemove = false;
	if (value === "" || value == null) {
		const type = typeof el[key];
		if (type === "boolean") value = includeBooleanAttr(value);
		else if (value == null && type === "string") {
			value = "";
			needRemove = true;
		} else if (type === "number") {
			value = 0;
			needRemove = true;
		}
	}
	try {
		el[key] = value;
	} catch (e) {}
	needRemove && el.removeAttribute(attrName || key);
}
function addEventListener(el, event, handler, options) {
	el.addEventListener(event, handler, options);
}
function removeEventListener(el, event, handler, options) {
	el.removeEventListener(event, handler, options);
}
var veiKey = /* @__PURE__ */ Symbol("_vei");
function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
	const invokers = el[veiKey] || (el[veiKey] = {});
	const existingInvoker = invokers[rawName];
	if (nextValue && existingInvoker) existingInvoker.value = nextValue;
	else {
		const [name, options] = parseName(rawName);
		if (nextValue) addEventListener(el, name, invokers[rawName] = createInvoker(nextValue, instance), options);
		else if (existingInvoker) {
			removeEventListener(el, name, existingInvoker, options);
			invokers[rawName] = void 0;
		}
	}
}
var optionsModifierRE = /(Once|Passive|Capture)$/;
var optionsModifierEventRE = /^on:?(?:Once|Passive|Capture)$/;
function parseName(name) {
	let options;
	let m;
	while ((m = name.match(optionsModifierRE)) && !optionsModifierEventRE.test(name)) {
		if (!options) options = {};
		name = name.slice(0, name.length - m[1].length);
		options[m[1].toLowerCase()] = true;
	}
	return [name[2] === ":" ? name.slice(3) : hyphenate(name.slice(2)), options];
}
var cachedNow = 0;
var p = /* @__PURE__ */ Promise.resolve();
var getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
function createInvoker(initialValue, instance) {
	const invoker = (e) => {
		if (!e._vts) e._vts = Date.now();
		else if (e._vts <= invoker.attached) return;
		const value = invoker.value;
		if (isArray(value)) {
			const originalStop = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				originalStop.call(e);
				e._stopped = true;
			};
			const handlers = value.slice();
			const args = [e];
			for (let i = 0; i < handlers.length; i++) {
				if (e._stopped) break;
				const handler = handlers[i];
				if (handler) callWithAsyncErrorHandling(handler, instance, 5, args);
			}
		} else callWithAsyncErrorHandling(value, instance, 5, [e]);
	};
	invoker.value = initialValue;
	invoker.attached = getNow();
	return invoker;
}
var isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
var patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
	const isSVG = namespace === "svg";
	if (key === "class") patchClass(el, nextValue, isSVG);
	else if (key === "style") patchStyle(el, prevValue, nextValue);
	else if (isOn(key)) {
		if (!isModelListener(key)) patchEvent(el, key, prevValue, nextValue, parentComponent);
	} else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
		patchDOMProp(el, key, nextValue);
		if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
	} else if (el._isVueCE && (shouldSetAsPropForVueCE(el, key) || el._def.__asyncLoader && (/[A-Z]/.test(key) || !isString$1(nextValue)))) patchDOMProp(el, camelize(key), nextValue, parentComponent, key);
	else {
		if (key === "true-value") el._trueValue = nextValue;
		else if (key === "false-value") el._falseValue = nextValue;
		patchAttr(el, key, nextValue, isSVG);
	}
};
function shouldSetAsProp(el, key, value, isSVG) {
	if (isSVG) {
		if (key === "innerHTML" || key === "textContent") return true;
		if (key in el && isNativeOn(key) && isFunction$1(value)) return true;
		return false;
	}
	if (key === "spellcheck" || key === "draggable" || key === "translate" || key === "autocorrect") return false;
	if (key === "sandbox" && el.tagName === "IFRAME") return false;
	if (key === "form") return false;
	if (key === "list" && el.tagName === "INPUT") return false;
	if (key === "type" && el.tagName === "TEXTAREA") return false;
	if (key === "width" || key === "height") {
		const tag = el.tagName;
		if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") return false;
	}
	if (isNativeOn(key) && isString$1(value)) return false;
	return key in el;
}
function shouldSetAsPropForVueCE(el, key) {
	const props = el._def.props;
	if (!props) return false;
	const camelKey = camelize(key);
	return Array.isArray(props) ? props.some((prop) => camelize(prop) === camelKey) : Object.keys(props).some((prop) => camelize(prop) === camelKey);
}
var systemModifiers = [
	"ctrl",
	"shift",
	"alt",
	"meta"
];
var modifierGuards = {
	stop: (e) => e.stopPropagation(),
	prevent: (e) => e.preventDefault(),
	self: (e) => e.target !== e.currentTarget,
	ctrl: (e) => !e.ctrlKey,
	shift: (e) => !e.shiftKey,
	alt: (e) => !e.altKey,
	meta: (e) => !e.metaKey,
	left: (e) => "button" in e && e.button !== 0,
	middle: (e) => "button" in e && e.button !== 1,
	right: (e) => "button" in e && e.button !== 2,
	exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
};
var withModifiers = (fn, modifiers) => {
	if (!fn) return fn;
	const cache = fn._withMods || (fn._withMods = {});
	const cacheKey = modifiers.join(".");
	return cache[cacheKey] || (cache[cacheKey] = ((event, ...args) => {
		for (let i = 0; i < modifiers.length; i++) {
			const guard = modifierGuards[modifiers[i]];
			if (guard && guard(event, modifiers)) return;
		}
		return fn(event, ...args);
	}));
};
var keyNames = {
	esc: "escape",
	space: " ",
	up: "arrow-up",
	left: "arrow-left",
	right: "arrow-right",
	down: "arrow-down",
	delete: "backspace"
};
var withKeys = (fn, modifiers) => {
	const cache = fn._withKeys || (fn._withKeys = {});
	const cacheKey = modifiers.join(".");
	return cache[cacheKey] || (cache[cacheKey] = ((event) => {
		if (!("key" in event)) return;
		const eventKey = hyphenate(event.key);
		if (modifiers.some((k) => k === eventKey || keyNames[k] === eventKey)) return fn(event);
	}));
};
var rendererOptions = /* @__PURE__ */ extend({ patchProp }, nodeOps);
var renderer;
function ensureRenderer() {
	return renderer || (renderer = createRenderer(rendererOptions));
}
var createApp = ((...args) => {
	const app = ensureRenderer().createApp(...args);
	const { mount } = app;
	app.mount = (containerOrSelector) => {
		const container = normalizeContainer(containerOrSelector);
		if (!container) return;
		const component = app._component;
		if (!isFunction$1(component) && !component.render && !component.template) component.template = container.innerHTML;
		if (container.nodeType === 1) container.textContent = "";
		const proxy = mount(container, false, resolveRootNamespace(container));
		if (container instanceof Element) {
			container.removeAttribute("v-cloak");
			container.setAttribute("data-v-app", "");
		}
		return proxy;
	};
	return app;
});
function resolveRootNamespace(container) {
	if (container instanceof SVGElement) return "svg";
	if (typeof MathMLElement === "function" && container instanceof MathMLElement) return "mathml";
}
function normalizeContainer(container) {
	if (isString$1(container)) return document.querySelector(container);
	return container;
}
/**
* vue v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function isFunction(value) {
	return typeof value === "function";
}
function isString(value) {
	return typeof value === "string";
}
function uuid() {
	return Math.random().toString(36).slice(2, 7);
}
function toCamelCase(attr) {
	return attr.toLowerCase().replace(/-(.)/g, (_, group) => {
		return group.toUpperCase();
	});
}
function camelCaseToUnderscore(str) {
	return str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
}
/**
* 通过 vnode 获取 data 属性
* @param {*} attrs
* @param {*} handler
*/
function getDataAttributes(attrs, handler) {
	if (!attrs) return;
	const result = {};
	for (const attr in attrs) {
		if (!attr.startsWith("data-")) continue;
		const transAttr = toCamelCase(attr.replace(/^data-/, ""));
		result[transAttr] = handler(attrs[attr]);
	}
	return result;
}
var isBrowser = typeof window !== "undefined" && typeof navigator !== "undefined";
var isAndroid = isBrowser && /Android/i.test(navigator.userAgent);
var isIOS = isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent);
var isHarmonyOS = isBrowser && /OpenHarmony|harmony/.test(navigator.userAgent);
var isDesktop = isBrowser && !/Android|iPad|iPhone|iPod|OpenHarmony|harmony|Mobile/.test(navigator.userAgent);
(() => {
	if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) return true;
	else return false;
})();
function resolvePath(basePath, relativePath) {
	if (relativePath.startsWith("/")) return relativePath.slice(1);
	const currParts = basePath.split("/");
	const relativeParts = relativePath.split("/");
	for (const element of relativeParts) {
		const part = element;
		if (part === "..") {
			if (currParts.length > 0) currParts.pop();
		} else if (part !== "." && part !== "") currParts.push(part);
	}
	return currParts.join("/");
}
function parsePath(currPath, url) {
	const basePath = currPath.split("/").slice(0, -1).join("/");
	const parts = url.split("?");
	const pagePath = parts[0];
	const paramStr = parts[1];
	let newUrl = resolvePath(basePath, pagePath);
	if (paramStr) newUrl += `?${paramStr}`;
	return newUrl;
}
var rpxRegex = /([+-]?\d+(?:\.\d+)?)rpx/g;
function transformRpx(styleText) {
	if (!isString(styleText)) return styleText;
	return styleText.replace(rpxRegex, (match, pixel) => {
		const viewportWidth = Number((Number(pixel) / 7.5).toFixed(6));
		return `${Object.is(viewportWidth, -0) ? 0 : viewportWidth}vw`;
	});
}
function suffixPixel(value) {
	return typeof value === "number" && Number.isFinite(value) && !Number.isNaN(value) ? `${value}px` : value;
}
/**
* 添加 Deg 后缀
*/
function suffixDegree(value) {
	return `${value}deg`;
}
/**
* 转化 animate 中 transform 的支持类型为 cssText 中的值
*/
var transformHandler = {
	matrix(args) {
		return `matrix(${args.join(", ")})`;
	},
	matrix3d(args) {
		return `matrix3d(${args.join(", ")})`;
	},
	rotate(args) {
		const [angle] = args.map(suffixDegree);
		return `rotate(${angle})`;
	},
	rotate3d(args) {
		args[3] = suffixDegree(args[3]);
		return `rotate3d(${args.join(", ")})`;
	},
	rotateX(args) {
		const [angle] = args.map(suffixDegree);
		return `rotateX(${angle})`;
	},
	rotateY(args) {
		const [angle] = args.map(suffixDegree);
		return `rotateY(${angle})`;
	},
	rotateZ(args) {
		const [angle] = args.map(suffixDegree);
		return `rotateZ(${angle})`;
	},
	scale(args) {
		return `scale(${args.join(", ")})`;
	},
	scale3d(args) {
		return `scale3d(${args.join(", ")})`;
	},
	scaleX(args) {
		return `scaleX(${args[0]})`;
	},
	scaleY(args) {
		return `scaleY(${args[0]})`;
	},
	scaleZ(args) {
		return `scaleZ(${args[0]})`;
	},
	skew(args) {
		return `skew(${args.map(suffixDegree).join(", ")})`;
	},
	skewX(args) {
		const [angle] = args.map(suffixDegree);
		return `skewX(${angle})`;
	},
	skewY(args) {
		const [angle] = args.map(suffixDegree);
		return `skewY(${angle})`;
	},
	translate(args) {
		return `translate(${args.map(suffixPixel).join(", ")})`;
	},
	translate3d(args) {
		return `translate3d(${args.map(suffixPixel).join(", ")})`;
	},
	translateX(args) {
		const [value] = args.map(suffixPixel);
		return `translateX(${value})`;
	},
	translateY(args) {
		const [value] = args.map(suffixPixel);
		return `translateY(${value})`;
	},
	translateZ(args) {
		const [value] = args.map(suffixPixel);
		return `translateZ(${value})`;
	}
};
function animationToStyle(action) {
	const { animates, option } = action;
	const transformOrigin = option.transformOrigin;
	const transition = option.transition;
	if (transformOrigin === void 0 || transition === void 0) return {
		transformOrigin: "",
		transform: "",
		transition: ""
	};
	const transformAnimations = [];
	const styles = {};
	for (let i = 0; i < animates.length; i++) {
		const animate = animates[i];
		if (animate.type === "style") {
			const [prop, value] = animate.args;
			styles[prop] = value;
		} else {
			const { type, args } = animate;
			if (isFunction(transformHandler[type])) transformAnimations.push(transformHandler[type](args));
			else console.warn(`[Common] SDK inner warning (Transform Handler not found animation type: ${type})`);
		}
	}
	return {
		keyframes: [{
			transform: transformAnimations.join(" "),
			transformOrigin,
			...styles
		}],
		options: {
			duration: transition.duration,
			easing: transition.timingFunction,
			delay: transition.delay,
			fill: "forwards"
		}
	};
}
var JSModules = {};
var MODULES_STATUS_UNLOAD = 1;
var MODULES_STATUS_LOADED = 2;
function modRequire(id, callback, errorCallback) {
	if (typeof id !== "string") throw new TypeError("require args must be a string");
	const mod = JSModules[id];
	if (!mod) throw new Error(`module ${id} not found`);
	if (mod.status === MODULES_STATUS_UNLOAD) {
		mod.status = MODULES_STATUS_LOADED;
		const module = { exports: {} };
		let res;
		try {
			if (mod.factory) res = mod.factory.call(null, modRequire, module, module.exports);
		} catch (e) {
			mod.status = MODULES_STATUS_UNLOAD;
			const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
			console.error(`require ${id} error: ${em}`);
			if (isFunction(errorCallback)) errorCallback({
				mod: id,
				errMsg: e.message
			});
		}
		mod.exports = module.exports === void 0 ? res : module.exports;
	}
	if (isFunction(callback)) callback(mod.exports);
	return mod.exports;
}
modRequire.async = async (id) => {
	return new Promise((resolve, reject) => {
		try {
			resolve(modRequire(id));
		} catch (e) {
			reject(/* @__PURE__ */ new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
		}
	});
};
var Callback = class {
	constructor() {
		this.callbacks = {};
	}
	store(callback, keep, evtId = uuid()) {
		if (keep) {
			for (const [k, v] of Object.entries(this.callbacks)) if (v.callback === callback) return k;
		}
		this.callbacks[evtId] = {
			callback,
			keep
		};
		return evtId;
	}
	/**
	* [Container] triggerCallback -> [Service] invoke
	* @param {*} evtId
	* @param {*} args
	*/
	invoke(evtId, args) {
		if (evtId === void 0) return;
		const obj = this.callbacks[evtId];
		if (obj && isFunction(obj.callback)) {
			obj.callback(args);
			if (!obj.keep) delete this.callbacks[evtId];
		}
	}
	remove(evtId) {
		if (evtId) Object.keys(this.callbacks).forEach((k) => {
			if (evtId === k) delete this.callbacks[k];
		});
		else Object.entries(this.callbacks).forEach(([k, v]) => {
			if (v.keep) delete this.callbacks[k];
		});
	}
};
new Callback();
var initTimeStamp = Date.now();
function useInfo() {
	const bridgeId = inject("bridgeId");
	const currPath = inject("path");
	const info = inject(currPath);
	let moduleId;
	let path;
	const scopeIds = getCurrentInstance().vnode.slotScopeIds;
	if (scopeIds?.length) {
		let currentInfo = info;
		let currentPath = currPath;
		for (let i = 0; i < scopeIds.length; i++) {
			if (!currentInfo?.pagePath) break;
			const parentPath = currentInfo.pagePath;
			const parentInfo = inject(parentPath);
			if (!parentInfo) break;
			currentInfo = parentInfo;
			currentPath = parentPath;
		}
		provide("path", currentPath);
		provide(currentPath, currentInfo);
		moduleId = currentInfo.id;
		path = currentPath;
	} else {
		moduleId = info.id;
		path = currPath;
	}
	return {
		attrs: useAttrs(),
		bridgeId,
		moduleId,
		path
	};
}
/**
* 查找最近的可滚动容器元素
*/
function isScrollable(element) {
	const isElementScrollable = (el) => {
		const style = window.getComputedStyle(el);
		const overflowY = style.overflowY;
		const overflowX = style.overflowX;
		return (overflowY === "auto" || overflowY === "scroll") && el.scrollHeight > el.clientHeight || (overflowX === "auto" || overflowX === "scroll") && el.scrollWidth > el.clientWidth;
	};
	let current = element;
	while (current && current !== document.body) {
		if (isElementScrollable(current)) return true;
		current = current.parentElement;
	}
	return false;
}
/**
* touchstart, touchmove, touchcancel, touchend, tap, longpress
* @param {*} type
* @param {*} any
*/
function triggerEvent(type, { event, detail, info, success }) {
	if (!info.attrs) return;
	const bindHandler = info.attrs[`bind${type}`] || info.attrs[`bind:${type}`];
	const catchHandler = info.attrs[`catch${type}`] || info.attrs[`catch:${type}`];
	if (catchHandler) {
		if (event) {
			event.stopPropagation();
			if (type.startsWith("touch")) {
				if (!isScrollable(event.target)) event.preventDefault();
			}
		}
		sendTriggerEvent(catchHandler, {
			type,
			detail,
			info,
			success,
			event
		});
		return;
	}
	if (bindHandler) sendTriggerEvent(bindHandler, {
		type,
		detail,
		info,
		success,
		event
	});
}
/**
* https://developers.weixin.qq.com/miniprogram/dev/framework/view/wxml/event.html
* @param {*} methodName
* @param {*} param
*/
function sendTriggerEvent(methodName, { type, detail = {}, info, success, event = {} }) {
	const { bridgeId, moduleId } = info;
	const { currentTarget, target, pageX, pageY, changedTouches = [], touches = [] } = event;
	if (pageX !== void 0 && pageY !== void 0) {
		detail.x = pageX;
		detail.y = pageY;
	}
	const currentTargetInfo = currentTarget ? {
		id: currentTarget.id,
		dataset: {
			...currentTarget.dataset,
			...currentTarget._ds
		},
		offsetLeft: currentTarget.offsetLeft,
		offsetTop: currentTarget.offsetTop
	} : {};
	const targetInfo = target ? {
		id: target.id,
		dataset: {
			...target.dataset,
			...target._ds
		},
		offsetLeft: target.offsetLeft,
		offsetTop: target.offsetTop
	} : {};
	const successId = success && window.__callback.store(success);
	window.__message.send({
		type: "t",
		target: "service",
		body: {
			bridgeId,
			moduleId,
			methodName,
			success: successId,
			event: {
				type,
				timeStamp: Date.now() - initTimeStamp,
				detail,
				currentTarget: currentTargetInfo,
				target: targetInfo,
				changedTouches: Array.from(changedTouches).map((touch) => ({
					clientX: touch.clientX,
					clientY: touch.clientY,
					force: touch.force,
					identifier: touch.identifier,
					pageX: touch.pageX,
					pageY: touch.pageY,
					screenX: touch.screenX,
					screenY: touch.screenY
				})),
				touches: Array.from(touches).map((touch) => ({
					clientX: touch.clientX,
					clientY: touch.clientY,
					force: touch.force,
					identifier: touch.identifier,
					pageX: touch.pageX,
					pageY: touch.pageY,
					screenX: touch.screenX,
					screenY: touch.screenY
				}))
			}
		}
	});
}
function invokeAPI(apiName, { params, bridgeId }) {
	window.__message.invoke({
		type: "invokeAPI",
		target: "container",
		body: {
			name: apiName,
			bridgeId,
			params
		}
	});
}
/**
* Invokes a container API from the render thread and routes callbacks back to
* the render callback registry through the service thread.
*/
function invokeAPIWithCallback(apiName, { params = {}, bridgeId, success, fail, complete }) {
	let successId;
	let failId;
	let completeId;
	const callbackRegistry = window.__callback;
	if (success) successId = callbackRegistry.store(success);
	if (fail) failId = callbackRegistry.store(fail);
	completeId = callbackRegistry.store((data) => {
		complete?.(data);
		callbackRegistry.remove(successId);
		callbackRegistry.remove(failId);
	});
	window.__message.send({
		type: "componentInvokeAPI",
		target: "service",
		body: {
			apiName,
			bridgeId,
			callbacks: {
				complete: completeId,
				fail: failId,
				success: successId
			},
			params
		}
	});
}
function onEvent(eventName, callback) {
	const handler = (msg) => {
		callback?.(msg);
	};
	window.__message.on(eventName, handler);
	return () => window.__message.off(eventName, handler);
}
/**
* 检查元素是否有指定事件类型的相关属性
* @param {object} info 组件信息对象
* @param {string} eventType 事件类型，默认为 'tap'
* @returns {boolean} 是否有相关属性
*/
function hasEvent(info, eventType = "tap") {
	const attrs = info.attrs || {};
	return !!(attrs[`bind${eventType}`] || attrs[`bind:${eventType}`] || attrs[`catch${eventType}`] || attrs[`catch:${eventType}`]);
}
/**
* 检查元素是否有指定事件类型的catch属性，支持写法：catchtouchstart、catch:touchstart
* @param {object} info 组件信息对象
* @param {string} eventType 事件类型，默认为 'tap'
* @returns {boolean} 是否有catch属性
*/
function hasCatchEvent(info, eventType = "tap") {
	const attrs = info.attrs || {};
	return !!(attrs[`catch${eventType}`] || attrs[`catch:${eventType}`]);
}
function getActualBottom(element, includeHeight) {
	if (!element) return 0;
	const rect = element.getBoundingClientRect();
	const visualViewport = window.visualViewport;
	return (visualViewport ? visualViewport.height : window.innerHeight) - rect.bottom - (includeHeight ? rect.height : 0);
}
function withInstall(comp) {
	comp.__tagName = camelCaseToUnderscore(comp.__name);
	comp.install = (app) => {
		install(app, comp);
	};
	return comp;
}
var componentPrefix = "dd-";
function install(app, component) {
	app.component(componentPrefix + component.__tagName, component);
}
function deepToRaw(obj) {
	if (typeof obj !== "object" || obj === null) return obj;
	if (Array.isArray(obj)) return obj.map((item) => deepToRaw(item));
	const result = {};
	for (const key in obj) if (Object.prototype.hasOwnProperty.call(obj, key)) {
		const value = obj[key];
		if (/* @__PURE__ */ isRef(value)) result[key] = unref(value);
		else if (/* @__PURE__ */ isReactive(value)) result[key] = /* @__PURE__ */ toRaw(value);
		else if (typeof value === "object" && value !== null) result[key] = deepToRaw(value);
		else result[key] = value;
	}
	return result;
}
function replaceExternalClassTokens(className, externalClass, replacementClassName) {
	const classTokens = className.split(/\s+/).filter(Boolean);
	const replacementTokens = replacementClassName.split(/\s+/).filter(Boolean);
	const nextClassTokens = [];
	for (const token of classTokens) if (token === externalClass) nextClassTokens.push(...replacementTokens);
	else nextClassTokens.push(token);
	return [...new Set(nextClassTokens)].join(" ");
}
var _sfc_main$41 = {
	__name: "Block",
	setup(__props) {
		useInfo();
		return (_ctx, _cache) => {
			return renderSlot(_ctx.$slots, "default");
		};
	}
};
var block_exports = /* @__PURE__ */ __exportAll({ default: () => block_default });
var block_default = withInstall(_sfc_main$41);
/**
* Implements the hover-class behavior shared by view-like components.
*
* exparser marks the original touch event instead of stopping DOM propagation,
* so hover-stop-propagation only suppresses ancestor hover states and does not
* swallow tap/touch handlers.
*/
function useHover(props) {
	const isHover = /* @__PURE__ */ ref(false);
	let isPressed = false;
	let startTimer;
	let stayTimer;
	function clearStartTimer() {
		if (startTimer !== void 0) {
			clearTimeout(startTimer);
			startTimer = void 0;
		}
	}
	function clearStayTimer() {
		if (stayTimer !== void 0) {
			clearTimeout(stayTimer);
			stayTimer = void 0;
		}
	}
	function resetHover() {
		clearStartTimer();
		clearStayTimer();
		isHover.value = false;
	}
	function start(event) {
		if (event._ddHoverPropagationStopped) return;
		if (props.hoverStopPropagation) event._ddHoverPropagationStopped = true;
		isPressed = true;
		clearStartTimer();
		clearStayTimer();
		if (props.disabled || props.hoverClass === "none") return;
		if (event.touches?.length > 1) return;
		startTimer = setTimeout(() => {
			startTimer = void 0;
			isHover.value = true;
			if (!isPressed) stayTimer = setTimeout(resetHover, Number(props.hoverStayTime) || 0);
		}, Math.max(Number(props.hoverStartTime) || 0, 0));
	}
	function end() {
		isPressed = false;
		if (isHover.value) {
			clearStayTimer();
			stayTimer = setTimeout(resetHover, Math.max(Number(props.hoverStayTime) || 0, 0));
		}
	}
	function cancel() {
		isPressed = false;
		resetHover();
	}
	onBeforeUnmount(resetHover);
	return {
		isHover,
		onHoverCancel: cancel,
		onHoverEnd: end,
		onHoverStart: start
	};
}
var _hoisted_1$26 = [
	"id",
	"tabindex",
	"aria-disabled",
	"type",
	"size",
	"loading",
	"plain",
	"disabled",
	"onKeydown"
];
var _sfc_main$40 = {
	__name: "Button",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* 按钮的大小
		* 合法值 default, mini
		*/
		size: {
			type: String,
			default: "default",
			validator: (value) => {
				return ["default", "mini"].includes(value);
			}
		},
		/**
		* 按钮的样式类型
		* 合法值 primary default warn
		*/
		type: {
			type: String,
			default: "default",
			validator: (value) => {
				return [
					"primary",
					"default",
					"warn"
				].includes(value);
			}
		},
		/**
		* 按钮是否镂空，背景色透明
		*/
		plain: {
			type: Boolean,
			default: false
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false
		},
		/**
		* 名称前是否带 loading 图标
		*/
		loading: { type: Boolean },
		/**
		* 用于 form 组件，点击分别会触发 form 组件的 submit/reset 事件
		* 合法值 submit, reset
		*/
		formType: {
			type: String,
			validator: (value) => {
				return ["submit", "reset"].includes(value);
			}
		},
		/**
		* 开放能力，暂不实现
		*/
		openType: {
			type: String,
			validator: (value) => {
				return [
					"contact",
					"liveActivity",
					"share",
					"getPhoneNumber",
					"getRealtimePhoneNumber",
					"getUserInfo",
					"launchApp",
					"openSetting",
					"feedback",
					"chooseAvatar",
					"agreePrivacyAuthorization"
				].includes(value);
			}
		},
		appParameter: {
			type: String,
			default: ""
		},
		launchAppid: {
			type: String,
			default: ""
		},
		withCredentials: {
			type: Boolean,
			default: true
		},
		lang: {
			type: String,
			default: "en"
		},
		sessionFrom: {
			type: String,
			default: "wxapp"
		},
		businessId: {
			type: String,
			default: ""
		},
		sendMessageTitle: {
			type: String,
			default: ""
		},
		sendMessagePath: {
			type: String,
			default: ""
		},
		sendMessageImg: {
			type: String,
			default: ""
		},
		showMessageCard: {
			type: Boolean,
			default: false
		},
		categoryId: {
			type: Array,
			default: () => []
		},
		needPhoneNumber: {
			type: Boolean,
			default: false
		},
		native: {
			type: Boolean,
			default: false
		},
		phoneNumber: {
			type: String,
			default: ""
		},
		smsType: {
			type: Number,
			default: 0
		},
		/**
		* 指定按钮按下去的样式类。当 hover-class="none" 时，没有点击态效果
		*/
		hoverClass: {
			type: String,
			default: "button-hover"
		},
		hover: {
			type: Boolean,
			default: false
		},
		/**
		* 指定是否阻止本节点的祖先节点出现点击态
		*/
		hoverStopPropagation: {
			type: Boolean,
			default: false
		},
		/**
		* 按住后多久出现点击态，单位毫秒
		*/
		hoverStartTime: {
			type: Number,
			default: 20
		},
		/**
		* 手指松开后点击态保留时间，单位毫秒
		*/
		hoverStayTime: {
			type: Number,
			default: 70
		}
	},
	setup(__props) {
		const props = __props;
		const plainParsed = computed(() => {
			return Boolean(props.plain) === true ? true : void 0;
		});
		const disabledParsed = computed(() => {
			return Boolean(props.disabled) === true ? true : void 0;
		});
		const loadingParsed = computed(() => {
			return Boolean(props.loading) === true ? true : void 0;
		});
		const { isHover, onHoverCancel, onHoverEnd, onHoverStart } = useHover(props);
		const info = useInfo();
		const handleFormEvent = inject("formEvent", void 0);
		function handleClicked(event) {
			if (!props.disabled) if (props.formType) handleFormEvent?.(event, props.formType);
			else {
				triggerEvent("tap", {
					event,
					info
				});
				handleOpenType(event);
			}
		}
		function invokeOpenTypeAPI(apiName, eventName, event, params = {}) {
			const preservedEvent = {
				...event,
				currentTarget: event.currentTarget,
				target: event.target
			};
			invokeAPIWithCallback(apiName, {
				bridgeId: info.bridgeId,
				params,
				success: (result = {}) => triggerEvent(eventName, {
					event: preservedEvent,
					info,
					detail: result
				}),
				fail: (result = {}) => triggerEvent(eventName, {
					event: preservedEvent,
					info,
					detail: result
				})
			});
		}
		function handleOpenType(event) {
			switch (props.openType) {
				case "openSetting":
					invokeOpenTypeAPI("openSetting", "opensetting", event);
					break;
				case "getUserInfo":
					invokeOpenTypeAPI("getUserInfo", "getuserinfo", event, {
						lang: props.lang,
						withCredentials: props.withCredentials
					});
					break;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", mergeProps({ id: __props.id }, _ctx.$attrs, {
				class: ["dd-button", [
					`dd-button--${__props.type}`,
					__props.size === "mini" && "dd-button--mini",
					unref(plainParsed) && "dd-button--plain",
					unref(disabledParsed) && "dd-button--disabled",
					unref(loadingParsed) && "dd-button--loading",
					unref(isHover) ? __props.hoverClass : void 0
				]],
				"data-dd-label-target": "",
				role: "button",
				tabindex: __props.disabled ? -1 : 0,
				"aria-disabled": __props.disabled,
				type: __props.type,
				size: __props.size,
				loading: unref(loadingParsed),
				plain: unref(plainParsed),
				disabled: unref(disabledParsed),
				onClick: handleClicked,
				onKeydown: [withKeys(withModifiers(handleClicked, ["prevent"]), ["enter"]), withKeys(withModifiers(handleClicked, ["prevent"]), ["space"])],
				onTouchstart: _cache[0] || (_cache[0] = (...args) => unref(onHoverStart) && unref(onHoverStart)(...args)),
				onTouchend: _cache[1] || (_cache[1] = (...args) => unref(onHoverEnd) && unref(onHoverEnd)(...args)),
				onTouchcancel: _cache[2] || (_cache[2] = (...args) => unref(onHoverCancel) && unref(onHoverCancel)(...args)),
				onMousedown: _cache[3] || (_cache[3] = (...args) => unref(onHoverStart) && unref(onHoverStart)(...args)),
				onMouseup: _cache[4] || (_cache[4] = (...args) => unref(onHoverEnd) && unref(onHoverEnd)(...args)),
				onMouseleave: _cache[5] || (_cache[5] = (...args) => unref(onHoverCancel) && unref(onHoverCancel)(...args))
			}), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_1$26);
		};
	}
};
var button_exports = /* @__PURE__ */ __exportAll({ default: () => button_default });
var button_default = withInstall(_sfc_main$40);
var NATIVE_PLACEHOLDER_SELECTOR = "[data-dimina-native-id][data-dimina-native-type]";
var activePointers = /* @__PURE__ */ new Map();
var pointerIdMap = /* @__PURE__ */ new Map();
var freePointerIds = [];
var installed = false;
var activeTarget = null;
var nextPointerId = 0;
function getBridge() {
	return window.DiminaNativeComponentBridge;
}
function findNativeTarget(touch) {
	const nativeElement = document.elementFromPoint(touch.clientX, touch.clientY)?.closest?.(NATIVE_PLACEHOLDER_SELECTOR);
	if (!nativeElement) return null;
	const id = nativeElement.dataset.diminaNativeId;
	const type = nativeElement.dataset.diminaNativeType;
	if (!id || !type) return null;
	return {
		id,
		type
	};
}
function acquirePointerId(touchIdentifier) {
	if (pointerIdMap.has(touchIdentifier)) return pointerIdMap.get(touchIdentifier);
	const pointerId = freePointerIds.length ? freePointerIds.shift() : nextPointerId++;
	pointerIdMap.set(touchIdentifier, pointerId);
	return pointerId;
}
function releasePointerId(touchIdentifier) {
	if (!pointerIdMap.has(touchIdentifier)) return;
	freePointerIds.push(pointerIdMap.get(touchIdentifier));
	pointerIdMap.delete(touchIdentifier);
}
function normalizeTouch(touch) {
	const touchIdentifier = String(touch.identifier);
	return {
		touchIdentifier,
		id: acquirePointerId(touchIdentifier),
		clientX: touch.clientX,
		clientY: touch.clientY,
		pageX: touch.pageX,
		pageY: touch.pageY
	};
}
function updateActivePointers(touches) {
	for (const touch of touches) {
		const touchIdentifier = String(touch.identifier);
		if (activePointers.has(touchIdentifier)) activePointers.set(touchIdentifier, normalizeTouch(touch));
	}
}
function sendTouch(action, actionPointerId) {
	const bridge = getBridge();
	if (!bridge?.dispatchTouch || !activeTarget || !activePointers.size) return;
	bridge.dispatchTouch(JSON.stringify({
		action,
		actionPointerId,
		targetId: activeTarget.id,
		targetType: activeTarget.type,
		viewportWidth: window.innerWidth,
		viewportHeight: window.innerHeight,
		pointers: Array.from(activePointers.values()).map((pointer) => ({
			id: pointer.id,
			clientX: pointer.clientX,
			clientY: pointer.clientY,
			pageX: pointer.pageX,
			pageY: pointer.pageY
		}))
	}));
}
function consume(event) {
	event.preventDefault();
	event.stopImmediatePropagation();
}
function onTouchStart(event) {
	if (!getBridge()?.dispatchTouch) return;
	let consumed = false;
	for (const touch of event.changedTouches) {
		const target = activeTarget || findNativeTarget(touch);
		if (!target || activeTarget && target.id !== activeTarget.id) continue;
		activeTarget = target;
		updateActivePointers(event.touches);
		const pointer = normalizeTouch(touch);
		activePointers.set(pointer.touchIdentifier, pointer);
		sendTouch(activePointers.size === 1 ? "down" : "pointerDown", pointer.id);
		consumed = true;
	}
	if (consumed) consume(event);
}
function onTouchMove(event) {
	if (!activeTarget || !activePointers.size) return;
	updateActivePointers(event.touches);
	sendTouch("move", -1);
	consume(event);
}
function onTouchEnd(event) {
	if (!activeTarget || !activePointers.size) return;
	let consumed = false;
	updateActivePointers(event.touches);
	for (const touch of event.changedTouches) {
		const touchIdentifier = String(touch.identifier);
		if (!activePointers.has(touchIdentifier)) continue;
		const pointer = normalizeTouch(touch);
		activePointers.set(touchIdentifier, pointer);
		sendTouch(activePointers.size === 1 ? "up" : "pointerUp", pointer.id);
		activePointers.delete(touchIdentifier);
		releasePointerId(touchIdentifier);
		consumed = true;
	}
	if (!activePointers.size) activeTarget = null;
	if (consumed) consume(event);
}
function onTouchCancel(event) {
	if (!activeTarget || !activePointers.size) return;
	updateActivePointers(event.touches);
	sendTouch("cancel", -1);
	for (const touchIdentifier of activePointers.keys()) releasePointerId(touchIdentifier);
	activePointers.clear();
	activeTarget = null;
	consume(event);
}
function ensureNativeLayerTouchBridge() {
	if (!isAndroid || installed || typeof document === "undefined") return;
	installed = true;
	document.addEventListener("touchstart", onTouchStart, {
		capture: true,
		passive: false
	});
	document.addEventListener("touchmove", onTouchMove, {
		capture: true,
		passive: false
	});
	document.addEventListener("touchend", onTouchEnd, {
		capture: true,
		passive: false
	});
	document.addEventListener("touchcancel", onTouchCancel, {
		capture: true,
		passive: false
	});
}
var _hoisted_1$25 = ["id"];
var _hoisted_2$11 = {
	key: 1,
	class: "dd-camera-native dd-camera-container"
};
var _hoisted_3$5 = ["data-dimina-native-id"];
var _hoisted_4$4 = {
	key: 4,
	class: "dd-camera-unavailable"
};
var _hoisted_5$2 = { class: "dd-camera-slot" };
var type$3 = "native/camera";
var _sfc_main$39 = {
	__name: "Camera",
	props: {
		id: {
			type: String,
			default: () => `camera-${useId()}`
		},
		mode: {
			type: String,
			default: "normal",
			validator: (value) => ["normal", "scanCode"].includes(value)
		},
		devicePosition: {
			type: String,
			default: "back",
			validator: (value) => ["front", "back"].includes(value)
		},
		filter: {
			type: Number,
			default: 0
		},
		flash: {
			type: String,
			default: "auto",
			validator: (value) => [
				"auto",
				"on",
				"off",
				"torch"
			].includes(value)
		},
		scanArea: {
			type: Array,
			default: () => []
		},
		needOutput: {
			type: Boolean,
			default: false
		},
		frameSize: {
			type: String,
			default: "",
			validator: (value) => [
				"",
				"small",
				"medium",
				"large"
			].includes(value)
		},
		centerCrop: {
			type: Boolean,
			default: true
		},
		resolution: {
			type: String,
			default: "medium",
			validator: (value) => [
				"low",
				"medium",
				"high"
			].includes(value)
		}
	},
	setup(__props) {
		const props = __props;
		const rootRef = /* @__PURE__ */ ref();
		const videoRef = /* @__PURE__ */ ref();
		const info = useInfo();
		const isNativeCamera = computed(() => isAndroid || isIOS || isHarmonyOS);
		const nativeEventOffs = [];
		let mediaStream;
		let resizeObserver;
		let scanFrameId = 0;
		let syncFrameId = 0;
		let lastRectKey = "";
		let nativeMounted = false;
		let desktopCameraVersion = 0;
		let barcodeDetector;
		function getRect() {
			if (!rootRef.value) return {};
			const rect = rootRef.value.getBoundingClientRect();
			return {
				left: rect.left,
				top: rect.top,
				width: rect.width,
				height: rect.height,
				pageLeft: rect.left + window.scrollX,
				pageTop: rect.top + window.scrollY,
				scrollX: window.scrollX,
				scrollY: window.scrollY,
				viewportWidth: window.innerWidth,
				viewportHeight: window.innerHeight
			};
		}
		function getNativeParams() {
			return {
				type: type$3,
				id: props.id,
				mode: props.mode,
				devicePosition: props.mode === "scanCode" ? "back" : props.devicePosition,
				filter: props.filter,
				flash: props.flash,
				scanArea: props.scanArea,
				needOutput: props.needOutput,
				frameSize: props.frameSize,
				centerCrop: props.centerCrop,
				resolution: props.resolution,
				hidden: rootRef.value?.hasAttribute("hidden") || false,
				rect: getRect()
			};
		}
		function invokeNative(apiName) {
			if (!isNativeCamera.value) return;
			if (apiName === "propsUpdate" && !nativeMounted) return;
			invokeAPI(apiName, {
				bridgeId: info.bridgeId,
				params: getNativeParams()
			});
		}
		function bindNativeEvent(eventType) {
			const off = onEvent(`bind${eventType}`, (msg) => {
				if (msg.id !== void 0 && msg.id !== props.id && msg.cameraId !== props.id) return;
				triggerEvent(eventType, {
					type: eventType,
					info,
					detail: msg
				});
			});
			nativeEventOffs.push(off);
		}
		function syncRect(force = false) {
			const rectKey = JSON.stringify({
				...getRect(),
				hidden: rootRef.value?.hasAttribute("hidden") || false
			});
			if (force || rectKey !== lastRectKey) {
				lastRectKey = rectKey;
				invokeNative("propsUpdate");
			}
		}
		function scheduleSyncRect() {
			if (syncFrameId) return;
			syncFrameId = requestAnimationFrame(() => {
				syncFrameId = 0;
				syncRect();
			});
		}
		function triggerCameraEvent(eventType, detail = {}) {
			triggerEvent(eventType, {
				type: eventType,
				info,
				detail
			});
		}
		function stopDesktopCamera() {
			desktopCameraVersion++;
			if (scanFrameId) cancelAnimationFrame(scanFrameId);
			scanFrameId = 0;
			mediaStream?.getTracks().forEach((track) => track.stop());
			mediaStream = void 0;
			barcodeDetector = void 0;
			if (videoRef.value) videoRef.value.srcObject = null;
		}
		async function scanDesktopFrame() {
			if (!mediaStream || props.mode !== "scanCode" || !barcodeDetector) return;
			try {
				const codes = await barcodeDetector.detect(videoRef.value);
				if (codes[0]) triggerCameraEvent("scancode", {
					type: codes[0].format,
					result: codes[0].rawValue
				});
			} catch {}
			scanFrameId = requestAnimationFrame(scanDesktopFrame);
		}
		async function startDesktopCamera() {
			stopDesktopCamera();
			const version = desktopCameraVersion;
			if (!navigator.mediaDevices?.getUserMedia || !videoRef.value) {
				triggerCameraEvent("error", { errMsg: "camera:fail camera is not available" });
				return;
			}
			try {
				const stream = await navigator.mediaDevices.getUserMedia({
					audio: false,
					video: { facingMode: props.mode === "scanCode" || props.devicePosition === "back" ? "environment" : "user" }
				});
				if (version !== desktopCameraVersion || !videoRef.value) {
					stream.getTracks().forEach((track) => track.stop());
					return;
				}
				mediaStream = stream;
				videoRef.value.srcObject = mediaStream;
				mediaStream.getVideoTracks()[0]?.addEventListener("ended", () => {
					triggerCameraEvent("stop", { reason: "camera track ended" });
				});
				await videoRef.value.play();
				const zoom = mediaStream.getVideoTracks()[0]?.getCapabilities?.().zoom;
				triggerCameraEvent("initdone", { maxZoom: zoom?.max || 1 });
				if (props.mode === "scanCode" && window.BarcodeDetector) {
					barcodeDetector = new window.BarcodeDetector();
					scanDesktopFrame();
				}
			} catch (error) {
				triggerCameraEvent("error", { errMsg: error?.message || "camera:fail open camera failed" });
			}
		}
		onMounted(() => {
			if (isDesktop) {
				startDesktopCamera();
				return;
			}
			if (!isNativeCamera.value) return;
			if (isAndroid) ensureNativeLayerTouchBridge();
			for (const eventType of [
				"stop",
				"error",
				"output",
				"scancode",
				"initdone"
			]) bindNativeEvent(eventType);
			nextTick(() => {
				nativeMounted = true;
				invokeNative("componentMount");
				lastRectKey = JSON.stringify({
					...getRect(),
					hidden: rootRef.value?.hasAttribute("hidden") || false
				});
				window.addEventListener("resize", scheduleSyncRect);
				window.addEventListener("scroll", scheduleSyncRect, true);
				if (window.ResizeObserver && rootRef.value) {
					resizeObserver = new ResizeObserver(scheduleSyncRect);
					resizeObserver.observe(rootRef.value);
				}
			});
		});
		watch(() => getNativeParams(), () => invokeNative("propsUpdate"), { deep: true });
		watch(() => [props.mode, props.devicePosition], () => {
			if (isDesktop) startDesktopCamera();
		});
		onBeforeUnmount(() => {
			stopDesktopCamera();
			if (syncFrameId) cancelAnimationFrame(syncFrameId);
			resizeObserver?.disconnect();
			window.removeEventListener("resize", scheduleSyncRect);
			window.removeEventListener("scroll", scheduleSyncRect, true);
			invokeNative("componentUnmount");
			nativeMounted = false;
			nativeEventOffs.splice(0).forEach((off) => off());
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef
			}, _ctx.$attrs, { class: "dd-camera" }), [unref(isDesktop) ? (openBlock(), createElementBlock("video", {
				key: 0,
				ref_key: "videoRef",
				ref: videoRef,
				class: "dd-camera-native",
				autoplay: "",
				muted: "",
				playsinline: "",
				style: normalizeStyle({ objectFit: __props.centerCrop ? "cover" : "contain" })
			}, null, 4)) : unref(isIOS) ? (openBlock(), createElementBlock("div", _hoisted_2$11, [..._cache[0] || (_cache[0] = [createBaseVNode("div", null, null, -1)])])) : unref(isAndroid) ? (openBlock(), createElementBlock("embed", {
				key: 2,
				class: "dd-camera-native",
				type: "application/view",
				comp_type: type$3,
				"data-dimina-native-type": "native/camera",
				"data-dimina-native-id": __props.id
			}, null, 8, _hoisted_3$5)) : unref(isHarmonyOS) ? (openBlock(), createElementBlock("embed", {
				key: 3,
				class: "dd-camera-native",
				type: type$3
			})) : (openBlock(), createElementBlock("div", _hoisted_4$4, "未找到摄像头")), createBaseVNode("div", _hoisted_5$2, [renderSlot(_ctx.$slots, "default")])], 16, _hoisted_1$25);
		};
	}
};
var camera_exports = /* @__PURE__ */ __exportAll({ default: () => camera_default });
var camera_default = withInstall(_sfc_main$39);
/**
* 处理组件的触摸相关事件
* 封装了触摸事件的添加、移除和检测catch事件处理器的逻辑
* @param {object} info 组件信息
* @param {object} elementRef 元素引用
* @param {number} longPressThreshold 长按触发阈值，单位毫秒
* @param {number} moveThreshold 判定为移动的阈值，单位像素
*/
function useTouchEvents(info, elementRef, longPressThreshold = 350, moveThreshold = 10) {
	const longPressTimer = /* @__PURE__ */ ref(null);
	const touchStartPosition = /* @__PURE__ */ ref({
		x: 0,
		y: 0
	});
	const isTouchMoved = /* @__PURE__ */ ref(false);
	const canMoveStatus = /* @__PURE__ */ ref("init");
	/**
	* 触摸开始事件处理
	* @param {Event} event 原始事件对象
	*/
	function onTouchStart(event) {
		const currentTarget = event.currentTarget;
		const touch = event.touches[0];
		touchStartPosition.value = {
			x: touch.clientX,
			y: touch.clientY
		};
		isTouchMoved.value = false;
		canMoveStatus.value = "init";
		if (longPressTimer.value) clearTimeout(longPressTimer.value);
		longPressTimer.value = setTimeout(() => {
			if (!isTouchMoved.value) {
				const preservedEvent = {
					...event,
					currentTarget
				};
				triggerEvent("longpress", {
					event: preservedEvent,
					info
				});
				triggerEvent("longtap", {
					event: preservedEvent,
					info
				});
			}
			longPressTimer.value = null;
		}, longPressThreshold);
		triggerEvent("touchstart", {
			event,
			info
		});
	}
	/**
	* 触摸移动事件处理
	* @param {Event} event 原始事件对象
	*/
	function onTouchMove(event) {
		const touch = event.touches[0];
		const moveX = Math.abs(touch.clientX - touchStartPosition.value.x);
		const moveY = Math.abs(touch.clientY - touchStartPosition.value.y);
		if (moveX > moveThreshold || moveY > moveThreshold) {
			isTouchMoved.value = true;
			if (longPressTimer.value) {
				clearTimeout(longPressTimer.value);
				longPressTimer.value = null;
			}
		}
		if (hasCatchEvent(info, "touchmove")) {
			if (canMoveStatus.value === "off") {
				event.cancelable && event.preventDefault();
				return;
			}
			const path = event?.composedPath() || [];
			for (const element of path) {
				const { scrollHeight, clientHeight, scrollTop } = element;
				if (scrollHeight > clientHeight) {
					if (touch.clientY - touchStartPosition.value.y > 0) scrollTop === 0 && preventDefaultMove(event);
					else if (scrollHeight - clientHeight - scrollTop < 1) preventDefaultMove(event);
					else canMoveStatus.value = "on";
					break;
				}
			}
		}
		triggerEvent("touchmove", {
			event,
			info
		});
	}
	/**
	* 禁止浏览器默认行为事件处理
	* @param {Event} event 原始事件对象
	*/
	function preventDefaultMove(event) {
		event.cancelable && event.preventDefault();
		canMoveStatus.value === "init" && (canMoveStatus.value = "off");
	}
	/**
	* 触摸结束事件处理
	* @param {Event} event 原始事件对象
	*/
	function onTouchEnd(event) {
		if (longPressTimer.value) {
			clearTimeout(longPressTimer.value);
			longPressTimer.value = null;
		}
		triggerEvent("touchend", {
			event,
			info
		});
	}
	/**
	* 触摸取消事件处理
	* @param {Event} event 原始事件对象
	*/
	function onTouchCancel(event) {
		if (longPressTimer.value) {
			clearTimeout(longPressTimer.value);
			longPressTimer.value = null;
		}
		triggerEvent("touchcancel", {
			event,
			info
		});
	}
	const hasCatchTouchStart = hasCatchEvent(info, "touchstart");
	const hasCatchTouchMove = hasCatchEvent(info, "touchmove");
	const hasCatchTouchEnd = hasCatchEvent(info, "touchend");
	const hasCatchTouchCancel = hasCatchEvent(info, "touchcancel");
	onMounted(() => {
		if (elementRef.value) {
			elementRef.value.addEventListener("touchstart", onTouchStart, { passive: !hasCatchTouchStart });
			elementRef.value.addEventListener("touchmove", onTouchMove, { passive: !hasCatchTouchMove });
			elementRef.value.addEventListener("touchend", onTouchEnd, { passive: !hasCatchTouchEnd });
			elementRef.value.addEventListener("touchcancel", onTouchCancel, { passive: !hasCatchTouchCancel });
		}
	});
	onUnmounted(() => {
		if (elementRef.value) {
			elementRef.value.removeEventListener("touchstart", onTouchStart, { passive: !hasCatchTouchStart });
			elementRef.value.removeEventListener("touchmove", onTouchMove, { passive: !hasCatchTouchMove });
			elementRef.value.removeEventListener("touchend", onTouchEnd, { passive: !hasCatchTouchEnd });
			elementRef.value.removeEventListener("touchcancel", onTouchCancel, { passive: !hasCatchTouchCancel });
		}
	});
}
var _hoisted_1$24 = [
	"canvas-id",
	"data-type",
	"width",
	"height"
];
var _hoisted_2$10 = { class: "dd-canvas-slot" };
var _sfc_main$38 = {
	__name: "Canvas",
	props: {
		canvasId: {
			type: String,
			default: ""
		},
		disableScroll: {
			type: Boolean,
			default: false
		},
		type: {
			type: String,
			default: ""
		},
		newTouchListener: {
			type: Boolean,
			default: false
		},
		renderWidth: {
			type: Number,
			default: 300
		},
		renderHeight: {
			type: Number,
			default: 150
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		const canvasRef = /* @__PURE__ */ ref(null);
		const rootRef = /* @__PURE__ */ ref(null);
		const isError = /* @__PURE__ */ ref(false);
		if ([
			"touchstart",
			"touchmove",
			"touchend",
			"touchcancel",
			"longpress",
			"longtap"
		].some((eventName) => hasEvent(info, eventName))) useTouchEvents(info, rootRef);
		function preventScroll(event) {
			if (props.disableScroll && event.cancelable) event.preventDefault();
		}
		onMounted(() => {
			if (props.type) return;
			let errMsg;
			if (!props.canvasId) errMsg = "canvas-id attribute is undefined";
			else {
				const scope = rootRef.value.closest(".dd-page") || document;
				if (Array.from(scope.querySelectorAll("canvas[canvas-id]")).filter((canvas) => canvas.getAttribute("canvas-id") === props.canvasId).length > 1) errMsg = `canvas-id ${props.canvasId} in this page has already existed`;
			}
			if (errMsg) {
				isError.value = true;
				triggerEvent("error", {
					info,
					detail: { errMsg }
				});
			}
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				ref_key: "rootRef",
				ref: rootRef
			}, _ctx.$attrs, {
				class: "dd-canvas",
				style: unref(isError) ? { display: "none" } : void 0,
				onTouchmove: preventScroll
			}), [createBaseVNode("canvas", {
				ref_key: "canvasRef",
				ref: canvasRef,
				"canvas-id": __props.canvasId,
				"data-type": __props.type || void 0,
				width: __props.renderWidth,
				height: __props.renderHeight
			}, null, 8, _hoisted_1$24), createBaseVNode("div", _hoisted_2$10, [renderSlot(_ctx.$slots, "default")])], 16);
		};
	}
};
var canvas_exports = /* @__PURE__ */ __exportAll({ default: () => canvas_default });
var canvas_default = withInstall(_sfc_main$38);
var _hoisted_1$23 = [
	"id",
	"tabindex",
	"aria-checked",
	"aria-disabled",
	"onKeydown"
];
var _hoisted_2$9 = { class: "dd-checkbox-wrapper" };
var _sfc_main$37 = {
	__name: "Checkbox",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* checkbox标识，选中时触发checkbox-group的 change 事件，并携带 checkbox 的 value。
		*/
		value: {
			type: String,
			default: ""
		},
		/**
		* 是否禁用 checkbox。
		*/
		disabled: {
			type: Boolean,
			default: false
		},
		/**
		* 当前是否选中，可用来设置默认选中。
		*/
		checked: {
			type: Boolean,
			default: false
		},
		/**
		* checkbox颜色，同css的color。
		*/
		color: {
			type: String,
			default: "#09BB07"
		}
	},
	setup(__props) {
		const props = __props;
		const isOn = /* @__PURE__ */ ref(props.checked);
		const checkboxGroup = inject("checkboxGroup", void 0);
		watch(() => props.checked, (value) => {
			isOn.value = value;
		});
		const checkboxControl = {
			getValue: () => props.value,
			isChecked: () => isOn.value,
			setChecked: (value) => {
				isOn.value = value;
			},
			reset: () => {
				isOn.value = false;
			}
		};
		const unregisterCheckbox = checkboxGroup?.registerCheckbox(checkboxControl);
		onBeforeUnmount(() => unregisterCheckbox?.());
		const computedStyle = computed(() => {
			if (props.color) return { color: props.color };
			else return;
		});
		function handleClicked(event) {
			if (!props.disabled) if (checkboxGroup) checkboxGroup.toggleCheckbox(checkboxControl, event);
			else isOn.value = !isOn.value;
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, {
				class: "dd-checkbox",
				"data-dd-label-target": "",
				role: "checkbox",
				tabindex: __props.disabled ? -1 : 0,
				"aria-checked": unref(isOn),
				"aria-disabled": __props.disabled,
				onClick: handleClicked,
				onKeydown: [withKeys(withModifiers(handleClicked, ["prevent"]), ["enter"]), withKeys(withModifiers(handleClicked, ["prevent"]), ["space"])]
			}), [createBaseVNode("div", _hoisted_2$9, [createBaseVNode("div", {
				class: normalizeClass(["dd-checkbox-input", {
					"dd-checkbox-input-checked": unref(isOn),
					"dd-checkbox-input-disabled": __props.disabled
				}]),
				style: normalizeStyle(unref(computedStyle))
			}, null, 6), renderSlot(_ctx.$slots, "default")])], 16, _hoisted_1$23);
		};
	}
};
var checkbox_exports = /* @__PURE__ */ __exportAll({ default: () => checkbox_default });
var checkbox_default = withInstall(_sfc_main$37);
var _hoisted_1$22 = ["id"];
var _sfc_main$36 = {
	__name: "CheckboxGroup",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* name，为表单使用
		*/
		name: { type: String },
		autoFill: { type: String }
	},
	setup(__props) {
		const props = __props;
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		const items = /* @__PURE__ */ new Set();
		function getValue() {
			return [...items].filter((item) => item.isChecked()).map((item) => item.getValue());
		}
		function syncFormValue() {
			collectFormValue?.(props.name, getValue());
		}
		function registerCheckbox(item) {
			items.add(item);
			syncFormValue();
			return () => {
				items.delete(item);
				syncFormValue();
			};
		}
		const info = useInfo();
		function toggleCheckbox(item, event) {
			item.setChecked(!item.isChecked());
			const value = getValue();
			collectFormValue?.(props.name, value);
			triggerEvent("change", {
				event,
				info,
				detail: { value }
			});
		}
		function reset() {
			for (const item of items) item.reset();
			syncFormValue();
		}
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue,
			reset
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		provide("checkboxGroup", {
			registerCheckbox,
			toggleCheckbox
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, {
				class: "dd-checkbox-group",
				role: "group"
			}), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_1$22);
		};
	}
};
var checkbox_group_exports = /* @__PURE__ */ __exportAll({ default: () => checkbox_group_default });
var checkbox_group_default = withInstall(_sfc_main$36);
var _sfc_main$35 = {
	__name: "ComponentHost",
	props: { name: { type: String } },
	setup(__props) {
		const props = __props;
		useInfo();
		const componentName = computed(() => {
			if (!props.name) return "component-host";
			let name = props.name.replace(/^\/+/, "").replace(/\/index$/, "").replace(/\//g, "-").replace(/[^a-zA-Z0-9-]/g, "-").toLowerCase();
			if (!/^[a-zA-Z]/.test(name)) name = "component-host-" + name;
			return name || "component-host";
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(resolveDynamicComponent(unref(componentName)), normalizeProps(guardReactiveProps(_ctx.$attrs)), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16);
		};
	}
};
var component_host_exports = /* @__PURE__ */ __exportAll({ default: () => component_host_default });
var component_host_default = withInstall(_sfc_main$35);
function useTapEvents(elementRef, handler) {
	onMounted(() => {
		if (elementRef.value) elementRef.value.addEventListener("click", handler);
	});
	onUnmounted(() => {
		if (elementRef.value) elementRef.value.removeEventListener("click", handler);
	});
}
var _hoisted_1$21 = [
	"src",
	"loading",
	"referrerpolicy"
];
var _sfc_main$34 = {
	__name: "Image",
	props: {
		src: {
			type: String,
			default: ""
		},
		lazyLoad: {
			type: Boolean,
			default: false
		},
		lazyLoadMargin: {
			type: Number,
			default: 2
		},
		webp: {
			type: Boolean,
			default: false
		},
		backgroundSize: {
			type: String,
			default: "100% 100%"
		},
		backgroundPosition: {
			type: String,
			default: ""
		},
		backgroundRepeat: {
			type: String,
			default: "no-repeat"
		},
		renderingMode: {
			type: String,
			default: "backgroundImage",
			validator: (value) => ["backgroundImage", "img"].includes(value)
		},
		showMenuByLongpress: {
			type: Boolean,
			default: false
		},
		referrerPolicy: {
			type: String,
			default: "unsafe-url"
		},
		mode: {
			type: String,
			default: "scaleToFill",
			validator: (val) => {
				return [
					"scaleToFill",
					"aspectFit",
					"aspectFill",
					"widthFix",
					"heightFix",
					"top",
					"bottom",
					"center",
					"left",
					"right",
					"top left",
					"top right",
					"bottom left",
					"bottom right"
				].includes(val);
			}
		}
	},
	setup(__props) {
		const props = __props;
		const MODE_CLASS_MAP = {
			"scaleToFill": "dd-image-scale",
			"aspectFit": "dd-image-aspect",
			"aspectFill": "dd-image-fill",
			"widthFix": "dd-image-width",
			"heightFix": "dd-image-height",
			"top": "dd-image-top",
			"bottom": "dd-image-bottom",
			"center": "dd-image-center",
			"left": "dd-image-left",
			"right": "dd-image-right",
			"top left": "dd-image-top-left",
			"top right": "dd-image-top-right",
			"bottom left": "dd-image-bottom-left",
			"bottom right": "dd-image-bottom-right"
		};
		const dynamicClass = computed(() => MODE_CLASS_MAP[props.mode] || "");
		const BACKGROUND_MODE_MAP = {
			"scaleToFill": { backgroundSize: "100% 100%" },
			"aspectFit": {
				backgroundSize: "contain",
				backgroundPosition: "center center"
			},
			"aspectFill": {
				backgroundSize: "cover",
				backgroundPosition: "center center"
			},
			"widthFix": { backgroundSize: "100% 100%" },
			"heightFix": { backgroundSize: "100% 100%" },
			"top": { backgroundPosition: "top center" },
			"bottom": { backgroundPosition: "bottom center" },
			"center": { backgroundPosition: "center center" },
			"left": { backgroundPosition: "center left" },
			"right": { backgroundPosition: "center right" },
			"top left": { backgroundPosition: "top left" },
			"top right": { backgroundPosition: "top right" },
			"bottom left": { backgroundPosition: "bottom left" },
			"bottom right": { backgroundPosition: "bottom right" }
		};
		const backgroundStyle = computed(() => {
			if (props.renderingMode !== "backgroundImage") return void 0;
			return {
				backgroundImage: renderedSrc.value ? `url(${JSON.stringify(renderedSrc.value)})` : "",
				backgroundSize: props.backgroundSize,
				backgroundPosition: props.backgroundPosition,
				backgroundRepeat: props.backgroundRepeat,
				...BACKGROUND_MODE_MAP[props.mode]
			};
		});
		const imgRef = /* @__PURE__ */ ref(null);
		const conRef = /* @__PURE__ */ ref(null);
		const renderedSrc = /* @__PURE__ */ ref(props.lazyLoad ? "" : props.src);
		let intersectionObserver;
		let resizeObserver;
		let originalWidth = "";
		let originalHeight = "";
		let hasBeenShown = !props.lazyLoad;
		const info = useInfo();
		let lastCompletedSrc = "";
		onMounted(() => {
			originalWidth = conRef.value.style.width;
			originalHeight = conRef.value.style.height;
			applyModeSize();
			setupLazyLoading();
			if (window.ResizeObserver && conRef.value) {
				resizeObserver = new ResizeObserver(updateFixedSize);
				resizeObserver.observe(conRef.value);
			}
			checkCompletedImage();
		});
		onBeforeUnmount(() => {
			intersectionObserver?.disconnect();
			resizeObserver?.disconnect();
		});
		watch(() => props.src, async () => {
			lastCompletedSrc = "";
			if (props.lazyLoad) {
				hasBeenShown = false;
				renderedSrc.value = "";
				await nextTick();
				setupLazyLoading();
			} else showImage();
			await nextTick();
			checkCompletedImage();
		});
		function showImage() {
			hasBeenShown = true;
			renderedSrc.value = props.src;
			intersectionObserver?.disconnect();
			intersectionObserver = void 0;
		}
		function setupLazyLoading() {
			intersectionObserver?.disconnect();
			intersectionObserver = void 0;
			if (!props.lazyLoad || hasBeenShown || !("IntersectionObserver" in window)) {
				showImage();
				return;
			}
			const margin = Math.max(Number(props.lazyLoadMargin) || 0, 0);
			const verticalMargin = margin * window.innerHeight;
			const horizontalMargin = margin * window.innerWidth;
			intersectionObserver = new IntersectionObserver((entries) => {
				if (entries.some((entry) => entry.isIntersecting || entry.intersectionRatio > 0)) showImage();
			}, { rootMargin: `${verticalMargin}px ${horizontalMargin}px` });
			intersectionObserver.observe(conRef.value);
		}
		watch(() => [props.lazyLoad, props.lazyLoadMargin], ([lazyLoad], [previousLazyLoad]) => {
			if (!lazyLoad) showImage();
			else if (!previousLazyLoad && renderedSrc.value) hasBeenShown = true;
			else setupLazyLoading();
		});
		function handleLoaded(event) {
			lastCompletedSrc = props.src;
			updateFixedSize();
			triggerEvent("load", {
				event,
				info,
				detail: {
					width: imgRef.value?.naturalWidth || imgRef.value?.width,
					height: imgRef.value?.naturalHeight || imgRef.value?.height
				}
			});
		}
		function updateFixedSize() {
			const image = imgRef.value;
			const container = conRef.value;
			if (!image?.naturalWidth || !image?.naturalHeight || !container) return;
			const ratio = image.naturalWidth / image.naturalHeight;
			if (props.mode === "widthFix") container.style.height = `${container.clientWidth / ratio}px`;
			else if (props.mode === "heightFix") container.style.width = `${container.clientHeight * ratio}px`;
		}
		function applyModeSize() {
			if (!conRef.value) return;
			conRef.value.style.width = props.mode === "heightFix" ? "auto" : originalWidth;
			conRef.value.style.height = props.mode === "widthFix" ? "auto" : originalHeight;
			nextTick(updateFixedSize);
		}
		watch(() => props.mode, applyModeSize);
		function checkCompletedImage() {
			const img = imgRef.value;
			if (!img || !props.src || !img.complete || img.naturalWidth <= 0 || lastCompletedSrc === props.src) return;
			handleLoaded(new Event("load"));
		}
		function handleError(event) {
			triggerEvent("error", {
				event,
				info,
				detail: { errMsg: props.src }
			});
		}
		function handleContextMenu(event) {
			if (!props.showMenuByLongpress) event.preventDefault();
		}
		if (hasEvent(info, "tap")) useTapEvents(conRef, (event) => {
			triggerEvent("tap", {
				event,
				info
			});
		});
		if (hasEvent(info, "touchstart") || hasEvent(info, "touchmove") || hasEvent(info, "touchend") || hasEvent(info, "touchcancel") || hasEvent(info, "longpress") || hasEvent(info, "longtap")) useTouchEvents(info, conRef);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", mergeProps({
				ref_key: "conRef",
				ref: conRef
			}, _ctx.$attrs, {
				class: "dd-image",
				style: unref(backgroundStyle),
				onContextmenu: handleContextMenu
			}), [createBaseVNode("img", {
				ref_key: "imgRef",
				ref: imgRef,
				class: normalizeClass([unref(dynamicClass), { "dd-image-preloader": __props.renderingMode === "backgroundImage" }]),
				src: unref(renderedSrc),
				alt: "",
				decoding: "async",
				loading: props.lazyLoad ? "lazy" : "eager",
				referrerpolicy: __props.referrerPolicy,
				onLoad: handleLoaded,
				onError: handleError
			}, null, 42, _hoisted_1$21)], 16);
		};
	}
};
var _sfc_main$33 = {
	__name: "CoverImage",
	props: {
		src: {
			type: String,
			default: ""
		},
		referrerPolicy: {
			type: String,
			default: "no-referrer"
		}
	},
	setup(__props) {
		const props = __props;
		useInfo();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(_sfc_main$34, mergeProps(_ctx.$attrs, {
				src: props.src,
				"referrer-policy": props.referrerPolicy
			}), null, 16, ["src", "referrer-policy"]);
		};
	}
};
var cover_image_exports = /* @__PURE__ */ __exportAll({ default: () => cover_image_default });
var cover_image_default = withInstall(_sfc_main$33);
function useNativeEvents(info, elementRef, eventTypes) {
	const activeEventTypes = eventTypes.filter((type) => hasEvent(info, type));
	if (!activeEventTypes.length) return;
	const handlers = /* @__PURE__ */ new Map();
	onMounted(() => {
		const el = elementRef.value;
		if (!el) return;
		activeEventTypes.forEach((type) => {
			const handler = (event) => triggerEvent(type, {
				event,
				info
			});
			handlers.set(type, handler);
			el.addEventListener(type, handler);
		});
	});
	onUnmounted(() => {
		const el = elementRef.value;
		if (!el) return;
		handlers.forEach((handler, type) => {
			el.removeEventListener(type, handler);
		});
		handlers.clear();
	});
}
var _hoisted_1$20 = ["data-session-from"];
var _sfc_main$32 = {
	__name: "View",
	props: {
		inline: {
			type: Boolean,
			default: false
		},
		hover: {
			type: Boolean,
			default: false
		},
		sessionFrom: {
			type: String,
			default: "wxapp"
		},
		hoverClass: {
			type: String,
			default: "none"
		},
		hoverStopPropagation: {
			type: Boolean,
			default: false
		},
		hoverStartTime: {
			type: Number,
			default: 50
		},
		hoverStayTime: {
			type: Number,
			default: 400
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		const viewRef = /* @__PURE__ */ ref(null);
		if (hasEvent(info, "tap")) useTapEvents(viewRef, (event) => {
			triggerEvent("tap", {
				event,
				info
			});
		});
		if (hasEvent(info, "touchstart") || hasEvent(info, "touchmove") || hasEvent(info, "touchend") || hasEvent(info, "touchcancel") || hasEvent(info, "longpress") || hasEvent(info, "longtap")) useTouchEvents(info, viewRef);
		useNativeEvents(info, viewRef, ["transitionend", "animationend"]);
		const { isHover, onHoverCancel, onHoverEnd, onHoverStart } = useHover(props);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				ref_key: "viewRef",
				ref: viewRef
			}, _ctx.$attrs, {
				class: ["dd-view", unref(isHover) ? __props.hoverClass : void 0],
				style: __props.inline ? { display: "inline" } : void 0,
				"data-session-from": __props.sessionFrom,
				onTouchstart: _cache[0] || (_cache[0] = (...args) => unref(onHoverStart) && unref(onHoverStart)(...args)),
				onTouchend: _cache[1] || (_cache[1] = (...args) => unref(onHoverEnd) && unref(onHoverEnd)(...args)),
				onTouchcancel: _cache[2] || (_cache[2] = (...args) => unref(onHoverCancel) && unref(onHoverCancel)(...args)),
				onMousedown: _cache[3] || (_cache[3] = (...args) => unref(onHoverStart) && unref(onHoverStart)(...args)),
				onMouseup: _cache[4] || (_cache[4] = (...args) => unref(onHoverEnd) && unref(onHoverEnd)(...args)),
				onMouseleave: _cache[5] || (_cache[5] = (...args) => unref(onHoverCancel) && unref(onHoverCancel)(...args))
			}), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_1$20);
		};
	}
};
var _sfc_main$31 = {
	__name: "CoverView",
	props: {
		scrollTop: { type: [Number, String] },
		scrollLeft: { type: [Number, String] },
		markerId: { type: [Number, String] },
		hoverClass: {
			type: String,
			default: "none"
		},
		hover: {
			type: Boolean,
			default: false
		},
		hoverStopPropagation: {
			type: Boolean,
			default: false
		},
		hoverStartTime: {
			type: Number,
			default: 50
		},
		hoverStayTime: {
			type: Number,
			default: 400
		}
	},
	setup(__props) {
		const props = __props;
		const viewRef = /* @__PURE__ */ ref(null);
		watch([() => props.scrollTop, () => props.scrollLeft], ([top, left]) => {
			const element = viewRef.value?.$el;
			if (!element) return;
			if (top !== void 0) element.scrollTop = Number(top) || 0;
			if (left !== void 0) element.scrollLeft = Number(left) || 0;
		}, {
			flush: "post",
			immediate: true
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(_sfc_main$32, mergeProps({
				ref_key: "viewRef",
				ref: viewRef
			}, _ctx.$attrs, {
				"marker-id": __props.markerId,
				hover: __props.hover,
				"hover-class": __props.hoverClass,
				"hover-stop-propagation": __props.hoverStopPropagation,
				"hover-start-time": __props.hoverStartTime,
				"hover-stay-time": __props.hoverStayTime
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, [
				"marker-id",
				"hover",
				"hover-class",
				"hover-stop-propagation",
				"hover-start-time",
				"hover-stay-time"
			]);
		};
	}
};
var cover_view_exports = /* @__PURE__ */ __exportAll({ default: () => cover_view_default });
var cover_view_default = withInstall(_sfc_main$31);
var _sfc_main$30 = {
	__name: "Form",
	props: {
		/**
		* 是否返回 formId 用于发送模板消息
		*/
		reportSubmit: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 等待一段时间（毫秒数）以确认 formId 是否生效。
		* 如果未指定这个参数，formId 有很小的概率是无效的（如遇到网络失败的情况）。
		* 指定这个参数将可以检测 formId 是否有效，以这个参数的时间作为这项检测的超时时间。
		* 如果失败，将返回 requestFormId:fail 开头的 formId
		*/
		reportSubmitTimeout: {
			type: Number,
			default: 0,
			required: false
		}
	},
	setup(__props) {
		const formValues = /* @__PURE__ */ ref({});
		const formControls = /* @__PURE__ */ new Set();
		function collectFormValue(name, value) {
			if (name) formValues.value[name] = value;
		}
		function registerFormControl(control) {
			formControls.add(control);
			return () => formControls.delete(control);
		}
		function readFormValues() {
			const values = { .../* @__PURE__ */ toRaw(formValues.value) };
			for (const control of formControls) {
				const name = control.getName?.();
				if (name) values[name] = control.getValue?.();
			}
			return values;
		}
		provide("collectFormValue", collectFormValue);
		provide("registerFormControl", registerFormControl);
		const info = useInfo();
		function handleEvent(event, formType) {
			event.stopPropagation();
			if (formType === "submit") triggerEvent("submit", {
				event,
				info,
				detail: { value: readFormValues() }
			});
			else if (formType === "reset") {
				for (const control of formControls) control.reset?.();
				formValues.value = {};
				triggerEvent("reset", {
					event,
					info
				});
			}
		}
		provide("formEvent", handleEvent);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", normalizeProps(guardReactiveProps(_ctx.$attrs)), [renderSlot(_ctx.$slots, "default")], 16);
		};
	}
};
var form_exports = /* @__PURE__ */ __exportAll({ default: () => form_default });
var form_default = withInstall(_sfc_main$30);
var _hoisted_1$19 = ["title"];
var _sfc_main$29 = {
	__name: "Icon",
	props: {
		/**
		* icon的类型
		* 合法值 success, success_no_circle, info, warn, waiting, cancel,
		* download, search, clear, circle
		*/
		type: {
			type: String,
			required: true
		},
		/**
		* icon的大小，单位默认为px，支持传入单位(rpx/px/rem)
		*/
		size: {
			type: [Number, String],
			default: 23
		},
		/**
		* icon的颜色，同css的color
		*/
		color: { type: String }
	},
	setup(__props) {
		useCssVars((_ctx) => ({
			"c819827a": unref(iSize),
			"v3cd4ae3e": unref(iColor)
		}));
		const props = __props;
		const iClass = computed(() => {
			switch (props.type) {
				case "success": return "dd-icon-success";
				case "success_circle": return "dd-icon-success_circle";
				case "success_no_circle": return "dd-icon-success_no_circle";
				case "info": return "dd-icon-info";
				case "info_circle": return "dd-icon-info_circle";
				case "warn": return "dd-icon-warn";
				case "waiting": return "dd-icon-waiting";
				case "cancel": return "dd-icon-cancel";
				case "download": return "dd-icon-download";
				case "search": return "dd-icon-search";
				case "clear": return "dd-icon-clear";
				case "circle": return "dd-icon-circle";
				default: return "dd-icon-success";
			}
		});
		const iTitle = computed(() => {
			switch (props.type) {
				case "success":
				case "success_circle":
				case "success_no_circle": return "成功";
				case "info":
				case "info_circle": return "信息";
				case "warn": return "警告";
				case "waiting": return "等待";
				case "cancel": return "取消";
				case "download": return "下载";
				case "search": return "搜索";
				case "clear": return "清除";
				case "circle": return "空选";
				default: return "成功";
			}
		});
		const unit = /^-?(?:\d+|\d*\.\d+)(?:px|rem|em|vw|vh|%)$/;
		const iSize = computed(() => {
			let size;
			if (!props.size) size = "23px";
			else size = transformRpx(props.size);
			if (!unit.test(size)) size += "px";
			return size;
		});
		const iColor = computed(() => {
			return props.color || "initial";
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("i", mergeProps(_ctx.$attrs, {
				title: unref(iTitle),
				class: ["dd-icon", unref(iClass)]
			}), null, 16, _hoisted_1$19);
		};
	}
};
var icon_exports = /* @__PURE__ */ __exportAll({ default: () => icon_default });
var icon_default = withInstall(_sfc_main$29);
var image_exports = /* @__PURE__ */ __exportAll({ default: () => image_default });
var image_default = withInstall(_sfc_main$34);
/**
* Web approximation of the mini-program keyboardheightchange event. Native
* containers can still deliver their own exact keyboard animation duration.
*/
function useKeyboardHeight(info, active) {
	if (!hasEvent(info, "keyboardheightchange")) return;
	let layoutHeight = 0;
	let lastHeight = 0;
	function emitHeight(height) {
		const nextHeight = Math.max(Math.round(height), 0);
		if (nextHeight === lastHeight) return;
		lastHeight = nextHeight;
		triggerEvent("keyboardheightchange", {
			info,
			detail: {
				height: nextHeight,
				duration: 0
			}
		});
	}
	function handleViewportResize() {
		if (!active.value) return;
		const viewport = window.visualViewport;
		const visibleBottom = viewport ? viewport.height + viewport.offsetTop : window.innerHeight;
		emitHeight(layoutHeight - visibleBottom);
	}
	onMounted(() => {
		layoutHeight = Math.max(window.innerHeight, document.documentElement.clientHeight);
		window.visualViewport?.addEventListener("resize", handleViewportResize);
		window.addEventListener("resize", handleViewportResize);
	});
	watch(active, (focused) => {
		if (focused) handleViewportResize();
		else emitHeight(0);
	});
	onBeforeUnmount(() => {
		window.visualViewport?.removeEventListener("resize", handleViewportResize);
		window.removeEventListener("resize", handleViewportResize);
	});
}
var _hoisted_1$18 = [
	"id",
	"type",
	"inputmode",
	"maxlength",
	"value",
	"disabled",
	"autocomplete"
];
var _sfc_main$28 = {
	__name: "Input",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* name，为表单使用
		*/
		name: { type: String },
		/**
		* 输入框的初始内容
		*/
		value: {
			type: String,
			default: ""
		},
		/**
		* input 的类型
		* 合法值: text, number, idcard, digit, safe-password, nickname
		*/
		type: {
			type: String,
			default: "text",
			validator: (value) => {
				return [
					"text",
					"number",
					"idcard",
					"digit",
					"safe-password",
					"nickname"
				].includes(value);
			}
		},
		/**
		* 是否是密码类型
		*/
		password: {
			type: Boolean,
			default: false
		},
		/**
		* 输入框为空时占位符
		*/
		placeholder: {
			type: String,
			default: ""
		},
		/**
		* 指定 placeholder 的样式，目前仅支持color,font-size和font-weight
		*/
		placeholderStyle: {
			type: [String, Object],
			default() {
				return {};
			}
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false
		},
		/**
		* 最大输入长度，设置为 -1 的时候不限制最大长度
		*/
		maxlength: {
			type: [Number, String],
			default: 140
		},
		/**
		* 指定光标与键盘的距离，取 input 距离底部的距离和 cursor-spacing 指定的距离的最小值作为光标与键盘的距离
		*/
		cursorSpacing: {
			type: Number,
			default: 0
		},
		/**
		* (即将废弃，请直接使用 focus )自动聚焦，拉起键盘
		*/
		autoFocus: {
			type: Boolean,
			default: false
		},
		/**
		* 获取焦点
		*/
		focus: {
			type: Boolean,
			default: false
		},
		/**
		* 设置键盘右下角按钮的文字，仅在type='text'时生效
		* 合法值: send, search, next, go, done
		*/
		confirmType: {
			type: String,
			default: "done",
			validator: (value) => {
				return [
					"send",
					"search",
					"next",
					"go",
					"done"
				].includes(value);
			}
		},
		/**
		* 强制 input 处于同层状态，默认 focus 时 input 会切到非同层状态 (仅在 iOS 下生效)
		*/
		alwaysEmbed: {
			type: Boolean,
			default: false
		},
		/**
		* 点击键盘右下角按钮时是否保持键盘不收起
		*/
		confirmHold: {
			type: Boolean,
			default: false
		},
		/**
		* 指定focus时的光标位置
		*/
		cursor: { type: Number },
		/**
		* 光标颜色。iOS 下的格式为十六进制颜色值 #000000，安卓下的只支持 default 和 green
		*/
		cursorColor: { type: String },
		/**
		* 光标起始位置，自动聚集时有效，需与selection-end搭配使用
		*/
		selectionStart: {
			type: Number,
			default: -1
		},
		selectionEnd: {
			type: Number,
			default: -1
		},
		/**
		* 键盘弹起时，是否自动上推页面
		*/
		adjustPosition: {
			type: Boolean,
			default: true
		},
		/**
		* focus时，点击页面的时候不收起键盘
		*/
		holdKeyboard: {
			type: Boolean,
			default: false
		},
		/**
		* WebView 特有属性
		* 指定 placeholder 的样式类，目前仅支持color,font-size和font-weight
		*/
		placeholderClass: {
			type: String,
			default: "input-placeholder"
		},
		keyboardAppearance: {
			type: String,
			default: "default"
		},
		dropdownStyle: {
			type: Object,
			default: () => ({})
		},
		autoFill: {
			type: String,
			default: ""
		},
		safePasswordCertPath: {
			type: String,
			default: null
		},
		safePasswordTimeStamp: {
			type: Number,
			default: null
		},
		safePasswordNonce: {
			type: Number,
			default: null
		},
		safePasswordSalt: {
			type: String,
			default: null
		},
		safePasswordCustomHash: { type: String },
		safePasswordLength: {
			type: Number,
			default: 6
		}
	},
	emits: ["update:value"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const wrapperClass = computed(() => {
			return {
				"dd-input-wrapper": true,
				"dd-input-disabled": props.disabled
			};
		});
		const inputType = computed(() => {
			if (props.password || props.type === "safe-password") return "password";
			return props.type === "number" || props.type === "digit" ? "text" : props.type;
		});
		const inputMode = computed(() => {
			switch (props.type) {
				case "number": return "numeric";
				case "digit": return "decimal";
				default: return "text";
			}
		});
		const computedPlaceholderStyle = computed(() => {
			const placeholderColor = () => {
				if (typeof props.placeholderStyle === "string") {
					const match = props.placeholderStyle.match(/color:([^;]+)/);
					if (match) return match[1].trim();
				} else if (props.placeholderStyle && typeof props.placeholderStyle === "object") {
					if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "color")) return props.placeholderStyle.color;
				}
				return "rgba(0,0,0,.3)";
			};
			const placeholderFontSize = () => {
				let size;
				if (typeof props.placeholderStyle === "string") {
					const match = props.placeholderStyle.match(/font-size:([^;]+)/);
					if (match) size = match[1].trim();
				} else if (props.placeholderStyle && typeof props.placeholderStyle === "object") {
					if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-size")) size = props.placeholderStyle["font-size"];
				}
				return size ? transformRpx(size) : "inherit";
			};
			const placeholderFontWeight = () => {
				if (typeof props.placeholderStyle === "string") {
					const match = props.placeholderStyle.match(/font-weight:([^;]+)/);
					if (match) return match[1].trim();
				} else if (props.placeholderStyle && typeof props.placeholderStyle === "object") {
					if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-weight")) return props.placeholderStyle["font-weight"];
				}
				return "inherit";
			};
			return {
				color: placeholderColor(),
				fontSize: placeholderFontSize(),
				fontWeight: placeholderFontWeight()
			};
		});
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		collectFormValue?.(props.name, props.value);
		const iValue = /* @__PURE__ */ ref(props.value);
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue: () => iValue.value,
			reset: () => {
				iValue.value = "";
				collectFormValue?.(props.name, iValue.value);
			}
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		const placeholderShow = computed(() => {
			return iValue.value === void 0 || iValue.value === null || iValue.value === "" || typeof iValue.value === "string" && iValue.value.length === 0;
		});
		const inputRef = /* @__PURE__ */ ref(null);
		const keyCode = /* @__PURE__ */ ref(null);
		const vFocus = { mounted: (el) => {
			if (!props.autoFocus && !props.focus) return;
			el.focus();
			applySelection(el);
		} };
		function applySelection(element = inputRef.value) {
			if (!element?.setSelectionRange) return;
			const cursor = Number(props.cursor);
			const start = cursor >= 0 ? cursor : Number(props.selectionStart);
			const end = cursor >= 0 ? cursor : Number(props.selectionEnd);
			if (start >= 0) element.setSelectionRange(start, end >= 0 ? end : start);
		}
		watch([() => props.focus, () => props.value], ([nF, nV], [, preV]) => {
			if (nF) {
				inputRef.value.focus();
				applySelection();
			}
			if (preV !== nV) iValue.value = nV;
		});
		const wrapperRef = /* @__PURE__ */ ref(null);
		const info = useInfo();
		const keyboardAccessoryVisible = /* @__PURE__ */ ref(false);
		provide("keyboardAccessoryVisible", keyboardAccessoryVisible);
		useKeyboardHeight(info, keyboardAccessoryVisible);
		function handleKeydown(event) {
			keyCode.value = event.keyCode;
			if (event.keyCode === 13) {
				if (!props.confirmHold) event.target.blur();
				triggerEvent("confirm", {
					event,
					info,
					detail: { value: event.target.value }
				});
			}
		}
		function handleWrapperEvent(event) {
			if (event.target.tagName.toLowerCase() !== "input") return;
			const value = event.target.value;
			switch (event.type) {
				case "input":
					collectFormValue?.(props.name, value);
					iValue.value = value;
					emit("update:value", value);
					triggerEvent("input", {
						event,
						info,
						detail: {
							value,
							cursor: event.target.selectionEnd,
							keyCode: keyCode.value
						},
						success: (data) => {
							iValue.value = data.value ?? data;
							emit("update:value", data.value ?? data);
						}
					});
					break;
				case "focusin":
					keyboardAccessoryVisible.value = true;
					applySelection(event.target);
					triggerEvent("focus", {
						event,
						info,
						detail: { value }
					});
					if (!isDesktop && props.adjustPosition) {
						const element = wrapperRef.value;
						if (!element) return;
						const bottom = getActualBottom(element, true);
						invokeAPI("adjustPosition", {
							bridgeId: info.bridgeId,
							params: { bottom }
						});
					}
					break;
				case "focusout":
					keyboardAccessoryVisible.value = false;
					triggerEvent("blur", {
						event,
						info,
						detail: {
							value,
							cursor: event.target.selectionEnd
						}
					});
					break;
				case "change":
					triggerEvent("change", {
						event,
						info,
						detail: { value }
					});
					break;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				ref_key: "wrapperRef",
				ref: wrapperRef
			}, _ctx.$attrs, {
				class: unref(wrapperClass),
				role: "textbox",
				"data-dd-label-target": "",
				onInput: handleWrapperEvent,
				onFocusin: handleWrapperEvent,
				onFocusout: handleWrapperEvent,
				onChange: handleWrapperEvent
			}), [
				withDirectives(createBaseVNode("input", {
					id: __props.id,
					ref_key: "inputRef",
					ref: inputRef,
					class: "dd-input",
					type: unref(inputType),
					inputmode: unref(inputMode),
					maxlength: __props.maxlength,
					value: unref(iValue),
					disabled: __props.disabled,
					autocomplete: __props.autoFill || void 0,
					onKeydown: handleKeydown
				}, null, 40, _hoisted_1$18), [[vFocus]]),
				withDirectives(createBaseVNode("div", {
					class: normalizeClass(["dd-input-placeholder", __props.placeholderClass]),
					style: normalizeStyle(unref(computedPlaceholderStyle))
				}, toDisplayString(__props.placeholder), 7), [[vShow, unref(placeholderShow)]]),
				renderSlot(_ctx.$slots, "default")
			], 16);
		};
	}
};
var input_exports = /* @__PURE__ */ __exportAll({ default: () => input_default });
var input_default = withInstall(_sfc_main$28);
var _sfc_main$27 = {
	__name: "KeyboardAccessory",
	props: { maxHeight: {
		type: Number,
		default: 200
	} },
	setup(__props) {
		const props = __props;
		const inputFocused = inject("keyboardAccessoryVisible", /* @__PURE__ */ ref(false));
		const visible = computed(() => inputFocused.value && window.innerWidth <= window.innerHeight);
		const accessoryStyle = computed(() => ({
			bottom: 0,
			left: 0,
			maxHeight: `${props.maxHeight}px`,
			pointerEvents: visible.value ? "auto" : "none",
			position: "fixed",
			visibility: visible.value ? "visible" : "hidden",
			width: "100%",
			zIndex: visible.value ? 1 : -1
		}));
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Teleport, { to: "body" }, [createBaseVNode("div", mergeProps(_ctx.$attrs, {
				class: "dd-keyboard-accessory",
				style: unref(accessoryStyle)
			}), [renderSlot(_ctx.$slots, "default")], 16)]);
		};
	}
};
var keyboard_accessory_exports = /* @__PURE__ */ __exportAll({ default: () => keyboard_accessory_default });
var keyboard_accessory_default = withInstall(_sfc_main$27);
var _hoisted_1$17 = ["for"];
var targetSelector = "[data-dd-label-target], input, textarea";
var _sfc_main$26 = {
	__name: "Label",
	props: { 
	/**
	* 绑定控件的 id
	*/
for: { type: String } },
	setup(__props) {
		const props = __props;
		const labelRef = /* @__PURE__ */ ref(null);
		function isLabelTarget(element) {
			return element instanceof Element && Boolean(element.closest(targetSelector));
		}
		function findTarget() {
			if (props.for) return document.getElementById(props.for);
			return labelRef.value?.querySelector(targetSelector);
		}
		function handleClick(event) {
			if (isLabelTarget(event.target)) return;
			const target = findTarget();
			if (!target || target === labelRef.value) return;
			if (props.for && target.matches("input, textarea, button, select")) return;
			event.preventDefault();
			target.click();
			if (target.matches("input, textarea")) target.focus();
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("label", mergeProps({
				ref_key: "labelRef",
				ref: labelRef
			}, _ctx.$attrs, {
				for: props.for,
				onClick: handleClick
			}), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_1$17);
		};
	}
};
var label_exports = /* @__PURE__ */ __exportAll({ default: () => label_default });
var label_default = withInstall(_sfc_main$26);
var _hoisted_1$16 = ["id"];
var _hoisted_2$8 = {
	key: 0,
	class: "dd-map-desktop"
};
var _hoisted_3$4 = {
	key: 1,
	class: "dd-map-native dd-map-container"
};
var _hoisted_4$3 = ["data-dimina-native-id"];
var _hoisted_5$1 = {
	key: 4,
	class: "dd-map-desktop"
};
var _hoisted_6$1 = { class: "dd-map-slot" };
var type$2 = "native/map";
var _sfc_main$25 = {
	__name: "Map",
	props: {
		id: {
			type: String,
			default: () => `map-${useId()}`
		},
		latitude: {
			type: Number,
			default: 39.92
		},
		longitude: {
			type: Number,
			default: 116.46
		},
		scale: {
			type: Number,
			default: 16
		},
		markers: {
			type: Array,
			default: () => []
		},
		covers: {
			type: Array,
			default: () => []
		},
		includePoints: {
			type: Array,
			default: () => []
		},
		polyline: {
			type: Array,
			default: () => []
		},
		circles: {
			type: Array,
			default: () => []
		},
		controls: {
			type: Array,
			default: () => []
		},
		polygons: {
			type: Array,
			default: () => []
		},
		showLocation: {
			type: Boolean,
			default: false
		},
		showScale: {
			type: Boolean,
			default: false
		},
		showCompass: {
			type: Boolean,
			default: false
		},
		theme: {
			type: String,
			default: "normal"
		},
		subkey: {
			type: String,
			default: ""
		},
		layerStyle: {
			type: Number,
			default: 1
		},
		usePluginId: {
			type: Boolean,
			default: false
		},
		enableZoom: {
			type: Boolean,
			default: true
		},
		enableScroll: {
			type: Boolean,
			default: true
		},
		enableRotate: {
			type: Boolean,
			default: false
		},
		enable3D: {
			type: Boolean,
			default: false
		},
		enableOverlooking: {
			type: Boolean,
			default: false
		},
		enableAutoMaxOverlooking: {
			type: Boolean,
			default: false
		},
		enableSatellite: {
			type: Boolean,
			default: false
		},
		enableTraffic: {
			type: Boolean,
			default: false
		},
		enablePoi: {
			type: Boolean,
			default: true
		},
		enablePOI: {
			type: Boolean,
			default: void 0
		},
		enableBuilding: {
			type: Boolean,
			default: true
		},
		enableIndoor: {
			type: Boolean,
			default: false
		},
		enableIndoorBuildingPick: {
			type: Boolean,
			default: false
		},
		enableIndoorLevelPick: {
			type: Boolean,
			default: false
		},
		rotate: {
			type: Number,
			default: 0
		},
		skew: {
			type: Number,
			default: 0
		},
		minScale: {
			type: Number,
			default: 3
		},
		maxScale: {
			type: Number,
			default: 22
		},
		setting: {
			type: Object,
			default: () => ({})
		}
	},
	setup(__props) {
		const props = __props;
		const rootRef = /* @__PURE__ */ ref();
		const info = useInfo();
		const isNativeMap = computed(() => isAndroid || isIOS || isHarmonyOS);
		const nativeEventOffs = [];
		let resizeObserver;
		let syncFrameId = 0;
		let lastRectKey = "";
		let nativeMounted = false;
		function getRect() {
			if (!rootRef.value) return {};
			const rect = rootRef.value.getBoundingClientRect();
			return {
				left: rect.left,
				top: rect.top,
				width: rect.width,
				height: rect.height,
				pageLeft: rect.left + window.scrollX,
				pageTop: rect.top + window.scrollY,
				scrollX: window.scrollX,
				scrollY: window.scrollY,
				viewportWidth: window.innerWidth,
				viewportHeight: window.innerHeight
			};
		}
		function getNativeParams() {
			const enablePoi = props.enablePOI === void 0 ? props.enablePoi : props.enablePOI;
			return {
				latitude: props.latitude,
				longitude: props.longitude,
				scale: props.scale,
				markers: props.markers,
				covers: props.covers,
				includePoints: props.includePoints,
				polyline: props.polyline,
				circles: props.circles,
				controls: props.controls,
				polygons: props.polygons,
				showLocation: props.showLocation,
				showScale: props.showScale,
				showCompass: props.showCompass,
				theme: props.theme,
				subkey: props.subkey,
				layerStyle: props.layerStyle,
				usePluginId: props.usePluginId,
				enableZoom: props.enableZoom,
				enableScroll: props.enableScroll,
				enableRotate: props.enableRotate,
				enable3D: props.enable3D,
				enableOverlooking: props.enableOverlooking,
				enableAutoMaxOverlooking: props.enableAutoMaxOverlooking,
				enableSatellite: props.enableSatellite,
				enableTraffic: props.enableTraffic,
				enablePoi,
				enablePOI: enablePoi,
				enableBuilding: props.enableBuilding,
				enableIndoor: props.enableIndoor,
				enableIndoorBuildingPick: props.enableIndoorBuildingPick,
				enableIndoorLevelPick: props.enableIndoorLevelPick,
				rotate: props.rotate,
				skew: props.skew,
				minScale: props.minScale,
				maxScale: props.maxScale,
				setting: props.setting,
				...props.setting,
				type: type$2,
				id: props.id,
				hidden: rootRef.value?.hasAttribute("hidden") || false,
				rect: getRect()
			};
		}
		function invokeNative(apiName) {
			if (!isNativeMap.value) return;
			if (apiName === "propsUpdate" && !nativeMounted) return;
			invokeAPI(apiName, {
				bridgeId: info.bridgeId,
				params: getNativeParams()
			});
		}
		function bindNativeEvent(nativeEvent, eventType) {
			const off = onEvent(nativeEvent, (msg) => {
				if (msg.id !== void 0 && msg.id !== props.id && msg.mapId !== props.id) return;
				triggerEvent(eventType, {
					type: eventType,
					info,
					detail: msg
				});
			});
			nativeEventOffs.push(off);
		}
		function syncRect(force = false) {
			const rectKey = JSON.stringify({
				...getRect(),
				hidden: rootRef.value?.hasAttribute("hidden") || false
			});
			if (force || rectKey !== lastRectKey) {
				lastRectKey = rectKey;
				invokeNative("propsUpdate");
			}
		}
		function scheduleSyncRect() {
			if (syncFrameId) return;
			syncFrameId = requestAnimationFrame(() => {
				syncFrameId = 0;
				syncRect();
			});
		}
		onMounted(() => {
			if (!isNativeMap.value) return;
			if (isAndroid) ensureNativeLayerTouchBridge();
			for (const eventType of [
				"callouttap",
				"markertap",
				"labeltap",
				"controltap",
				"regionchange",
				"tap",
				"indoorchange",
				"poitap",
				"anchorpointtap",
				"updated",
				"rendersuccess",
				"error"
			]) bindNativeEvent(`bind${eventType}`, eventType);
			nextTick(() => {
				nativeMounted = true;
				invokeNative("componentMount");
				lastRectKey = JSON.stringify({
					...getRect(),
					hidden: rootRef.value?.hasAttribute("hidden") || false
				});
				window.addEventListener("resize", scheduleSyncRect);
				window.addEventListener("scroll", scheduleSyncRect, true);
				if (window.ResizeObserver && rootRef.value) {
					resizeObserver = new ResizeObserver(scheduleSyncRect);
					resizeObserver.observe(rootRef.value);
				}
			});
		});
		watch(() => getNativeParams(), () => invokeNative("propsUpdate"), { deep: true });
		onBeforeUnmount(() => {
			if (syncFrameId) cancelAnimationFrame(syncFrameId);
			resizeObserver?.disconnect();
			window.removeEventListener("resize", scheduleSyncRect);
			window.removeEventListener("scroll", scheduleSyncRect, true);
			invokeNative("componentUnmount");
			nativeMounted = false;
			nativeEventOffs.splice(0).forEach((off) => off());
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef
			}, _ctx.$attrs, { class: "dd-map" }), [unref(isDesktop) ? (openBlock(), createElementBlock("div", _hoisted_2$8, "未实现组件")) : unref(isIOS) ? (openBlock(), createElementBlock("div", _hoisted_3$4, [..._cache[0] || (_cache[0] = [createBaseVNode("div", null, null, -1)])])) : unref(isAndroid) ? (openBlock(), createElementBlock("embed", {
				key: 2,
				class: "dd-map-native",
				type: "application/view",
				comp_type: type$2,
				"data-dimina-native-type": "native/map",
				"data-dimina-native-id": __props.id
			}, null, 8, _hoisted_4$3)) : unref(isHarmonyOS) ? (openBlock(), createElementBlock("embed", {
				key: 3,
				class: "dd-map-native",
				type: type$2
			})) : (openBlock(), createElementBlock("div", _hoisted_5$1, "未实现组件")), createBaseVNode("div", _hoisted_6$1, [renderSlot(_ctx.$slots, "default")])], 16, _hoisted_1$16);
		};
	}
};
var map_exports = /* @__PURE__ */ __exportAll({ default: () => map_default });
var map_default = withInstall(_sfc_main$25);
var _sfc_main$24 = {
	__name: "MovableArea",
	props: { 
	/**
	* 当里面的movable-view设置为支持双指缩放时，设置此值可将缩放手势生效区域修改为整个movable-area
	*/
scaleArea: {
		type: Boolean,
		default: false,
		require: false
	} },
	setup(__props) {
		const props = __props;
		const info = useInfo();
		const movableViews = /* @__PURE__ */ new Set();
		provide("registerMovableView", (handlers) => {
			movableViews.add(handlers);
			return () => movableViews.delete(handlers);
		});
		function handleScaleGesture(event, phase) {
			if (!props.scaleArea || event.target.closest?.(".dd-movable-view")) return;
			if (phase !== "end" && event.touches?.length < 2) return;
			for (const handlers of movableViews) handlers[phase]?.(event);
		}
		function onClicked(event) {
			triggerEvent("tap", {
				event,
				info
			});
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
				class: "dd-movable-area",
				onClick: onClicked,
				onTouchstart: _cache[0] || (_cache[0] = ($event) => handleScaleGesture($event, "start")),
				onTouchmove: _cache[1] || (_cache[1] = ($event) => handleScaleGesture($event, "move")),
				onTouchend: _cache[2] || (_cache[2] = ($event) => handleScaleGesture($event, "end")),
				onTouchcancel: _cache[3] || (_cache[3] = ($event) => handleScaleGesture($event, "end"))
			}), [renderSlot(_ctx.$slots, "default")], 16);
		};
	}
};
var movable_area_exports = /* @__PURE__ */ __exportAll({ default: () => movable_area_default });
var movable_area_default = withInstall(_sfc_main$24);
var _sfc_main$23 = {
	__name: "MovableView",
	props: {
		/**
		* movable-view的移动方向，属性值有all、vertical、horizontal、none
		*/
		direction: {
			type: String,
			default: "none",
			required: false,
			validator: (value) => [
				"all",
				"vertical",
				"horizontal",
				"none"
			].includes(value)
		},
		/**
		* movable-view是否带有惯性
		*/
		inertia: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 超过可移动区域后，movable-view是否还可以移动
		*/
		outOfBounds: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 定义x轴方向的偏移，如果x的值不在可移动范围内，会自动移动到可移动范围；改变x的值会触发动画；单位支持px（默认）、暂不支持 rpx；
		*/
		x: {
			type: [Number, String],
			default: 0,
			required: false
		},
		/**
		* 定义y轴方向的偏移，如果y的值不在可移动范围内，会自动移动到可移动范围；改变y的值会触发动画；单位支持px（默认）、暂不支持 rpx；
		*/
		y: {
			type: [Number, String],
			default: 0,
			required: false
		},
		/**
		* 阻尼系数，用于控制x或y改变时的动画和过界回弹的动画
		*/
		damping: {
			type: Number,
			default: 20,
			required: false
		},
		/**
		* 摩擦系数，用于控制惯性滑动的动画
		*/
		friction: {
			type: Number,
			default: 2,
			required: false,
			validator: (value) => value > 0
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 是否支持双指缩放
		*/
		scale: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 定义缩放倍数最小值
		*/
		scaleMin: {
			type: Number,
			default: .5,
			required: false
		},
		/**
		* 定义缩放倍数最大值
		*/
		scaleMax: {
			type: Number,
			default: 10,
			required: false
		},
		/**
		* 定义缩放倍数
		*/
		scaleValue: {
			type: Number,
			default: 1,
			required: false,
			validator: (value) => value >= .5 && value <= 10
		},
		/**
		* 是否使用动画
		*/
		animation: {
			type: Boolean,
			default: true,
			required: false
		}
	},
	emits: ["update:x", "update:y"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const info = useInfo();
		const registerMovableView = inject("registerMovableView", void 0);
		const movableView = /* @__PURE__ */ ref(null);
		const movableViewContent = /* @__PURE__ */ ref(null);
		let startX = 0;
		let startY = 0;
		function parseCoordinate(value) {
			const parsed = Number.parseFloat(value);
			return Number.isFinite(parsed) ? parsed : 0;
		}
		const currentX = /* @__PURE__ */ ref(parseCoordinate(props.x));
		const currentY = /* @__PURE__ */ ref(parseCoordinate(props.y));
		const currentScale = /* @__PURE__ */ ref(Math.min(Math.max(props.scaleValue, props.scaleMin, .5), props.scaleMax, 10));
		const duration = /* @__PURE__ */ ref(props.animation ? "0.5s" : "0s");
		let isDragging = false;
		let isScaling = false;
		let isUpdatingFromDrag = false;
		let parentRect = {
			width: 0,
			height: 0
		};
		let childRect = {
			width: 0,
			height: 0
		};
		let rafId = null;
		let startDistance = 0;
		let startScale = 1;
		let lastPointerX = 0;
		let lastPointerY = 0;
		let lastPointerTime = 0;
		let velocityX = 0;
		let velocityY = 0;
		let resizeObserver = null;
		let unregisterMovableView;
		onMounted(() => {
			unregisterMovableView = registerMovableView?.({
				start: startDrag,
				move: drag,
				end: endDrag
			});
			resizeObserver = new ResizeObserver(() => {
				requestAnimationFrame(() => {
					updateRects();
				});
			});
			if (movableView.value && movableView.value.parentElement) {
				resizeObserver.observe(movableView.value.parentElement);
				resizeObserver.observe(movableViewContent.value);
			}
			nextTick(() => {
				updateRects();
				duration.value = "0s";
				const { x: constrainedX, y: constrainedY } = constrainPosition(currentX.value, currentY.value);
				currentX.value = constrainedX;
				currentY.value = constrainedY;
			});
		});
		onUnmounted(() => {
			unregisterMovableView?.();
			if (resizeObserver) {
				resizeObserver.disconnect();
				resizeObserver = null;
			}
			if (rafId) {
				cancelAnimationFrame(rafId);
				rafId = null;
			}
		});
		function updateRects() {
			parentRect = movableView.value.parentElement.getBoundingClientRect();
			childRect = {
				width: movableViewContent.value.offsetWidth,
				height: movableViewContent.value.offsetHeight
			};
			if (parentRect.width >= childRect.width) parentRect.x;
			else parentRect.x;
			if (parentRect.height >= childRect.height) parentRect.y;
			else parentRect.y;
		}
		function constrainPosition(x, y) {
			if (!parentRect || !childRect) return {
				x,
				y
			};
			let constrainedX = x;
			let constrainedY = y;
			if (parentRect.width >= childRect.width) constrainedX = Math.min(Math.max(x, 0), parentRect.width - childRect.width);
			else constrainedX = Math.min(Math.max(x, parentRect.width - childRect.width), 0);
			if (parentRect.height >= childRect.height) constrainedY = Math.min(Math.max(y, 0), parentRect.height - childRect.height);
			else constrainedY = Math.min(Math.max(y, parentRect.height - childRect.height), 0);
			return {
				x: constrainedX,
				y: constrainedY
			};
		}
		function startDrag(event) {
			if (props.disabled) {
				triggerEvent("touchstart", {
					event,
					info
				});
				return;
			}
			duration.value = "0s";
			if (props.scale && event.touches?.length >= 2) {
				const [first, second] = event.touches;
				startDistance = Math.hypot(second.clientX - first.clientX, second.clientY - first.clientY);
				startScale = currentScale.value;
				isScaling = true;
				isDragging = false;
				triggerEvent("touchstart", {
					event,
					info
				});
				return;
			}
			isDragging = true;
			const pointer = event.touches ? event.touches[0] : event;
			startX = pointer.clientX - currentX.value;
			startY = pointer.clientY - currentY.value;
			lastPointerX = pointer.clientX;
			lastPointerY = pointer.clientY;
			lastPointerTime = event.timeStamp || performance.now();
			velocityX = 0;
			velocityY = 0;
			triggerEvent("touchstart", {
				event,
				info
			});
		}
		function drag(event) {
			if (isScaling && event.touches?.length >= 2) {
				if (event.cancelable) event.preventDefault();
				const [first, second] = event.touches;
				const distance = Math.hypot(second.clientX - first.clientX, second.clientY - first.clientY);
				const scale = Math.min(Math.max(startScale * distance / Math.max(startDistance, 1), props.scaleMin, .5), props.scaleMax, 10);
				if (scale !== currentScale.value) {
					currentScale.value = Number(scale.toFixed(3));
					triggerEvent("scale", {
						event,
						info,
						detail: {
							scale: currentScale.value,
							x: currentX.value,
							y: currentY.value
						}
					});
				}
				return;
			}
			if (props.disabled || !isDragging) {
				if (props.disabled) triggerEvent("touchmove", {
					event,
					info
				});
				return;
			}
			event.stopPropagation();
			if (rafId) cancelAnimationFrame(rafId);
			rafId = requestAnimationFrame(() => {
				const nX = event.touches ? event.touches[0].clientX : event.clientX;
				const nY = event.touches ? event.touches[0].clientY : event.clientY;
				const time = event.timeStamp || performance.now();
				const elapsed = Math.max(time - lastPointerTime, 1);
				velocityX = (nX - lastPointerX) / elapsed;
				velocityY = (nY - lastPointerY) / elapsed;
				lastPointerX = nX;
				lastPointerY = nY;
				lastPointerTime = time;
				const dx = nX - startX;
				const dy = nY - startY;
				const constrained = constrainPosition(dx, dy);
				const damp = (value, boundary) => boundary + (value - boundary) / Math.max(props.damping / 5, 1);
				const constrainedX = props.outOfBounds && constrained.x !== dx ? damp(dx, constrained.x) : constrained.x;
				const constrainedY = props.outOfBounds && constrained.y !== dy ? damp(dy, constrained.y) : constrained.y;
				isUpdatingFromDrag = true;
				if (props.direction === "horizontal") {
					currentX.value = constrainedX;
					emit("update:x", constrainedX);
				} else if (props.direction === "vertical") {
					currentY.value = constrainedY;
					emit("update:y", constrainedY);
				} else if (props.direction === "all") {
					currentX.value = constrainedX;
					currentY.value = constrainedY;
					emit("update:x", constrainedX);
					emit("update:y", constrainedY);
				}
				if (props.direction !== "none") triggerEvent("change", {
					event,
					info,
					detail: {
						x: currentX.value,
						y: currentY.value,
						source: constrained.x === dx && constrained.y === dy ? "touch" : "touch-out-of-bounds"
					}
				});
			});
		}
		function endDrag(event) {
			if (props.disabled) {
				triggerEvent("touchend", {
					event,
					info
				});
				return;
			}
			if (isScaling) {
				isScaling = false;
				triggerEvent("touchend", {
					event,
					info
				});
				return;
			}
			if (!isDragging) return;
			isDragging = false;
			isUpdatingFromDrag = false;
			const constrained = constrainPosition(currentX.value, currentY.value);
			let nextX = constrained.x;
			let nextY = constrained.y;
			let source = constrained.x !== currentX.value || constrained.y !== currentY.value ? "out-of-bounds" : "";
			if (!source && props.inertia) {
				const inertiaFactor = 180 / Math.max(props.friction, .01);
				const inertiaPosition = constrainPosition(currentX.value + velocityX * inertiaFactor, currentY.value + velocityY * inertiaFactor);
				nextX = inertiaPosition.x;
				nextY = inertiaPosition.y;
				source = nextX !== currentX.value || nextY !== currentY.value ? "friction" : "";
			}
			duration.value = props.animation && source ? `${Math.max(120, 600 / Math.max(props.damping / 10, 1))}ms` : "0s";
			if (source) {
				currentX.value = nextX;
				currentY.value = nextY;
				emit("update:x", nextX);
				emit("update:y", nextY);
				triggerEvent("change", {
					event,
					info,
					detail: {
						x: nextX,
						y: nextY,
						source
					}
				});
			}
			if (rafId) {
				cancelAnimationFrame(rafId);
				rafId = null;
			}
			triggerEvent("touchend", {
				event,
				info
			});
		}
		watch([() => props.x, () => props.y], ([nX, nY], [pX, pY]) => {
			if (isUpdatingFromDrag) return;
			if (nX === pX && nY === pY) return;
			const { x: constrainedX, y: constrainedY } = constrainPosition(parseCoordinate(nX), parseCoordinate(nY));
			duration.value = props.animation ? "0.5s" : "0s";
			currentX.value = constrainedX;
			currentY.value = constrainedY;
		}, { flush: "post" });
		watch([
			() => props.scaleValue,
			() => props.scaleMin,
			() => props.scaleMax
		], ([value]) => {
			if (!props.scale) return;
			currentScale.value = Math.min(Math.max(Number(value) || 1, props.scaleMin, .5), props.scaleMax, 10);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				ref_key: "movableView",
				ref: movableView
			}, _ctx.$attrs, {
				class: ["dd-movable-view", [`direction-${__props.direction}`]],
				"aria-dropeffect": "move",
				"aria-label": "可移动",
				onTouchstart: startDrag,
				onTouchmove: drag,
				onTouchend: endDrag,
				onTouchcancel: endDrag,
				onMousedown: startDrag,
				onMousemove: drag,
				onMouseup: endDrag,
				onMouseleave: endDrag
			}), [createBaseVNode("div", {
				ref_key: "movableViewContent",
				ref: movableViewContent,
				class: "dd-movable-view-content",
				style: normalizeStyle({
					"--duration": unref(duration),
					"transform": `translate3d(${unref(currentX)}px, ${unref(currentY)}px, 0) scale(${unref(currentScale)})`
				})
			}, [renderSlot(_ctx.$slots, "default")], 4)], 16);
		};
	}
};
var movable_view_exports = /* @__PURE__ */ __exportAll({ default: () => movable_view_default });
var movable_view_default = withInstall(_sfc_main$23);
var _sfc_main$22 = {
	__name: "NavigationBar",
	props: {
		/**
		* 导航条标题
		*/
		title: {
			type: String,
			required: false
		},
		/**
		* 是否在导航条显示 loading 加载提示
		*/
		loading: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 导航条前景颜色值，包括按钮、标题、状态栏的颜色，仅支持 #ffffff 和 #000000
		*/
		frontColor: {
			type: String,
			required: false,
			validator: (value) => ["#ffffff", "#000000"].includes(value)
		},
		/**
		* 导航条背景颜色值，有效值为十六进制颜色
		*/
		backgroundColor: {
			type: String,
			required: false,
			validator: (value) => /^#(?:[0-9A-F]{6}|[0-9A-F]{3})$/i.test(value)
		},
		/**
		* 改变导航栏颜色时的动画时长，默认为 0 （即没有动画效果）
		*/
		colorAnimationDuration: {
			type: Number,
			default: 0,
			required: false
		},
		/**
		* 改变导航栏颜色时的动画方式，支持 linear 、 easeIn 、 easeOut 和 easeInOut
		*/
		colorAnimationTimingFunc: {
			type: String,
			default: "linear",
			required: false,
			validator: (value) => [
				"linear",
				"easeIn",
				"easeOut",
				"easeInOut"
			].includes(value)
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		function updateTitle() {
			invokeAPI("setNavigationBarTitle", {
				bridgeId: info.bridgeId,
				params: { title: props.title }
			});
		}
		function updateColor() {
			invokeAPI("setNavigationBarColor", {
				bridgeId: info.bridgeId,
				params: {
					frontColor: props.frontColor,
					backgroundColor: props.backgroundColor,
					animation: {
						duration: props.colorAnimationDuration,
						timingFunc: props.colorAnimationTimingFunc
					}
				}
			});
		}
		function updateLoading() {
			invokeAPI(props.loading ? "showNavigationBarLoading" : "hideNavigationBarLoading", {
				bridgeId: info.bridgeId,
				params: {}
			});
		}
		watch(() => props.title, updateTitle, { immediate: true });
		watch(() => [
			props.frontColor,
			props.backgroundColor,
			props.colorAnimationDuration,
			props.colorAnimationTimingFunc
		], updateColor, { immediate: true });
		watch(() => props.loading, updateLoading, { immediate: true });
		return (_ctx, _cache) => {
			return renderSlot(_ctx.$slots, "default");
		};
	}
};
var navigation_bar_exports = /* @__PURE__ */ __exportAll({ default: () => navigation_bar_default });
var navigation_bar_default = withInstall(_sfc_main$22);
var _hoisted_1$15 = ["onKeydown"];
var _sfc_main$21 = {
	__name: "Navigator",
	props: {
		/**
		* 在哪个目标上发生跳转，默认当前小程序
		* 合法值 self|miniProgram
		*/
		target: {
			type: String,
			default: "self"
		},
		url: { type: String },
		redirect: {
			type: Boolean,
			default: false
		},
		/**
		* 跳转方式
		* 合法值: navigate, redirect, switchTab, reLaunch, navigateBack, exit
		*/
		openType: {
			type: String,
			default: "navigate"
		},
		/**
		* 当 open-type 为 'navigateBack' 时有效，表示回退的层数
		*/
		delta: {
			type: Number,
			default: 1
		},
		/**
		* 当target="miniProgram"且open-type="navigate"时有效，要打开的小程序 appId
		*/
		appId: { type: String },
		path: { type: String },
		extraData: { type: Object },
		/**
		* 当target="miniProgram"且open-type="navigate"时有效，要打开的小程序版本
		* 合法值 develop|trial|release
		*/
		version: {
			type: String,
			default: "release"
		},
		/**
		* 当target="miniProgram"时有效，当传递该参数后，可以不传 app-id 和 path。链接可以通过【小程序菜单】->【复制链接】获取。
		*/
		shortLink: { type: String },
		scene: {
			type: Number,
			default: 1037
		},
		sceneNote: {
			type: String,
			default: ""
		},
		/**
		* 指定点击时的样式类，当hover-class="none"时，没有点击态效果
		*/
		hoverClass: {
			type: String,
			default: "navigator-hover"
		},
		hover: {
			type: Boolean,
			default: true
		},
		/**
		* 指定是否阻止本节点的祖先节点出现点击态
		*/
		hoverStopPropagation: {
			type: Boolean,
			default: false
		},
		/**
		* 按住后多久出现点击态，单位毫秒
		*/
		hoverStartTime: {
			type: Number,
			default: 50
		},
		/**
		* 手指松开后点击态保留时间，单位毫秒
		*/
		hoverStayTime: {
			type: Number,
			default: 600
		}
	},
	setup(__props) {
		const props = __props;
		const { isHover, onHoverCancel, onHoverEnd, onHoverStart } = useHover(props);
		const info = useInfo();
		function invokeNavigationAPI(apiName, params, event) {
			const preservedEvent = {
				...event,
				currentTarget: event.currentTarget,
				target: event.target
			};
			invokeAPIWithCallback(apiName, {
				bridgeId: info.bridgeId,
				params,
				success: (result = {}) => triggerEvent("success", {
					event: preservedEvent,
					info,
					detail: result
				}),
				fail: (result = {}) => triggerEvent("fail", {
					event: preservedEvent,
					info,
					detail: result
				}),
				complete: (result = {}) => triggerEvent("complete", {
					event: preservedEvent,
					info,
					detail: result
				})
			});
		}
		function clicked(event) {
			const { openType, target, url, redirect } = props;
			if (url?.includes("javascript:")) return;
			if (redirect) {
				invokeNavigationAPI("redirectTo", { url: parsePath(info.path, url) }, event);
				return;
			}
			if (target === "miniProgram") {
				if (openType === "navigate") invokeNavigationAPI("navigateToMiniProgram", {
					appId: props.appId,
					path: props.path,
					shortLink: props.shortLink,
					extraData: props.extraData,
					envVersion: props.version,
					scene: props.scene,
					sceneNote: props.sceneNote
				}, event);
				else if (openType === "navigateBack") invokeNavigationAPI("navigateBackMiniProgram", { extraData: props.extraData }, event);
				else if (openType === "exit") invokeNavigationAPI("exit", {}, event);
				return;
			}
			switch (openType) {
				case "navigate":
					invokeNavigationAPI("navigateTo", { url: parsePath(info.path, url) }, event);
					break;
				case "redirect":
					invokeNavigationAPI("redirectTo", { url: parsePath(info.path, url) }, event);
					break;
				case "switchTab":
					invokeNavigationAPI("switchTab", { url: parsePath(info.path, url) }, event);
					break;
				case "reLaunch":
					invokeNavigationAPI("reLaunch", { url: parsePath(info.path, url) }, event);
					break;
				case "navigateBack":
					invokeNavigationAPI("navigateBack", { delta: props.delta }, event);
					break;
				case "exit": break;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", mergeProps(_ctx.$attrs, {
				class: ["dd-navigator", [unref(isHover) ? __props.hoverClass : void 0]],
				role: "link",
				tabindex: "0",
				onClick: clicked,
				onKeydown: withKeys(withModifiers(clicked, ["prevent"]), ["enter"]),
				onTouchstart: _cache[0] || (_cache[0] = (...args) => unref(onHoverStart) && unref(onHoverStart)(...args)),
				onTouchend: _cache[1] || (_cache[1] = (...args) => unref(onHoverEnd) && unref(onHoverEnd)(...args)),
				onTouchcancel: _cache[2] || (_cache[2] = (...args) => unref(onHoverCancel) && unref(onHoverCancel)(...args)),
				onMousedown: _cache[3] || (_cache[3] = (...args) => unref(onHoverStart) && unref(onHoverStart)(...args)),
				onMouseup: _cache[4] || (_cache[4] = (...args) => unref(onHoverEnd) && unref(onHoverEnd)(...args)),
				onMouseleave: _cache[5] || (_cache[5] = (...args) => unref(onHoverCancel) && unref(onHoverCancel)(...args))
			}), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_1$15);
		};
	}
};
var navigator_exports = /* @__PURE__ */ __exportAll({ default: () => navigator_default });
var navigator_default = withInstall(_sfc_main$21);
var _hoisted_1$14 = ["src"];
var _sfc_main$20 = {
	__name: "OpenData",
	props: {
		type: {
			type: String,
			default: ""
		},
		openGid: {
			type: String,
			default: ""
		},
		lang: {
			type: String,
			default: "en"
		},
		defaultText: {
			type: String,
			default: ""
		},
		defaultAvatar: {
			type: String,
			default: ""
		},
		keyList: {
			type: Array,
			default: () => []
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		const displayText = /* @__PURE__ */ ref("");
		const avatarUrl = /* @__PURE__ */ ref("");
		let requestVersion = 0;
		function showFallback(errMsg) {
			avatarUrl.value = props.type === "userAvatarUrl" ? props.defaultAvatar : "";
			displayText.value = avatarUrl.value ? "" : props.defaultText;
			triggerEvent("error", {
				info,
				detail: { errMsg }
			});
		}
		function renderUserInfo(userInfo) {
			const field = props.type.replace(/^user/, "");
			const key = field ? field[0].toLowerCase() + field.slice(1) : "";
			const value = userInfo?.[key];
			if (!value) {
				showFallback(`${props.type} is empty.`);
				return;
			}
			if (key === "avatarUrl") {
				avatarUrl.value = value;
				displayText.value = "";
			} else if (key === "gender") displayText.value = {
				en: [
					"",
					"Male",
					"Female"
				],
				zh_CN: [
					"",
					"男",
					"女"
				],
				zh_TW: [
					"",
					"男",
					"女"
				]
			}[props.lang]?.[value] || "";
			else displayText.value = String(value);
		}
		function requestData() {
			const version = ++requestVersion;
			avatarUrl.value = "";
			displayText.value = "";
			if (!props.type) return;
			let apiName;
			let params = {};
			if (props.type === "groupName") {
				apiName = "getGroupInfoByGId";
				params = { openGId: props.openGid };
			} else if (props.type.startsWith("user")) {
				apiName = "getUserInfo";
				params = { lang: props.lang };
			} else if (props.type.endsWith("CloudStorage")) {
				apiName = `get${props.type[0].toUpperCase()}${props.type.slice(1)}`;
				params = { keyList: props.keyList };
			} else {
				showFallback(`${props.type} is not supported.`);
				return;
			}
			invokeAPIWithCallback(apiName, {
				bridgeId: info.bridgeId,
				params,
				success: (result = {}) => {
					if (version !== requestVersion) return;
					if (props.type === "groupName") {
						displayText.value = result.roomTopic || props.defaultText;
						if (!result.roomTopic) triggerEvent("error", {
							info,
							detail: { errMsg: "groupName is empty." }
						});
						triggerEvent("getgroupname", {
							info,
							detail: result
						});
					} else if (props.type.startsWith("user")) renderUserInfo(result.userInfo || result);
					else displayText.value = props.defaultText;
				},
				fail: (error = {}) => {
					if (version === requestVersion) showFallback(error.errMsg || `${apiName}:fail`);
				}
			});
		}
		watch(() => [
			props.type,
			props.openGid,
			props.lang,
			props.defaultText,
			props.defaultAvatar,
			props.keyList
		], requestData, {
			deep: true,
			immediate: true
		});
		onBeforeUnmount(() => {
			requestVersion++;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", mergeProps(_ctx.$attrs, { class: "dd-open-data" }), [unref(avatarUrl) ? (openBlock(), createElementBlock("img", {
				key: 0,
				src: unref(avatarUrl),
				alt: "",
				class: "dd-open-data-avatar"
			}, null, 8, _hoisted_1$14)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createTextVNode(toDisplayString(unref(displayText)), 1)], 64))], 16);
		};
	}
};
var open_data_exports = /* @__PURE__ */ __exportAll({ default: () => open_data_default });
var open_data_default = withInstall(_sfc_main$20);
var _sfc_main$19 = {
	__name: "PageMeta",
	props: {
		/**
		* 编译器注入的 rpx 传输单位标记，用于兼容历史 rem 产物。
		*/
		diminaRpxUnit: {
			type: String,
			default: "",
			required: false
		},
		/**
		* 下拉背景字体、loading 图的样式，仅支持 dark 和 light
		*/
		backgroundTextStyle: {
			type: String,
			required: false,
			validator: (value) => {
				return ["dark", "light"].includes(value);
			}
		},
		/**
		* 窗口的背景色，必须为十六进制颜色值
		*/
		backgroundColor: {
			type: String,
			required: false
		},
		/**
		* 窗口的背景色，必须为十六进制颜色值
		*/
		backgroundColorTop: {
			type: String,
			required: false
		},
		/**
		* 底部窗口的背景色，必须为十六进制颜色值，仅 iOS 支持
		*/
		backgroundColorBottom: {
			type: String,
			required: false
		},
		/**
		* 页面内容的背景色，用于页面中的空白部分和页面大小变化 resize 动画期间的临时空闲区域
		*/
		rootBackgroundColor: {
			type: String,
			default: "",
			required: false
		},
		/**
		* 页面根节点样式，页面根节点是所有页面节点的祖先节点，相当于 HTML 中的 body 节点
		*/
		pageStyle: {
			type: String,
			default: "",
			required: false
		},
		/**
		* 页面 page 的字体大小，可以设置为 system ，表示使用当前用户设置的微信字体大小
		*/
		pageFontSize: {
			type: String,
			default: "",
			required: false
		},
		/**
		* 页面的根字体大小，页面中的所有 rem 单位，将使用这个字体大小作为参考值，即 1rem 等于这个字体大小；自小程序版本 2.11.0 起，也可以设置为 system
		*/
		rootFontSize: {
			type: String,
			default: "",
			required: false
		},
		/**
		* 页面的方向，可为 auto portrait 或 landscape
		*/
		pageOrientation: {
			type: String,
			default: "",
			required: false
		},
		scrollTop: {
			type: [Number, String],
			default: ""
		},
		scrollDuration: {
			type: Number,
			default: 300
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		let pageElement;
		let originalPageStyle;
		let originalRootFontSize;
		let originalRootBackgroundColor;
		function updateBackground() {
			invokeAPI("setBackgroundTextStyle", {
				bridgeId: info.bridgeId,
				params: { textStyle: props.backgroundTextStyle }
			});
			invokeAPI("setBackgroundColor", {
				bridgeId: info.bridgeId,
				params: {
					backgroundColor: props.backgroundColor,
					backgroundColorTop: props.backgroundColorTop,
					backgroundColorBottom: props.backgroundColorBottom
				}
			});
		}
		function normalizeFontSize(value) {
			if (!value) return "";
			if (value === "system") return `${window.__fontSizeSetting__ || 16}px`;
			return transformRpx(value);
		}
		function updatePageStyle() {
			if (!pageElement) return;
			pageElement.style.cssText = props.pageStyle || "";
			if (props.pageFontSize) pageElement.style.fontSize = normalizeFontSize(props.pageFontSize);
			if (props.diminaRpxUnit === "vw") document.documentElement.style.fontSize = normalizeFontSize(props.rootFontSize);
			document.documentElement.style.backgroundColor = props.rootBackgroundColor || "";
		}
		function scrollPage() {
			if (props.scrollTop === "" || props.scrollTop === void 0 || props.scrollTop === null) return;
			invokeAPIWithCallback("pageScrollTo", {
				bridgeId: info.bridgeId,
				params: {
					duration: props.scrollDuration,
					scrollTop: Number(props.scrollTop) || 0
				},
				success: () => triggerEvent("scrolldone", {
					info,
					detail: {}
				})
			});
		}
		function handleResize(event) {
			triggerEvent("resize", {
				event,
				info,
				detail: { size: {
					windowWidth: window.innerWidth,
					windowHeight: window.innerHeight
				} }
			});
		}
		function handleScroll(event) {
			triggerEvent("scroll", {
				event,
				info,
				detail: { scrollTop: window.scrollY }
			});
		}
		watch(() => [
			props.backgroundTextStyle,
			props.backgroundColor,
			props.backgroundColorTop,
			props.backgroundColorBottom
		], updateBackground);
		watch(() => [
			props.diminaRpxUnit,
			props.pageStyle,
			props.pageFontSize,
			props.rootFontSize,
			props.rootBackgroundColor
		], updatePageStyle);
		watch(() => [props.scrollTop, props.scrollDuration], scrollPage);
		onMounted(() => {
			pageElement = document.querySelector(".dd-page");
			originalPageStyle = pageElement?.getAttribute("style");
			originalRootFontSize = document.documentElement.style.fontSize;
			originalRootBackgroundColor = document.documentElement.style.backgroundColor;
			updateBackground();
			updatePageStyle();
			scrollPage();
			window.addEventListener("resize", handleResize);
			window.addEventListener("scroll", handleScroll, { passive: true });
		});
		onBeforeUnmount(() => {
			window.removeEventListener("resize", handleResize);
			window.removeEventListener("scroll", handleScroll);
			if (pageElement) if (originalPageStyle === null) pageElement.removeAttribute("style");
			else pageElement.setAttribute("style", originalPageStyle);
			document.documentElement.style.fontSize = originalRootFontSize;
			document.documentElement.style.backgroundColor = originalRootBackgroundColor;
		});
		return (_ctx, _cache) => {
			return renderSlot(_ctx.$slots, "default");
		};
	}
};
var page_meta_exports = /* @__PURE__ */ __exportAll({ default: () => page_meta_default });
var page_meta_default = withInstall(_sfc_main$19);
var _plugin_vue_export_helper_default = (sfc, props) => {
	const target = sfc.__vccOpts || sfc;
	for (const [key, val] of props) target[key] = val;
	return target;
};
var _hoisted_1$13 = { class: "dd-picker-column" };
var itemHeight = 44;
var PickerColumn_default = /*#__PURE__*/ _plugin_vue_export_helper_default({
	__name: "PickerColumn",
	props: {
		options: {
			type: Array,
			default: () => []
		},
		value: {
			type: Number,
			default: 0
		}
	},
	emits: ["change"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const columnRef = /* @__PURE__ */ ref(null);
		const currentIndex = /* @__PURE__ */ ref(props.value);
		const startY = /* @__PURE__ */ ref(0);
		const currentY = /* @__PURE__ */ ref(0);
		const isDragging = /* @__PURE__ */ ref(false);
		watch(() => props.value, (newVal) => {
			if (!isDragging.value) {
				if (newVal !== currentIndex.value) currentIndex.value = newVal;
				updatePosition();
			}
		});
		watch(() => props.options, () => {
			nextTick(() => {
				if (!isDragging.value) updatePosition();
			});
		});
		onMounted(() => {
			updatePosition();
		});
		const updatePosition = () => {
			if (!columnRef.value) return;
			const translateY = -currentIndex.value * itemHeight;
			columnRef.value.style.transform = `translateY(${translateY}px)`;
			columnRef.value.style.transition = "transform 0.3s ease";
		};
		const handleTouchStart = (e) => {
			isDragging.value = true;
			startY.value = e.touches[0].clientY;
			currentY.value = e.touches[0].clientY;
			if (columnRef.value) columnRef.value.style.transition = "none";
		};
		const handleTouchMove = (e) => {
			if (!isDragging.value) return;
			e.preventDefault();
			currentY.value = e.touches[0].clientY;
			const deltaY = currentY.value - startY.value;
			const translateY = -currentIndex.value * itemHeight + deltaY;
			if (columnRef.value) columnRef.value.style.transform = `translateY(${translateY}px)`;
		};
		const handleTouchEnd = (e) => {
			if (!isDragging.value) return;
			isDragging.value = false;
			const deltaY = currentY.value - startY.value;
			const moveCount = Math.round(deltaY / itemHeight);
			let newIndex = currentIndex.value - moveCount;
			newIndex = Math.max(0, Math.min(newIndex, props.options.length - 1));
			if (newIndex !== currentIndex.value) {
				currentIndex.value = newIndex;
				emit("change", e, newIndex);
			}
			updatePosition();
		};
		const handleMouseDown = (e) => {
			isDragging.value = true;
			startY.value = e.clientY;
			currentY.value = e.clientY;
			if (columnRef.value) columnRef.value.style.transition = "none";
			const handleMouseMove = (e) => {
				if (!isDragging.value) return;
				currentY.value = e.clientY;
				const deltaY = currentY.value - startY.value;
				const translateY = -currentIndex.value * itemHeight + deltaY;
				if (columnRef.value) columnRef.value.style.transform = `translateY(${translateY}px)`;
			};
			const handleMouseUp = (e) => {
				if (!isDragging.value) return;
				isDragging.value = false;
				const deltaY = currentY.value - startY.value;
				const moveCount = Math.round(deltaY / itemHeight);
				let newIndex = currentIndex.value - moveCount;
				newIndex = Math.max(0, Math.min(newIndex, props.options.length - 1));
				if (newIndex !== currentIndex.value) {
					currentIndex.value = newIndex;
					emit("change", e, newIndex);
				}
				updatePosition();
				document.removeEventListener("mousemove", handleMouseMove);
				document.removeEventListener("mouseup", handleMouseUp);
			};
			document.addEventListener("mousemove", handleMouseMove);
			document.addEventListener("mouseup", handleMouseUp);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$13, [
				_cache[0] || (_cache[0] = createBaseVNode("div", { class: "dd-picker-column-mask" }, null, -1)),
				_cache[1] || (_cache[1] = createBaseVNode("div", { class: "dd-picker-column-indicator" }, null, -1)),
				createBaseVNode("div", {
					class: "dd-picker-column-content",
					ref_key: "columnRef",
					ref: columnRef,
					onTouchstart: handleTouchStart,
					onTouchmove: handleTouchMove,
					onTouchend: handleTouchEnd,
					onMousedown: handleMouseDown
				}, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.options, (option, index) => {
					return openBlock(), createElementBlock("div", {
						key: index,
						class: normalizeClass(["dd-picker-column-item", { "dd-picker-column-item-selected": index === unref(currentIndex) }])
					}, toDisplayString(option), 3);
				}), 128))], 544)
			]);
		};
	}
}, [["__scopeId", "data-v-61501610"]]);
var _hoisted_1$12 = { class: "dd-picker-header" };
var _hoisted_2$7 = { class: "dd-picker-title" };
var _hoisted_3$3 = { class: "dd-picker-body" };
var _hoisted_4$2 = {
	key: 1,
	class: "dd-picker-columns"
};
var _hoisted_5 = {
	key: 2,
	class: "dd-picker-columns"
};
var _hoisted_6 = {
	key: 3,
	class: "dd-picker-columns"
};
var _sfc_main$17 = {
	__name: "Picker",
	props: {
		/**
		* 选择器的标题
		*/
		headerText: { type: String },
		/**
		* 选择器类型
		*/
		mode: {
			type: String,
			default: "selector",
			validator: (value) => {
				return [
					"selector",
					"multiSelector",
					"time",
					"date",
					"region"
				].includes(value);
			}
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false
		},
		/**
		* mode 为 selector 或 multiSelector 时，range 有效
		*/
		range: {
			type: [Array, Object],
			default: () => []
		},
		/**
		* 当 range 是一个 Object Array 时，通过 range-key 来指定 Object 中 key 的值作为选择器显示内容
		*/
		rangeKey: { type: String },
		/**
		* 表示有效时间范围的开始，字符串格式为"hh:mm"
		* 表示有效日期范围的开始，字符串格式为"YYYY-MM-DD"
		*/
		start: { type: String },
		/**
		* 表示有效时间范围的结束，字符串格式为"hh:mm"
		* 表示有效日期范围的结束，字符串格式为"YYYY-MM-DD"
		*/
		end: { type: String },
		/**
		* 有效值 year,month,day，表示选择器的粒度
		*/
		fields: {
			type: String,
			default: "day",
			validator: (value) => {
				return [
					"year",
					"month",
					"day"
				].includes(value);
			}
		},
		/**
		* 表示选择了 range 中的第几个（下标从 0 开始）
		*/
		value: {
			type: [
				Number,
				String,
				Array
			],
			default: (props) => {
				switch (props.mode) {
					case "selector": return 0;
					case "multiSelector": return [];
					case "time": {
						const now = /* @__PURE__ */ new Date();
						return `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
					}
					case "date": {
						const now = /* @__PURE__ */ new Date();
						return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
					}
				}
			}
		},
		customItem: {
			type: String,
			default: ""
		},
		level: {
			type: String,
			default: ""
		},
		name: { type: String },
		autoFill: { type: String }
	},
	setup(__props) {
		const props = __props;
		const showPicker = /* @__PURE__ */ ref(false);
		const currentValue = /* @__PURE__ */ ref(props.value);
		const tempValue = /* @__PURE__ */ ref(props.value);
		const columnValues = /* @__PURE__ */ ref({});
		watch(() => props.value, (newVal) => {
			currentValue.value = newVal;
			tempValue.value = newVal;
		});
		watch(() => props.mode, () => {
			if (props.mode === "multiSelector" && (!Array.isArray(tempValue.value) || tempValue.value.length === 0)) {
				tempValue.value = props.range.map(() => 0);
				const values = {};
				tempValue.value.forEach((val, idx) => {
					values[idx] = val;
				});
				columnValues.value = values;
			}
		}, { immediate: true });
		const handleTriggerClick = () => {
			if (props.disabled) return;
			if (props.mode === "region") {
				triggerEvent("error", {
					info,
					detail: { errMsg: "picker:fail region mode is not supported by the current container" }
				});
				return;
			}
			showPicker.value = true;
			if (props.mode === "multiSelector") {
				if (!Array.isArray(currentValue.value) || currentValue.value.length === 0) tempValue.value = props.range.map(() => 0);
				else tempValue.value = [...currentValue.value];
				const values = {};
				tempValue.value.forEach((val, idx) => {
					values[idx] = val;
				});
				columnValues.value = values;
			} else tempValue.value = currentValue.value;
		};
		const handleCancel = (event) => {
			showPicker.value = false;
			triggerEvent("cancel", {
				event,
				info,
				detail: {}
			});
		};
		const info = useInfo();
		const handleConfirm = (event) => {
			currentValue.value = tempValue.value;
			collectFormValue?.(props.name, currentValue.value);
			showPicker.value = false;
			triggerEvent("change", {
				event,
				info,
				detail: { value: tempValue.value }
			});
		};
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		watch(currentValue, (value) => collectFormValue?.(props.name, value), {
			deep: true,
			immediate: true
		});
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue: () => currentValue.value,
			reset: () => {
				currentValue.value = props.mode === "selector" ? -1 : "";
				tempValue.value = currentValue.value;
				collectFormValue?.(props.name, currentValue.value);
			}
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		const handleMaskClick = () => {
			handleCancel();
		};
		const stopPropagation = (e) => {
			e.stopPropagation();
		};
		const displayOptions = computed(() => {
			switch (props.mode) {
				case "selector": return getDisplayRange(props.range);
				case "multiSelector": return props.range.map((column) => getDisplayRange(column));
				case "time": return getTimeOptions();
				case "date": return getDateOptions();
				default: return [];
			}
		});
		const getDisplayRange = (range) => {
			if (!Array.isArray(range) && typeof range === "object" && range !== null) return Object.values(range);
			if (!Array.isArray(range)) return [];
			if (range.length > 0 && typeof range[0] === "object") {
				if (props.rangeKey) return range.map((item) => item[props.rangeKey] || "");
				return range.map((item) => {
					return item.name || item.label || item.text || item.value || String(item);
				});
			}
			return range;
		};
		const getTimeOptions = () => {
			const hours = [];
			const minutes = [];
			for (let i = 0; i < 24; i++) hours.push(String(i).padStart(2, "0"));
			for (let i = 0; i < 60; i++) minutes.push(String(i).padStart(2, "0"));
			return [hours, minutes];
		};
		const getDateOptions = () => {
			const years = [];
			const months = [];
			const days = [];
			const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
			const startYear = props.start ? Number.parseInt(props.start.split("-")[0]) : currentYear - 10;
			const endYear = props.end ? Number.parseInt(props.end.split("-")[0]) : currentYear + 10;
			for (let i = startYear; i <= endYear; i++) years.push(String(i));
			for (let i = 1; i <= 12; i++) months.push(String(i).padStart(2, "0"));
			for (let i = 1; i <= 31; i++) days.push(String(i).padStart(2, "0"));
			switch (props.fields) {
				case "year": return [years];
				case "month": return [years, months];
				default: return [
					years,
					months,
					days
				];
			}
		};
		const handleColumnChange = (event, columnIndex, value) => {
			if (props.mode === "multiSelector" && columnValues.value[columnIndex] !== value) {
				columnValues.value[columnIndex] = value;
				const tempArray = [];
				for (let i = 0; i < props.range.length; i++) tempArray[i] = columnValues.value[i] || 0;
				tempValue.value = tempArray;
				triggerEvent("columnchange", {
					event,
					info,
					detail: {
						column: columnIndex,
						value
					}
				});
			}
		};
		const handleSingleChange = (_event, value) => {
			if (props.mode === "selector") tempValue.value = value;
		};
		const getTimeValue = (index) => {
			if (typeof tempValue.value === "string" && tempValue.value.includes(":")) {
				const parts = tempValue.value.split(":");
				if (index === 0) return Number.parseInt(parts[0]) || 0;
				if (index === 1) return Number.parseInt(parts[1]) || 0;
			}
			return 0;
		};
		const handleTimeChange = (_event, index, value) => {
			const parts = tempValue.value.split(":");
			if (index === 0) parts[0] = displayOptions.value[0][value];
			else if (index === 1) parts[1] = displayOptions.value[1][value];
			tempValue.value = parts.join(":");
		};
		const getDateValue = (index) => {
			if (typeof tempValue.value === "string") {
				const parts = tempValue.value.split("-");
				if (index === 0 && parts[0]) return displayOptions.value[0].indexOf(parts[0]);
				if (index === 1 && parts[1]) return displayOptions.value[1].indexOf(parts[1]);
				if (index === 2 && parts[2]) return displayOptions.value[2].indexOf(parts[2]);
			}
			return 0;
		};
		const handleDateChange = (_event, index, value) => {
			const parts = tempValue.value.split("-");
			if (index === 0) parts[0] = displayOptions.value[0][value];
			else if (index === 1) parts[1] = displayOptions.value[1][value];
			else if (index === 2) parts[2] = displayOptions.value[2][value];
			if (props.fields === "year") tempValue.value = parts[0];
			else if (props.fields === "month") tempValue.value = `${parts[0]}-${parts[1]}`;
			else tempValue.value = parts.join("-");
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("div", mergeProps(_ctx.$attrs, {
				class: "dd-picker",
				onClick: handleTriggerClick
			}), [renderSlot(_ctx.$slots, "default")], 16), unref(showPicker) ? (openBlock(), createElementBlock("div", {
				key: 0,
				class: "dd-picker-overlay",
				onClick: handleMaskClick
			}, [createBaseVNode("div", {
				class: "dd-picker-container",
				onClick: stopPropagation
			}, [createBaseVNode("div", _hoisted_1$12, [
				createBaseVNode("div", {
					class: "dd-picker-action dd-picker-cancel",
					onClick: handleCancel
				}, "取消"),
				createBaseVNode("div", _hoisted_2$7, toDisplayString(__props.headerText || ""), 1),
				createBaseVNode("div", {
					class: "dd-picker-action dd-picker-confirm",
					onClick: handleConfirm
				}, "确定")
			]), createBaseVNode("div", _hoisted_3$3, [__props.mode === "selector" ? (openBlock(), createBlock(PickerColumn_default, {
				key: 0,
				options: unref(displayOptions),
				value: unref(tempValue),
				onChange: handleSingleChange
			}, null, 8, ["options", "value"])) : __props.mode === "multiSelector" ? (openBlock(), createElementBlock("div", _hoisted_4$2, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(displayOptions), (column, index) => {
				return openBlock(), createBlock(PickerColumn_default, {
					key: `column-${index}`,
					options: column,
					value: unref(columnValues)[index] ?? 0,
					onChange: (event, value) => handleColumnChange(event, index, value)
				}, null, 8, [
					"options",
					"value",
					"onChange"
				]);
			}), 128))])) : __props.mode === "time" ? (openBlock(), createElementBlock("div", _hoisted_5, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(displayOptions), (column, index) => {
				return openBlock(), createBlock(PickerColumn_default, {
					key: index,
					options: column,
					value: getTimeValue(index),
					onChange: (event, value) => handleTimeChange(event, index, value)
				}, null, 8, [
					"options",
					"value",
					"onChange"
				]);
			}), 128))])) : __props.mode === "date" ? (openBlock(), createElementBlock("div", _hoisted_6, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(displayOptions), (column, index) => {
				return openBlock(), createBlock(PickerColumn_default, {
					key: index,
					options: column,
					value: getDateValue(index),
					onChange: (event, value) => handleDateChange(event, index, value)
				}, null, 8, [
					"options",
					"value",
					"onChange"
				]);
			}), 128))])) : createCommentVNode("", true)])])])) : createCommentVNode("", true)], 64);
		};
	}
};
var picker_exports = /* @__PURE__ */ __exportAll({ default: () => picker_default });
var picker_default = withInstall(_sfc_main$17);
var _sfc_main$16 = {
	__name: "PickerView",
	props: {
		/**
		* 数组中的数字依次表示 picker-view 内的 picker-view-column 选择的第几项（下标从 0 开始），数字大于 picker-view-column 可选项长度时，选择最后一项。
		*/
		value: { type: Array },
		/**
		* 设置蒙层的类名
		*/
		maskClass: { type: String },
		/**
		* 设置选择器中间选中框的样式
		*/
		indicatorStyle: { type: String },
		/**
		* 设置选择器中间选中框的类名
		*/
		indicatorClass: { type: String },
		/**
		* 设置蒙层的样式
		*/
		maskStyle: { type: String },
		/**
		* 是否在手指松开时立即触发 change 事件。若不开启则会在滚动动画结束后触发 change 事件。
		*/
		immediateChange: {
			type: Boolean,
			default: false
		},
		name: { type: String },
		autoFill: { type: String }
	},
	setup(__props) {
		const props = __props;
		let index = -1;
		const pickerView = /* @__PURE__ */ ref(null);
		const itemValue = /* @__PURE__ */ ref([...props.value || []]);
		provide("getPickerHeight", () => {
			return pickerView.value.offsetHeight;
		});
		provide("pickerItemStyle", computed(() => ({
			indicatorStyle: props.indicatorStyle,
			indicatorClass: props.indicatorClass,
			maskStyle: props.maskStyle,
			maskClass: props.maskClass
		})));
		provide("itemValue", itemValue);
		provide("pickerImmediateChange", computed(() => props.immediateChange));
		provide("getItemIndex", () => {
			return ++index;
		});
		provide("setPickerValue", (index, value) => {
			itemValue.value[index] = value;
		});
		watch(() => props.value, (value = []) => {
			itemValue.value = [...value];
		}, { deep: true });
		const info = useInfo();
		provide("pickerEvent", (type, event) => {
			const detail = type === "change" ? { value: [...itemValue.value] } : {};
			triggerEvent(type, {
				event,
				info,
				detail
			});
		});
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		watch(itemValue, (value) => collectFormValue?.(props.name, [...value]), {
			deep: true,
			immediate: true
		});
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue: () => [...itemValue.value],
			reset: () => {
				itemValue.value = [...props.value || []];
			}
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				ref_key: "pickerView",
				ref: pickerView
			}, _ctx.$attrs, { class: "dd-picker-view" }), [renderSlot(_ctx.$slots, "default")], 16);
		};
	}
};
var picker_view_exports = /* @__PURE__ */ __exportAll({ default: () => picker_view_default });
var picker_view_default = withInstall(_sfc_main$16);
var _hoisted_1$11 = {
	"aria-label": "上下滚动进行选择",
	"aria-dropeffect": "move"
};
var _sfc_main$15 = {
	__name: "PickerViewColumn",
	setup(__props) {
		const indicatorRef = /* @__PURE__ */ ref(null);
		const maskRef = /* @__PURE__ */ ref(null);
		const contentRef = /* @__PURE__ */ ref(null);
		const currentY = /* @__PURE__ */ ref(0);
		const duration = /* @__PURE__ */ ref("0.2s");
		const pickerItemStyle = inject("pickerItemStyle", computed(() => ({})));
		const pickerEvent = inject("pickerEvent", void 0);
		const pickerImmediateChange = inject("pickerImmediateChange", computed(() => false));
		const getPickerHeight = inject("getPickerHeight", () => 0);
		const itemIndex = inject("getItemIndex", () => 0)();
		const setPickerValue = inject("setPickerValue", void 0);
		const itemValue = inject("itemValue", /* @__PURE__ */ ref(Array.from({ length: itemIndex }).fill(0)));
		const indicatorClass = computed(() => pickerItemStyle.value.indicatorClass);
		const maskClass = computed(() => pickerItemStyle.value.maskClass);
		const nodeLineHeight = /* @__PURE__ */ ref("34px");
		let isDragging = false;
		let startY = 0;
		let moveY = 0;
		let startIndex = 0;
		let valueChanged = false;
		let dragDistance = 0;
		let itemsSize = 0;
		const currentIndex = /* @__PURE__ */ ref(Math.min(itemValue.value[itemIndex] || 0, itemsSize));
		let itemHeight = 0;
		let pendingEndEvent;
		setPickerValue?.(itemIndex, currentIndex.value);
		function startDrag(event) {
			pickerEvent?.("pickstart", event);
			isDragging = true;
			duration.value = "0s";
			startY = event.touches ? event.touches[0].clientY : event.clientY;
			itemHeight = indicatorRef.value.offsetHeight;
			startIndex = currentIndex.value;
			valueChanged = false;
			dragDistance = 0;
			moveY = -currentIndex.value * itemHeight;
		}
		function drag(event) {
			if (!isDragging) return;
			dragDistance = (event.touches ? event.touches[0].clientY : event.clientY) - startY;
			moveY = dragDistance - currentIndex.value * itemHeight;
			currentY.value = moveY;
		}
		function getTargetItemIndex(event) {
			let target = event.target;
			while (target && target.parentElement !== contentRef.value) target = target.parentElement;
			if (!target || target.parentElement !== contentRef.value) return -1;
			return Array.from(contentRef.value.children).indexOf(target);
		}
		function endDrag(event) {
			if (!isDragging) return;
			isDragging = false;
			duration.value = "0.2s";
			itemsSize = Math.max((contentRef.value?.children.length || 1) - 1, 0);
			const targetIndex = Math.abs(dragDistance) < 3 ? getTargetItemIndex(event) : -1;
			if (targetIndex >= 0) {
				currentIndex.value = targetIndex;
				currentY.value = -currentIndex.value * itemHeight;
			} else if (moveY < 0) {
				currentIndex.value = Math.min(itemsSize, Math.abs(Math.round(moveY / itemHeight)));
				currentY.value = -currentIndex.value * itemHeight;
			} else {
				currentIndex.value = 0;
				currentY.value = 0;
			}
			setPickerValue?.(itemIndex, currentIndex.value);
			valueChanged = currentIndex.value !== startIndex;
			if (pickerImmediateChange.value && valueChanged) pickerEvent?.("change", event);
			pendingEndEvent = event;
			if (duration.value === "0s" || moveY === -currentIndex.value * itemHeight) finishScroll();
		}
		function finishScroll(event = pendingEndEvent) {
			if (!pendingEndEvent && !event) return;
			if (!pickerImmediateChange.value && valueChanged) pickerEvent?.("change", event);
			pickerEvent?.("pickend", event);
			pendingEndEvent = void 0;
		}
		watch(() => itemValue.value[itemIndex], (value) => {
			const nextIndex = Math.min(Math.max(Number(value) || 0, 0), itemsSize);
			currentIndex.value = nextIndex;
			currentY.value = -nextIndex * itemHeight;
		});
		function applyLayoutStyles() {
			if (!indicatorRef.value || !maskRef.value || !contentRef.value || !itemHeight) return;
			const pTop = (getPickerHeight() - itemHeight) / 2;
			indicatorRef.value.style.cssText = pickerItemStyle.value.indicatorStyle || "";
			indicatorRef.value.style.height = `${itemHeight}px`;
			indicatorRef.value.style.top = `${pTop}px`;
			maskRef.value.style.cssText = pickerItemStyle.value.maskStyle || "";
			maskRef.value.style.backgroundSize = `100% ${pTop}px`;
			Array.from(contentRef.value.children).forEach((node) => {
				node.style.height = `${itemHeight}px`;
			});
			contentRef.value.style.paddingTop = `${pTop}px`;
		}
		watch(pickerItemStyle, () => applyLayoutStyles(), { deep: true });
		onMounted(async () => {
			await nextTick();
			indicatorRef.value.style.cssText = pickerItemStyle.value.indicatorStyle || "";
			const firstChild = contentRef.value.firstElementChild;
			if (firstChild) {
				const computedStyle = window.getComputedStyle(firstChild);
				const lineHeight = Number.parseFloat(computedStyle.lineHeight);
				const fontSize = Number.parseFloat(computedStyle.fontSize) || 16;
				nodeLineHeight.value = `${Number.isFinite(lineHeight) ? lineHeight : fontSize * 1.2}px`;
				indicatorRef.value.style.height = nodeLineHeight.value;
			}
			itemHeight = indicatorRef.value.offsetHeight || Number.parseFloat(nodeLineHeight.value) || 34;
			itemsSize = Math.max(contentRef.value.children.length - 1, 0);
			currentIndex.value = Math.min(Math.max(Number(itemValue.value[itemIndex]) || 0, 0), itemsSize);
			setPickerValue?.(itemIndex, currentIndex.value);
			applyLayoutStyles();
			duration.value = "0s";
			currentY.value = -currentIndex.value * itemHeight;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-picker-view-column" }), [createBaseVNode("div", _hoisted_1$11, [
				createBaseVNode("div", {
					ref_key: "maskRef",
					ref: maskRef,
					class: normalizeClass(["dd-picker__mask", unref(maskClass)])
				}, null, 2),
				createBaseVNode("div", {
					ref_key: "indicatorRef",
					ref: indicatorRef,
					class: normalizeClass(["dd-picker__indicator", unref(indicatorClass)])
				}, null, 2),
				createBaseVNode("div", {
					ref_key: "contentRef",
					ref: contentRef,
					class: "dd-picker__content",
					style: normalizeStyle({
						"--duration": unref(duration),
						"transform": `translateY(${unref(currentY)}px)`
					}),
					onTransitionend: withModifiers(finishScroll, ["self"]),
					onTouchstart: startDrag,
					onTouchmove: withModifiers(drag, ["prevent"]),
					onTouchend: withModifiers(endDrag, ["prevent"]),
					onTouchcancel: endDrag,
					onMousedown: startDrag,
					onMousemove: withModifiers(drag, ["prevent"]),
					onMouseup: endDrag,
					onMouseleave: endDrag
				}, [renderSlot(_ctx.$slots, "default")], 36)
			])], 16);
		};
	}
};
var picker_view_column_exports = /* @__PURE__ */ __exportAll({ default: () => picker_view_column_default });
var picker_view_column_default = withInstall(_sfc_main$15);
var _hoisted_1$10 = ["aria-valuenow"];
var _hoisted_2$6 = ["aria-valuenow"];
var _hoisted_3$2 = ["hidden"];
var _sfc_main$14 = {
	__name: "Progress",
	props: {
		/**
		* 百分比0~100
		*/
		percent: {
			type: [Number, String],
			required: false
		},
		/**
		* 在进度条右侧显示百分比
		*/
		showInfo: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 圆角大小
		*/
		borderRadius: {
			type: [Number, String],
			default: 0,
			required: false
		},
		/**
		* 右侧百分比字体大小
		*/
		fontSize: {
			type: [Number, String],
			default: 16,
			required: false
		},
		/**
		* 进度条线的宽度
		*/
		strokeWidth: {
			type: [Number, String],
			default: 6,
			required: false
		},
		/**
		* 进度条颜色
		* @deprecated 请使用activeColor属性
		*/
		color: {
			type: String,
			default: "#09BB07",
			required: false
		},
		/**
		* 已选择的进度条的颜色
		*/
		activeColor: {
			type: String,
			default: "#09BB07",
			required: false
		},
		/**
		* 未选择的进度条的颜色
		*/
		backgroundColor: {
			type: String,
			default: "#EBEBEB",
			required: false
		},
		/**
		* 进度条从左往右的动画
		*/
		active: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* backwards: 动画从头播；forwards：动画从上次结束点接着播
		*/
		activeMode: {
			type: String,
			default: "backwards",
			required: false
		},
		/**
		* 进度增加1%所需毫秒数
		*/
		duration: {
			type: Number,
			default: 30,
			required: false
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		const currentPercent = /* @__PURE__ */ ref(0);
		let animationTimer;
		let previousTarget = 0;
		function normalizePercent(value) {
			const number = Number(value);
			return Number.isFinite(number) ? Math.min(Math.max(number, 0), 100) : 0;
		}
		function clearAnimation() {
			if (animationTimer !== void 0) {
				clearInterval(animationTimer);
				animationTimer = void 0;
			}
		}
		function runAnimation() {
			clearAnimation();
			const target = normalizePercent(props.percent);
			if (!props.active) {
				currentPercent.value = target;
				previousTarget = target;
				return;
			}
			currentPercent.value = props.activeMode === "forwards" ? previousTarget : 0;
			const tick = () => {
				if (target <= currentPercent.value + 1) {
					currentPercent.value = target;
					previousTarget = target;
					clearAnimation();
					triggerEvent("activeend", {
						info,
						detail: { curPercent: currentPercent.value }
					});
					return;
				}
				currentPercent.value += 1;
			};
			tick();
			if (currentPercent.value < target) animationTimer = setInterval(tick, Math.max(Number(props.duration) || 0, 0));
		}
		watch([
			() => props.percent,
			() => props.active,
			() => props.activeMode,
			() => props.duration
		], runAnimation, { immediate: true });
		onBeforeUnmount(clearAnimation);
		const progressColor = computed(() => {
			const attrs = info.attrs || {};
			if ("activeColor" in attrs || "active-color" in attrs) return props.activeColor;
			if ("color" in attrs) return props.color;
			return props.activeColor;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
				class: "dd-progress",
				role: "progressbar",
				"aria-valuenow": unref(currentPercent),
				"aria-valuemin": "0",
				"aria-valuemax": "100"
			}), [createBaseVNode("div", {
				class: "dd-progress-bar",
				"aria-label": "",
				"aria-valuenow": `${__props.percent}%`,
				style: normalizeStyle({
					borderRadius: `${__props.borderRadius}px`,
					backgroundColor: __props.backgroundColor,
					height: `${__props.strokeWidth}px`
				})
			}, [createBaseVNode("div", {
				class: "dd-progress-inner-bar",
				style: normalizeStyle({
					width: `${unref(currentPercent)}%`,
					backgroundColor: unref(progressColor)
				})
			}, null, 4)], 12, _hoisted_2$6), createBaseVNode("p", {
				class: "dd-progress-info",
				style: normalizeStyle({ fontSize: __props.fontSize }),
				hidden: !__props.showInfo
			}, toDisplayString(unref(currentPercent)) + "% ", 13, _hoisted_3$2)], 16, _hoisted_1$10);
		};
	}
};
var progress_exports = /* @__PURE__ */ __exportAll({ default: () => progress_default });
var progress_default = withInstall(_sfc_main$14);
var _hoisted_1$9 = [
	"id",
	"tabindex",
	"aria-checked",
	"aria-disabled",
	"onKeydown"
];
var _hoisted_2$5 = { class: "dd-radio-wrapper" };
var _sfc_main$13 = {
	__name: "Radio",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* radio 标识。当该radio 选中时，radio-group 的 change 事件会携带radio的value
		*/
		value: {
			type: String,
			default: ""
		},
		/**
		* 是否选中
		*/
		checked: {
			type: Boolean,
			default: false
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false
		},
		/**
		* switch 的颜色，同 css 的 color
		*/
		color: {
			type: String,
			default: "#09BB07"
		}
	},
	setup(__props) {
		const props = __props;
		const radioGroup = inject("radioGroup", void 0);
		const isOn = /* @__PURE__ */ ref(Boolean(props.checked));
		watch(() => props.checked, (value) => {
			isOn.value = value;
		});
		const radioControl = {
			getValue: () => props.value,
			isChecked: () => isOn.value,
			setChecked: (value) => {
				isOn.value = value;
			},
			reset: () => {
				isOn.value = false;
			}
		};
		const unregisterRadio = radioGroup?.registerRadio(radioControl);
		onBeforeUnmount(() => unregisterRadio?.());
		const computedStyle = computed(() => {
			if (props.color && isOn.value) return {
				backgroundColor: props.color,
				borderColor: props.color
			};
			else return;
		});
		const info = useInfo();
		function handleClicked(event) {
			if (!props.disabled) {
				if (radioGroup) radioGroup.selectRadio(radioControl, event);
				else isOn.value = true;
				triggerEvent("tap", {
					event,
					info,
					detail: {}
				});
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, {
				class: "dd-radio",
				"data-dd-label-target": "",
				role: "radio",
				tabindex: __props.disabled ? -1 : 0,
				"aria-checked": unref(isOn),
				"aria-disabled": __props.disabled,
				onClick: handleClicked,
				onKeydown: [withKeys(withModifiers(handleClicked, ["prevent"]), ["enter"]), withKeys(withModifiers(handleClicked, ["prevent"]), ["space"])]
			}), [createBaseVNode("div", _hoisted_2$5, [createBaseVNode("div", {
				class: normalizeClass(["dd-radio-input", {
					"dd-radio-input-checked": unref(isOn),
					"dd-radio-input-disabled": __props.disabled
				}]),
				style: normalizeStyle(unref(computedStyle))
			}, null, 6), renderSlot(_ctx.$slots, "default")])], 16, _hoisted_1$9);
		};
	}
};
var radio_exports = /* @__PURE__ */ __exportAll({ default: () => radio_default });
var radio_default = withInstall(_sfc_main$13);
var _hoisted_1$8 = ["id"];
var _sfc_main$12 = {
	__name: "RadioGroup",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* name，为表单使用
		*/
		name: { type: String },
		autoFill: { type: String }
	},
	setup(__props) {
		const props = __props;
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		const items = /* @__PURE__ */ new Set();
		function getSelectedItem() {
			return [...items].find((item) => item.isChecked());
		}
		function getValue() {
			return getSelectedItem()?.getValue() ?? "";
		}
		function registerRadio(item) {
			items.add(item);
			if (item.isChecked()) {
				for (const other of items) if (other !== item) other.setChecked(false);
			}
			collectFormValue?.(props.name, getValue());
			return () => items.delete(item);
		}
		const info = useInfo();
		function selectRadio(item, event) {
			if (item.isChecked()) return;
			for (const other of items) other.setChecked(other === item);
			const value = getValue();
			collectFormValue?.(props.name, value);
			triggerEvent("change", {
				event,
				info,
				detail: { value }
			});
		}
		function reset() {
			for (const item of items) item.reset();
			[...items].filter((item) => item.isChecked()).slice(1).forEach((item) => item.setChecked(false));
			collectFormValue?.(props.name, getValue());
		}
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue,
			reset
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		provide("radioGroup", {
			registerRadio,
			selectRadio
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, { class: "dd-radio-group" }), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_1$8);
		};
	}
};
var radio_group_exports = /* @__PURE__ */ __exportAll({ default: () => radio_group_default });
var radio_group_default = withInstall(_sfc_main$12);
/*! @license DOMPurify 3.4.12 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.12/LICENSE */
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = true, o = false;
		try {
			if (i = (t = t.call(r)).next, 0 === l);
			else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = true, n = r;
		} finally {
			try {
				if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
var entries = Object.entries;
var setPrototypeOf = Object.setPrototypeOf;
var isFrozen = Object.isFrozen;
var getPrototypeOf = Object.getPrototypeOf;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var freeze = Object.freeze;
var seal = Object.seal;
var create = Object.create;
var _ref = typeof Reflect !== "undefined" && Reflect;
var apply = _ref.apply;
var construct = _ref.construct;
if (!freeze) freeze = function freeze(x) {
	return x;
};
if (!seal) seal = function seal(x) {
	return x;
};
if (!apply) apply = function apply(func, thisArg) {
	for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
	return func.apply(thisArg, args);
};
if (!construct) construct = function construct(Func) {
	for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) args[_key2 - 1] = arguments[_key2];
	return new Func(...args);
};
var arrayForEach = unapply(Array.prototype.forEach);
var arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
var arrayPop = unapply(Array.prototype.pop);
var arrayPush = unapply(Array.prototype.push);
var arraySplice = unapply(Array.prototype.splice);
var arrayIsArray = Array.isArray;
var stringToLowerCase = unapply(String.prototype.toLowerCase);
var stringToString = unapply(String.prototype.toString);
var stringMatch = unapply(String.prototype.match);
var stringReplace = unapply(String.prototype.replace);
var stringIndexOf = unapply(String.prototype.indexOf);
var stringTrim = unapply(String.prototype.trim);
var numberToString = unapply(Number.prototype.toString);
var booleanToString = unapply(Boolean.prototype.toString);
var bigintToString = typeof BigInt === "undefined" ? null : unapply(BigInt.prototype.toString);
var symbolToString = typeof Symbol === "undefined" ? null : unapply(Symbol.prototype.toString);
var objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
var objectToString = unapply(Object.prototype.toString);
var regExpTest = unapply(RegExp.prototype.test);
var typeErrorCreate = unconstruct(TypeError);
/**
* Creates a new function that calls the given function with a specified thisArg and arguments.
*
* @param func - The function to be wrapped and called.
* @returns A new function that calls the given function with a specified thisArg and arguments.
*/
function unapply(func) {
	return function(thisArg) {
		if (thisArg instanceof RegExp) thisArg.lastIndex = 0;
		for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) args[_key3 - 1] = arguments[_key3];
		return apply(func, thisArg, args);
	};
}
/**
* Creates a new function that constructs an instance of the given constructor function with the provided arguments.
*
* @param func - The constructor function to be wrapped and called.
* @returns A new function that constructs an instance of the given constructor function with the provided arguments.
*/
function unconstruct(Func) {
	return function() {
		for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) args[_key4] = arguments[_key4];
		return construct(Func, args);
	};
}
/**
* Add properties to a lookup table
*
* @param set - The set to which elements will be added.
* @param array - The array containing elements to be added to the set.
* @param transformCaseFunc - An optional function to transform the case of each element before adding to the set.
* @returns The modified set with added elements.
*/
function addToSet(set, array) {
	let transformCaseFunc = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : stringToLowerCase;
	if (setPrototypeOf) setPrototypeOf(set, null);
	if (!arrayIsArray(array)) return set;
	let l = array.length;
	while (l--) {
		let element = array[l];
		if (typeof element === "string") {
			const lcElement = transformCaseFunc(element);
			if (lcElement !== element) {
				if (!isFrozen(array)) array[l] = lcElement;
				element = lcElement;
			}
		}
		set[element] = true;
	}
	return set;
}
/**
* Clean up an array to harden against CSPP
*
* @param array - The array to be cleaned.
* @returns The cleaned version of the array
*/
function cleanArray(array) {
	for (let index = 0; index < array.length; index++) if (!objectHasOwnProperty(array, index)) array[index] = null;
	return array;
}
/**
* Shallow clone an object
*
* @param object - The object to be cloned.
* @returns A new object that copies the original.
*/
function clone(object) {
	const newObject = create(null);
	for (const _ref2 of entries(object)) {
		var _ref3 = _slicedToArray(_ref2, 2);
		const property = _ref3[0];
		const value = _ref3[1];
		if (objectHasOwnProperty(object, property)) if (arrayIsArray(value)) newObject[property] = cleanArray(value);
		else if (value && typeof value === "object" && value.constructor === Object) newObject[property] = clone(value);
		else newObject[property] = value;
	}
	return newObject;
}
/**
* Convert non-node values into strings without depending on direct property access.
*
* @param value - The value to stringify.
* @returns A string representation of the provided value.
*/
function stringifyValue(value) {
	switch (typeof value) {
		case "string": return value;
		case "number": return numberToString(value);
		case "boolean": return booleanToString(value);
		case "bigint": return bigintToString ? bigintToString(value) : "0";
		case "symbol": return symbolToString ? symbolToString(value) : "Symbol()";
		case "undefined": return objectToString(value);
		case "function":
		case "object": {
			if (value === null) return objectToString(value);
			const valueAsRecord = value;
			const valueToString = lookupGetter(valueAsRecord, "toString");
			if (typeof valueToString === "function") {
				const stringified = valueToString(valueAsRecord);
				return typeof stringified === "string" ? stringified : objectToString(stringified);
			}
			return objectToString(value);
		}
		default: return objectToString(value);
	}
}
/**
* This method automatically checks if the prop is function or getter and behaves accordingly.
*
* @param object - The object to look up the getter function in its prototype chain.
* @param prop - The property name for which to find the getter function.
* @returns The getter function found in the prototype chain or a fallback function.
*/
function lookupGetter(object, prop) {
	while (object !== null) {
		const desc = getOwnPropertyDescriptor(object, prop);
		if (desc) {
			if (desc.get) return unapply(desc.get);
			if (typeof desc.value === "function") return unapply(desc.value);
		}
		object = getPrototypeOf(object);
	}
	function fallbackValue() {
		return null;
	}
	return fallbackValue;
}
function isRegex(value) {
	try {
		regExpTest(value, "");
		return true;
	} catch (_unused) {
		return false;
	}
}
var html$1 = freeze([
	"a",
	"abbr",
	"acronym",
	"address",
	"area",
	"article",
	"aside",
	"audio",
	"b",
	"bdi",
	"bdo",
	"big",
	"blink",
	"blockquote",
	"body",
	"br",
	"button",
	"canvas",
	"caption",
	"center",
	"cite",
	"code",
	"col",
	"colgroup",
	"content",
	"data",
	"datalist",
	"dd",
	"decorator",
	"del",
	"details",
	"dfn",
	"dialog",
	"dir",
	"div",
	"dl",
	"dt",
	"element",
	"em",
	"fieldset",
	"figcaption",
	"figure",
	"font",
	"footer",
	"form",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"head",
	"header",
	"hgroup",
	"hr",
	"html",
	"i",
	"img",
	"input",
	"ins",
	"kbd",
	"label",
	"legend",
	"li",
	"main",
	"map",
	"mark",
	"marquee",
	"menu",
	"menuitem",
	"meter",
	"nav",
	"nobr",
	"ol",
	"optgroup",
	"option",
	"output",
	"p",
	"picture",
	"pre",
	"progress",
	"q",
	"rp",
	"rt",
	"ruby",
	"s",
	"samp",
	"search",
	"section",
	"select",
	"shadow",
	"slot",
	"small",
	"source",
	"spacer",
	"span",
	"strike",
	"strong",
	"style",
	"sub",
	"summary",
	"sup",
	"table",
	"tbody",
	"td",
	"template",
	"textarea",
	"tfoot",
	"th",
	"thead",
	"time",
	"tr",
	"track",
	"tt",
	"u",
	"ul",
	"var",
	"video",
	"wbr"
]);
var svg$1 = freeze([
	"svg",
	"a",
	"altglyph",
	"altglyphdef",
	"altglyphitem",
	"animatecolor",
	"animatemotion",
	"animatetransform",
	"circle",
	"clippath",
	"defs",
	"desc",
	"ellipse",
	"enterkeyhint",
	"exportparts",
	"filter",
	"font",
	"g",
	"glyph",
	"glyphref",
	"hkern",
	"image",
	"inputmode",
	"line",
	"lineargradient",
	"marker",
	"mask",
	"metadata",
	"mpath",
	"part",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialgradient",
	"rect",
	"stop",
	"style",
	"switch",
	"symbol",
	"text",
	"textpath",
	"title",
	"tref",
	"tspan",
	"view",
	"vkern"
]);
var svgFilters = freeze([
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence"
]);
var svgDisallowed = freeze([
	"animate",
	"color-profile",
	"cursor",
	"discard",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-src",
	"font-face-uri",
	"foreignobject",
	"hatch",
	"hatchpath",
	"mesh",
	"meshgradient",
	"meshpatch",
	"meshrow",
	"missing-glyph",
	"script",
	"set",
	"solidcolor",
	"unknown",
	"use"
]);
var mathMl$1 = freeze([
	"math",
	"menclose",
	"merror",
	"mfenced",
	"mfrac",
	"mglyph",
	"mi",
	"mlabeledtr",
	"mmultiscripts",
	"mn",
	"mo",
	"mover",
	"mpadded",
	"mphantom",
	"mroot",
	"mrow",
	"ms",
	"mspace",
	"msqrt",
	"mstyle",
	"msub",
	"msup",
	"msubsup",
	"mtable",
	"mtd",
	"mtext",
	"mtr",
	"munder",
	"munderover",
	"mprescripts"
]);
var mathMlDisallowed = freeze([
	"maction",
	"maligngroup",
	"malignmark",
	"mlongdiv",
	"mscarries",
	"mscarry",
	"msgroup",
	"mstack",
	"msline",
	"msrow",
	"semantics",
	"annotation",
	"annotation-xml",
	"mprescripts",
	"none"
]);
var text = freeze(["#text"]);
var html = freeze([
	"accept",
	"action",
	"align",
	"alt",
	"autocapitalize",
	"autocomplete",
	"autopictureinpicture",
	"autoplay",
	"background",
	"bgcolor",
	"border",
	"capture",
	"cellpadding",
	"cellspacing",
	"checked",
	"cite",
	"class",
	"clear",
	"color",
	"cols",
	"colspan",
	"command",
	"commandfor",
	"controls",
	"controlslist",
	"coords",
	"crossorigin",
	"datetime",
	"decoding",
	"default",
	"dir",
	"disabled",
	"disablepictureinpicture",
	"disableremoteplayback",
	"download",
	"draggable",
	"enctype",
	"enterkeyhint",
	"exportparts",
	"face",
	"for",
	"headers",
	"height",
	"hidden",
	"high",
	"href",
	"hreflang",
	"id",
	"inert",
	"inputmode",
	"integrity",
	"ismap",
	"kind",
	"label",
	"lang",
	"list",
	"loading",
	"loop",
	"low",
	"max",
	"maxlength",
	"media",
	"method",
	"min",
	"minlength",
	"multiple",
	"muted",
	"name",
	"nonce",
	"noshade",
	"novalidate",
	"nowrap",
	"open",
	"optimum",
	"part",
	"pattern",
	"placeholder",
	"playsinline",
	"popover",
	"popovertarget",
	"popovertargetaction",
	"poster",
	"preload",
	"pubdate",
	"radiogroup",
	"readonly",
	"rel",
	"required",
	"rev",
	"reversed",
	"role",
	"rows",
	"rowspan",
	"spellcheck",
	"scope",
	"selected",
	"shape",
	"size",
	"sizes",
	"slot",
	"span",
	"srclang",
	"start",
	"src",
	"srcset",
	"step",
	"style",
	"summary",
	"tabindex",
	"title",
	"translate",
	"type",
	"usemap",
	"valign",
	"value",
	"width",
	"wrap",
	"xmlns"
]);
var svg = freeze([
	"accent-height",
	"accumulate",
	"additive",
	"alignment-baseline",
	"amplitude",
	"ascent",
	"attributename",
	"attributetype",
	"azimuth",
	"basefrequency",
	"baseline-shift",
	"begin",
	"bias",
	"by",
	"class",
	"clip",
	"clippathunits",
	"clip-path",
	"clip-rule",
	"color",
	"color-interpolation",
	"color-interpolation-filters",
	"color-profile",
	"color-rendering",
	"cx",
	"cy",
	"d",
	"dx",
	"dy",
	"diffuseconstant",
	"direction",
	"display",
	"divisor",
	"dominant-baseline",
	"dur",
	"edgemode",
	"elevation",
	"end",
	"exponent",
	"fill",
	"fill-opacity",
	"fill-rule",
	"filter",
	"filterunits",
	"flood-color",
	"flood-opacity",
	"font-family",
	"font-size",
	"font-size-adjust",
	"font-stretch",
	"font-style",
	"font-variant",
	"font-weight",
	"fx",
	"fy",
	"g1",
	"g2",
	"glyph-name",
	"glyphref",
	"gradientunits",
	"gradienttransform",
	"height",
	"href",
	"id",
	"image-rendering",
	"in",
	"in2",
	"intercept",
	"k",
	"k1",
	"k2",
	"k3",
	"k4",
	"kerning",
	"keypoints",
	"keysplines",
	"keytimes",
	"lang",
	"lengthadjust",
	"letter-spacing",
	"kernelmatrix",
	"kernelunitlength",
	"lighting-color",
	"local",
	"marker-end",
	"marker-mid",
	"marker-start",
	"markerheight",
	"markerunits",
	"markerwidth",
	"maskcontentunits",
	"maskunits",
	"max",
	"mask",
	"mask-type",
	"media",
	"method",
	"mode",
	"min",
	"name",
	"numoctaves",
	"offset",
	"operator",
	"opacity",
	"order",
	"orient",
	"orientation",
	"origin",
	"overflow",
	"paint-order",
	"path",
	"pathlength",
	"patterncontentunits",
	"patterntransform",
	"patternunits",
	"points",
	"preservealpha",
	"preserveaspectratio",
	"primitiveunits",
	"r",
	"rx",
	"ry",
	"radius",
	"refx",
	"refy",
	"repeatcount",
	"repeatdur",
	"restart",
	"result",
	"rotate",
	"scale",
	"seed",
	"shape-rendering",
	"slope",
	"specularconstant",
	"specularexponent",
	"spreadmethod",
	"startoffset",
	"stddeviation",
	"stitchtiles",
	"stop-color",
	"stop-opacity",
	"stroke-dasharray",
	"stroke-dashoffset",
	"stroke-linecap",
	"stroke-linejoin",
	"stroke-miterlimit",
	"stroke-opacity",
	"stroke",
	"stroke-width",
	"style",
	"surfacescale",
	"systemlanguage",
	"tabindex",
	"tablevalues",
	"targetx",
	"targety",
	"transform",
	"transform-origin",
	"text-anchor",
	"text-decoration",
	"text-orientation",
	"text-rendering",
	"textlength",
	"type",
	"u1",
	"u2",
	"unicode",
	"values",
	"viewbox",
	"visibility",
	"version",
	"vert-adv-y",
	"vert-origin-x",
	"vert-origin-y",
	"width",
	"word-spacing",
	"wrap",
	"writing-mode",
	"xchannelselector",
	"ychannelselector",
	"x",
	"x1",
	"x2",
	"xmlns",
	"y",
	"y1",
	"y2",
	"z",
	"zoomandpan"
]);
var mathMl = freeze([
	"accent",
	"accentunder",
	"align",
	"bevelled",
	"close",
	"columnalign",
	"columnlines",
	"columnspacing",
	"columnspan",
	"denomalign",
	"depth",
	"dir",
	"display",
	"displaystyle",
	"encoding",
	"fence",
	"frame",
	"height",
	"href",
	"id",
	"largeop",
	"length",
	"linethickness",
	"lquote",
	"lspace",
	"mathbackground",
	"mathcolor",
	"mathsize",
	"mathvariant",
	"maxsize",
	"minsize",
	"movablelimits",
	"notation",
	"numalign",
	"open",
	"rowalign",
	"rowlines",
	"rowspacing",
	"rowspan",
	"rspace",
	"rquote",
	"scriptlevel",
	"scriptminsize",
	"scriptsizemultiplier",
	"selection",
	"separator",
	"separators",
	"stretchy",
	"subscriptshift",
	"supscriptshift",
	"symmetric",
	"voffset",
	"width",
	"xmlns"
]);
var xml = freeze([
	"xlink:href",
	"xml:id",
	"xlink:title",
	"xml:space",
	"xmlns:xlink"
]);
var MUSTACHE_EXPR = seal(/{{[\w\W]*|^[\w\W]*}}/g);
var ERB_EXPR = seal(/<%[\w\W]*|^[\w\W]*%>/g);
var TMPLIT_EXPR = seal(/\${[\w\W]*/g);
var DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/);
var ARIA_ATTR = seal(/^aria-[\-\w]+$/);
var IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i);
var IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
var ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g);
var DOCTYPE_NAME = seal(/^html$/i);
var CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);
var ELEMENT_MARKUP_PROBE = seal(/<[/\w!]/g);
var COMMENT_MARKUP_PROBE = seal(/<[/\w]/g);
var FALLBACK_TAG_CLOSE = seal(/<\/no(script|embed|frames)/i);
var SELF_CLOSING_TAG = seal(/\/>/i);
var NODE_TYPE = {
	element: 1,
	attribute: 2,
	text: 3,
	cdataSection: 4,
	entityReference: 5,
	entityNode: 6,
	processingInstruction: 7,
	comment: 8,
	document: 9,
	documentType: 10,
	documentFragment: 11,
	notation: 12
};
var getGlobal = function getGlobal() {
	return typeof window === "undefined" ? null : window;
};
/**
* Creates a no-op policy for internal use only.
* Don't export this function outside this module!
* @param trustedTypes The policy factory.
* @param purifyHostElement The Script element used to load DOMPurify (to determine policy name suffix).
* @return The policy created (or null, if Trusted Types
* are not supported or creating the policy failed).
*/
var _createTrustedTypesPolicy = function _createTrustedTypesPolicy(trustedTypes, purifyHostElement) {
	if (typeof trustedTypes !== "object" || typeof trustedTypes.createPolicy !== "function") return null;
	let suffix = null;
	const ATTR_NAME = "data-tt-policy-suffix";
	if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) suffix = purifyHostElement.getAttribute(ATTR_NAME);
	const policyName = "dompurify" + (suffix ? "#" + suffix : "");
	try {
		return trustedTypes.createPolicy(policyName, {
			createHTML(html) {
				return html;
			},
			createScriptURL(scriptUrl) {
				return scriptUrl;
			}
		});
	} catch (_) {
		console.warn("TrustedTypes policy " + policyName + " could not be created.");
		return null;
	}
};
var _createHooksMap = function _createHooksMap() {
	return {
		afterSanitizeAttributes: [],
		afterSanitizeElements: [],
		afterSanitizeShadowDOM: [],
		beforeSanitizeAttributes: [],
		beforeSanitizeElements: [],
		beforeSanitizeShadowDOM: [],
		uponSanitizeAttribute: [],
		uponSanitizeElement: [],
		uponSanitizeShadowNode: []
	};
};
/**
* Resolve a set-valued configuration option: a fresh set built from
* cfg[key] when it is an own array property (seeded with a clone of
* options.base when given, case-normalized via options.transform),
* the fallback set otherwise.
*
* @param cfg the cloned, prototype-free configuration object
* @param key the configuration property to read
* @param fallback the set to use when the option is absent or not an array
* @param options transform and optional base set to merge into
* @returns the resolved set
*/
var _resolveSetOption = function _resolveSetOption(cfg, key, fallback, options) {
	return objectHasOwnProperty(cfg, key) && arrayIsArray(cfg[key]) ? addToSet(options.base ? clone(options.base) : {}, cfg[key], options.transform) : fallback;
};
function createDOMPurify() {
	let window = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : getGlobal();
	const DOMPurify = (root) => createDOMPurify(root);
	DOMPurify.version = "3.4.12";
	DOMPurify.removed = [];
	if (!window || !window.document || window.document.nodeType !== NODE_TYPE.document || !window.Element) {
		DOMPurify.isSupported = false;
		return DOMPurify;
	}
	let document = window.document;
	const originalDocument = document;
	const currentScript = originalDocument.currentScript;
	window.DocumentFragment;
	const HTMLTemplateElement = window.HTMLTemplateElement, Node = window.Node, Element = window.Element, NodeFilter = window.NodeFilter;
	window.NamedNodeMap === void 0 && (window.NamedNodeMap || window.MozNamedAttrMap);
	window.HTMLFormElement;
	const DOMParser = window.DOMParser, trustedTypes = window.trustedTypes;
	const ElementPrototype = Element.prototype;
	const cloneNode = lookupGetter(ElementPrototype, "cloneNode");
	const remove = lookupGetter(ElementPrototype, "remove");
	const getNextSibling = lookupGetter(ElementPrototype, "nextSibling");
	const getChildNodes = lookupGetter(ElementPrototype, "childNodes");
	const getParentNode = lookupGetter(ElementPrototype, "parentNode");
	const getShadowRoot = lookupGetter(ElementPrototype, "shadowRoot");
	const getAttributes = lookupGetter(ElementPrototype, "attributes");
	const getNodeType = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeType") : null;
	const getNodeName = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeName") : null;
	if (typeof HTMLTemplateElement === "function") {
		const template = document.createElement("template");
		if (template.content && template.content.ownerDocument) document = template.content.ownerDocument;
	}
	let trustedTypesPolicy;
	let emptyHTML = "";
	let defaultTrustedTypesPolicy;
	let defaultTrustedTypesPolicyResolved = false;
	let IN_TRUSTED_TYPES_POLICY = 0;
	const _assertNotInTrustedTypesPolicy = function _assertNotInTrustedTypesPolicy() {
		if (IN_TRUSTED_TYPES_POLICY > 0) throw typeErrorCreate("A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the \"DOMPurify and Trusted Types\" section of the README.");
	};
	const _createTrustedHTML = function _createTrustedHTML(html) {
		_assertNotInTrustedTypesPolicy();
		IN_TRUSTED_TYPES_POLICY++;
		try {
			return trustedTypesPolicy.createHTML(html);
		} finally {
			IN_TRUSTED_TYPES_POLICY--;
		}
	};
	const _createTrustedScriptURL = function _createTrustedScriptURL(scriptUrl) {
		_assertNotInTrustedTypesPolicy();
		IN_TRUSTED_TYPES_POLICY++;
		try {
			return trustedTypesPolicy.createScriptURL(scriptUrl);
		} finally {
			IN_TRUSTED_TYPES_POLICY--;
		}
	};
	const _getDefaultTrustedTypesPolicy = function _getDefaultTrustedTypesPolicy() {
		if (!defaultTrustedTypesPolicyResolved) {
			defaultTrustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
			defaultTrustedTypesPolicyResolved = true;
		}
		return defaultTrustedTypesPolicy;
	};
	const _document = document, implementation = _document.implementation, createNodeIterator = _document.createNodeIterator, createDocumentFragment = _document.createDocumentFragment, getElementsByTagName = _document.getElementsByTagName;
	const importNode = originalDocument.importNode;
	let hooks = _createHooksMap();
	/**
	* Expose whether this browser supports running the full DOMPurify.
	*/
	DOMPurify.isSupported = typeof entries === "function" && typeof getParentNode === "function" && implementation && implementation.createHTMLDocument !== void 0;
	const MUSTACHE_EXPR$1 = MUSTACHE_EXPR, ERB_EXPR$1 = ERB_EXPR, TMPLIT_EXPR$1 = TMPLIT_EXPR, DATA_ATTR$1 = DATA_ATTR, ARIA_ATTR$1 = ARIA_ATTR, IS_SCRIPT_OR_DATA$1 = IS_SCRIPT_OR_DATA, ATTR_WHITESPACE$1 = ATTR_WHITESPACE, CUSTOM_ELEMENT$1 = CUSTOM_ELEMENT;
	let IS_ALLOWED_URI$1 = IS_ALLOWED_URI;
	/**
	* We consider the elements and attributes below to be safe. Ideally
	* don't add any new ones but feel free to remove unwanted ones.
	*/
	let ALLOWED_TAGS = null;
	const DEFAULT_ALLOWED_TAGS = addToSet({}, [
		...html$1,
		...svg$1,
		...svgFilters,
		...mathMl$1,
		...text
	]);
	let ALLOWED_ATTR = null;
	const DEFAULT_ALLOWED_ATTR = addToSet({}, [
		...html,
		...svg,
		...mathMl,
		...xml
	]);
	let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
		tagNameCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		},
		attributeNameCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		},
		allowCustomizedBuiltInElements: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: false
		}
	}));
	let FORBID_TAGS = null;
	let FORBID_ATTR = null;
	const EXTRA_ELEMENT_HANDLING = Object.seal(create(null, {
		tagCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		},
		attributeCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		}
	}));
	let ALLOW_ARIA_ATTR = true;
	let ALLOW_DATA_ATTR = true;
	let ALLOW_UNKNOWN_PROTOCOLS = false;
	let ALLOW_SELF_CLOSE_IN_ATTR = true;
	let SAFE_FOR_TEMPLATES = false;
	let SAFE_FOR_XML = true;
	let WHOLE_DOCUMENT = false;
	let SET_CONFIG = false;
	let SET_CONFIG_ALLOWED_TAGS = null;
	let SET_CONFIG_ALLOWED_ATTR = null;
	let FORCE_BODY = false;
	let RETURN_DOM = false;
	let RETURN_DOM_FRAGMENT = false;
	let RETURN_TRUSTED_TYPE = false;
	let SANITIZE_DOM = true;
	let SANITIZE_NAMED_PROPS = false;
	const SANITIZE_NAMED_PROPS_PREFIX = "user-content-";
	let KEEP_CONTENT = true;
	let IN_PLACE = false;
	let USE_PROFILES = {};
	let FORBID_CONTENTS = null;
	const DEFAULT_FORBID_CONTENTS = addToSet({}, [
		"annotation-xml",
		"audio",
		"colgroup",
		"desc",
		"foreignobject",
		"head",
		"iframe",
		"math",
		"mi",
		"mn",
		"mo",
		"ms",
		"mtext",
		"noembed",
		"noframes",
		"noscript",
		"plaintext",
		"script",
		"selectedcontent",
		"style",
		"svg",
		"template",
		"thead",
		"title",
		"video",
		"xmp"
	]);
	let DATA_URI_TAGS = null;
	const DEFAULT_DATA_URI_TAGS = addToSet({}, [
		"audio",
		"video",
		"img",
		"source",
		"image",
		"track"
	]);
	let URI_SAFE_ATTRIBUTES = null;
	const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, [
		"alt",
		"class",
		"for",
		"id",
		"label",
		"name",
		"pattern",
		"placeholder",
		"role",
		"summary",
		"title",
		"value",
		"style",
		"xmlns"
	]);
	const MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML";
	const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
	const HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
	let NAMESPACE = HTML_NAMESPACE;
	let IS_EMPTY_INPUT = false;
	let ALLOWED_NAMESPACES = null;
	const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [
		MATHML_NAMESPACE,
		SVG_NAMESPACE,
		HTML_NAMESPACE
	], stringToString);
	const DEFAULT_MATHML_TEXT_INTEGRATION_POINTS = freeze([
		"mi",
		"mo",
		"mn",
		"ms",
		"mtext"
	]);
	let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
	const DEFAULT_HTML_INTEGRATION_POINTS = freeze(["annotation-xml"]);
	let HTML_INTEGRATION_POINTS = addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
	const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, [
		"title",
		"style",
		"font",
		"a",
		"script"
	]);
	let PARSER_MEDIA_TYPE = null;
	const SUPPORTED_PARSER_MEDIA_TYPES = ["application/xhtml+xml", "text/html"];
	const DEFAULT_PARSER_MEDIA_TYPE = "text/html";
	let transformCaseFunc = null;
	let CONFIG = null;
	const formElement = document.createElement("form");
	const isRegexOrFunction = function isRegexOrFunction(testValue) {
		return testValue instanceof RegExp || testValue instanceof Function;
	};
	/**
	* _parseConfig
	*
	* @param cfg optional config literal
	*/
	const _parseConfig = function _parseConfig() {
		let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		if (CONFIG && CONFIG === cfg) return;
		if (!cfg || typeof cfg !== "object") cfg = {};
		cfg = clone(cfg);
		PARSER_MEDIA_TYPE = SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
		transformCaseFunc = PARSER_MEDIA_TYPE === "application/xhtml+xml" ? stringToString : stringToLowerCase;
		ALLOWED_TAGS = _resolveSetOption(cfg, "ALLOWED_TAGS", DEFAULT_ALLOWED_TAGS, { transform: transformCaseFunc });
		ALLOWED_ATTR = _resolveSetOption(cfg, "ALLOWED_ATTR", DEFAULT_ALLOWED_ATTR, { transform: transformCaseFunc });
		ALLOWED_NAMESPACES = _resolveSetOption(cfg, "ALLOWED_NAMESPACES", DEFAULT_ALLOWED_NAMESPACES, { transform: stringToString });
		URI_SAFE_ATTRIBUTES = _resolveSetOption(cfg, "ADD_URI_SAFE_ATTR", DEFAULT_URI_SAFE_ATTRIBUTES, {
			transform: transformCaseFunc,
			base: DEFAULT_URI_SAFE_ATTRIBUTES
		});
		DATA_URI_TAGS = _resolveSetOption(cfg, "ADD_DATA_URI_TAGS", DEFAULT_DATA_URI_TAGS, {
			transform: transformCaseFunc,
			base: DEFAULT_DATA_URI_TAGS
		});
		FORBID_CONTENTS = _resolveSetOption(cfg, "FORBID_CONTENTS", DEFAULT_FORBID_CONTENTS, { transform: transformCaseFunc });
		FORBID_TAGS = _resolveSetOption(cfg, "FORBID_TAGS", clone({}), { transform: transformCaseFunc });
		FORBID_ATTR = _resolveSetOption(cfg, "FORBID_ATTR", clone({}), { transform: transformCaseFunc });
		USE_PROFILES = objectHasOwnProperty(cfg, "USE_PROFILES") ? cfg.USE_PROFILES && typeof cfg.USE_PROFILES === "object" ? clone(cfg.USE_PROFILES) : cfg.USE_PROFILES : false;
		ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false;
		ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false;
		ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false;
		ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false;
		SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false;
		SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false;
		WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false;
		RETURN_DOM = cfg.RETURN_DOM || false;
		RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false;
		RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false;
		FORCE_BODY = cfg.FORCE_BODY || false;
		SANITIZE_DOM = cfg.SANITIZE_DOM !== false;
		SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false;
		KEEP_CONTENT = cfg.KEEP_CONTENT !== false;
		IN_PLACE = cfg.IN_PLACE || false;
		IS_ALLOWED_URI$1 = isRegex(cfg.ALLOWED_URI_REGEXP) ? cfg.ALLOWED_URI_REGEXP : IS_ALLOWED_URI;
		NAMESPACE = typeof cfg.NAMESPACE === "string" ? cfg.NAMESPACE : HTML_NAMESPACE;
		MATHML_TEXT_INTEGRATION_POINTS = objectHasOwnProperty(cfg, "MATHML_TEXT_INTEGRATION_POINTS") && cfg.MATHML_TEXT_INTEGRATION_POINTS && typeof cfg.MATHML_TEXT_INTEGRATION_POINTS === "object" ? clone(cfg.MATHML_TEXT_INTEGRATION_POINTS) : addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
		HTML_INTEGRATION_POINTS = objectHasOwnProperty(cfg, "HTML_INTEGRATION_POINTS") && cfg.HTML_INTEGRATION_POINTS && typeof cfg.HTML_INTEGRATION_POINTS === "object" ? clone(cfg.HTML_INTEGRATION_POINTS) : addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
		const customElementHandling = objectHasOwnProperty(cfg, "CUSTOM_ELEMENT_HANDLING") && cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING === "object" ? clone(cfg.CUSTOM_ELEMENT_HANDLING) : create(null);
		CUSTOM_ELEMENT_HANDLING = create(null);
		if (objectHasOwnProperty(customElementHandling, "tagNameCheck") && isRegexOrFunction(customElementHandling.tagNameCheck)) CUSTOM_ELEMENT_HANDLING.tagNameCheck = customElementHandling.tagNameCheck;
		if (objectHasOwnProperty(customElementHandling, "attributeNameCheck") && isRegexOrFunction(customElementHandling.attributeNameCheck)) CUSTOM_ELEMENT_HANDLING.attributeNameCheck = customElementHandling.attributeNameCheck;
		if (objectHasOwnProperty(customElementHandling, "allowCustomizedBuiltInElements") && typeof customElementHandling.allowCustomizedBuiltInElements === "boolean") CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = customElementHandling.allowCustomizedBuiltInElements;
		seal(CUSTOM_ELEMENT_HANDLING);
		if (SAFE_FOR_TEMPLATES) ALLOW_DATA_ATTR = false;
		if (RETURN_DOM_FRAGMENT) RETURN_DOM = true;
		if (USE_PROFILES) {
			ALLOWED_TAGS = addToSet({}, text);
			ALLOWED_ATTR = create(null);
			if (USE_PROFILES.html === true) {
				addToSet(ALLOWED_TAGS, html$1);
				addToSet(ALLOWED_ATTR, html);
			}
			if (USE_PROFILES.svg === true) {
				addToSet(ALLOWED_TAGS, svg$1);
				addToSet(ALLOWED_ATTR, svg);
				addToSet(ALLOWED_ATTR, xml);
			}
			if (USE_PROFILES.svgFilters === true) {
				addToSet(ALLOWED_TAGS, svgFilters);
				addToSet(ALLOWED_ATTR, svg);
				addToSet(ALLOWED_ATTR, xml);
			}
			if (USE_PROFILES.mathMl === true) {
				addToSet(ALLOWED_TAGS, mathMl$1);
				addToSet(ALLOWED_ATTR, mathMl);
				addToSet(ALLOWED_ATTR, xml);
			}
		}
		EXTRA_ELEMENT_HANDLING.tagCheck = null;
		EXTRA_ELEMENT_HANDLING.attributeCheck = null;
		if (objectHasOwnProperty(cfg, "ADD_TAGS")) {
			if (typeof cfg.ADD_TAGS === "function") EXTRA_ELEMENT_HANDLING.tagCheck = cfg.ADD_TAGS;
			else if (arrayIsArray(cfg.ADD_TAGS)) {
				if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) ALLOWED_TAGS = clone(ALLOWED_TAGS);
				addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
			}
		}
		if (objectHasOwnProperty(cfg, "ADD_ATTR")) {
			if (typeof cfg.ADD_ATTR === "function") EXTRA_ELEMENT_HANDLING.attributeCheck = cfg.ADD_ATTR;
			else if (arrayIsArray(cfg.ADD_ATTR)) {
				if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) ALLOWED_ATTR = clone(ALLOWED_ATTR);
				addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
			}
		}
		if (objectHasOwnProperty(cfg, "ADD_URI_SAFE_ATTR") && arrayIsArray(cfg.ADD_URI_SAFE_ATTR)) addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
		if (objectHasOwnProperty(cfg, "FORBID_CONTENTS") && arrayIsArray(cfg.FORBID_CONTENTS)) {
			if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) FORBID_CONTENTS = clone(FORBID_CONTENTS);
			addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
		}
		if (objectHasOwnProperty(cfg, "ADD_FORBID_CONTENTS") && arrayIsArray(cfg.ADD_FORBID_CONTENTS)) {
			if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) FORBID_CONTENTS = clone(FORBID_CONTENTS);
			addToSet(FORBID_CONTENTS, cfg.ADD_FORBID_CONTENTS, transformCaseFunc);
		}
		if (KEEP_CONTENT) ALLOWED_TAGS["#text"] = true;
		if (WHOLE_DOCUMENT) addToSet(ALLOWED_TAGS, [
			"html",
			"head",
			"body"
		]);
		if (ALLOWED_TAGS.table) {
			addToSet(ALLOWED_TAGS, ["tbody"]);
			delete FORBID_TAGS.tbody;
		}
		if (cfg.TRUSTED_TYPES_POLICY) {
			if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== "function") throw typeErrorCreate("TRUSTED_TYPES_POLICY configuration option must provide a \"createHTML\" hook.");
			if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== "function") throw typeErrorCreate("TRUSTED_TYPES_POLICY configuration option must provide a \"createScriptURL\" hook.");
			const previousTrustedTypesPolicy = trustedTypesPolicy;
			trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
			try {
				emptyHTML = _createTrustedHTML("");
			} catch (error) {
				trustedTypesPolicy = previousTrustedTypesPolicy;
				throw error;
			}
		} else if (cfg.TRUSTED_TYPES_POLICY === null) {
			trustedTypesPolicy = void 0;
			emptyHTML = "";
		} else {
			if (trustedTypesPolicy === void 0) trustedTypesPolicy = _getDefaultTrustedTypesPolicy();
			if (trustedTypesPolicy && typeof emptyHTML === "string") emptyHTML = _createTrustedHTML("");
		}
		if (freeze) freeze(cfg);
		CONFIG = cfg;
	};
	const ALL_SVG_TAGS = addToSet({}, [
		...svg$1,
		...svgFilters,
		...svgDisallowed
	]);
	const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
	/**
	* Namespace rules for an element in the SVG namespace.
	*
	* @param tagName the element's lowercase tag name
	* @param parent the (possibly simulated) parent node
	* @param parentTagName the parent's lowercase tag name
	* @returns true if a spec-compliant parser could produce this element
	*/
	const _checkSvgNamespace = function _checkSvgNamespace(tagName, parent, parentTagName) {
		if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "svg";
		if (parent.namespaceURI === MATHML_NAMESPACE) return tagName === "svg" && (parentTagName === "annotation-xml" || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
		return Boolean(ALL_SVG_TAGS[tagName]);
	};
	/**
	* Namespace rules for an element in the MathML namespace.
	*
	* @param tagName the element's lowercase tag name
	* @param parent the (possibly simulated) parent node
	* @param parentTagName the parent's lowercase tag name
	* @returns true if a spec-compliant parser could produce this element
	*/
	const _checkMathMlNamespace = function _checkMathMlNamespace(tagName, parent, parentTagName) {
		if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "math";
		if (parent.namespaceURI === SVG_NAMESPACE) return tagName === "math" && HTML_INTEGRATION_POINTS[parentTagName];
		return Boolean(ALL_MATHML_TAGS[tagName]);
	};
	/**
	* Namespace rules for an element in the HTML namespace.
	*
	* @param tagName the element's lowercase tag name
	* @param parent the (possibly simulated) parent node
	* @param parentTagName the parent's lowercase tag name
	* @returns true if a spec-compliant parser could produce this element
	*/
	const _checkHtmlNamespace = function _checkHtmlNamespace(tagName, parent, parentTagName) {
		if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) return false;
		if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) return false;
		return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
	};
	/**
	* @param element a DOM element whose namespace is being checked
	* @returns Return false if the element has a
	*  namespace that a spec-compliant parser would never
	*  return. Return true otherwise.
	*/
	const _checkValidNamespace = function _checkValidNamespace(element) {
		let parent = getParentNode(element);
		if (!parent || !parent.tagName) parent = {
			namespaceURI: NAMESPACE,
			tagName: "template"
		};
		const tagName = stringToLowerCase(element.tagName);
		const parentTagName = stringToLowerCase(parent.tagName);
		if (!ALLOWED_NAMESPACES[element.namespaceURI]) return false;
		if (element.namespaceURI === SVG_NAMESPACE) return _checkSvgNamespace(tagName, parent, parentTagName);
		if (element.namespaceURI === MATHML_NAMESPACE) return _checkMathMlNamespace(tagName, parent, parentTagName);
		if (element.namespaceURI === HTML_NAMESPACE) return _checkHtmlNamespace(tagName, parent, parentTagName);
		if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && ALLOWED_NAMESPACES[element.namespaceURI]) return true;
		return false;
	};
	/**
	* _forceRemove
	*
	* @param node a DOM node
	*/
	const _forceRemove = function _forceRemove(node) {
		arrayPush(DOMPurify.removed, { element: node });
		try {
			getParentNode(node).removeChild(node);
		} catch (_) {
			remove(node);
			if (!getParentNode(node)) throw typeErrorCreate("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
		}
	};
	/**
	* _neutralizeRoot
	*
	* Fail-closed teardown of an in-place root after the sanitize walk aborts
	* (campaign-3 F2). An internal throw mid-walk — e.g. a page-registered
	* custom element's reaction detaches a node so `_forceRemove`'s deliberate
	* parentless guard throws, or any other re-entrant engine mutation — would
	* otherwise leave the caller's *live* tree half-sanitized, with everything
	* after the abort point still carrying its handlers. There is no safe way
	* to resume the walk (the tree mutated under us), so we strip the root bare:
	* remove every child and every attribute, then let the caller's catch see
	* the original error. Clobber-safe (cached `remove`/`childNodes`/`attributes`
	* getters; the root was already clobber-pre-flighted at the IN_PLACE entry).
	*
	* @param root the in-place root to empty
	*/
	const _neutralizeRoot = function _neutralizeRoot(root) {
		_neutralizeSubtree(root);
		const childNodes = getChildNodes(root);
		if (childNodes) {
			const snapshot = [];
			arrayForEach(childNodes, (child) => {
				arrayPush(snapshot, child);
			});
			arrayForEach(snapshot, (child) => {
				try {
					remove(child);
				} catch (_) {}
			});
		}
		const attributes = getAttributes(root);
		if (attributes) for (let i = attributes.length - 1; i >= 0; --i) {
			const attribute = attributes[i];
			const name = attribute && attribute.name;
			if (typeof name === "string") try {
				root.removeAttribute(name);
			} catch (_) {}
		}
	};
	/**
	* _removeAttribute
	*
	* @param name an Attribute name
	* @param element a DOM node
	*/
	const _removeAttribute = function _removeAttribute(name, element) {
		try {
			arrayPush(DOMPurify.removed, {
				attribute: element.getAttributeNode(name),
				from: element
			});
		} catch (_) {
			arrayPush(DOMPurify.removed, {
				attribute: null,
				from: element
			});
		}
		element.removeAttribute(name);
		if (name === "is") if (RETURN_DOM || RETURN_DOM_FRAGMENT) try {
			_forceRemove(element);
		} catch (_) {}
		else try {
			element.setAttribute(name, "");
		} catch (_) {}
	};
	/**
	* _stripDisallowedAttributes
	*
	* Removes every attribute the active configuration does not allow from a
	* single element, using the same allowlist as the main attribute pass (so
	* `on*` handlers go, but no `/^on/` blocklist is introduced). Used only to
	* neutralise nodes that are being discarded from an in-place tree.
	*
	* @param element the element to strip
	*/
	const _stripDisallowedAttributes = function _stripDisallowedAttributes(element) {
		const attributes = getAttributes(element);
		if (!attributes) return;
		for (let i = attributes.length - 1; i >= 0; --i) {
			const attribute = attributes[i];
			const name = attribute && attribute.name;
			if (typeof name !== "string" || ALLOWED_ATTR[transformCaseFunc(name)]) continue;
			try {
				element.removeAttribute(name);
			} catch (_) {}
		}
	};
	/**
	* _neutralizeSubtree
	*
	* Completes the audit-5 F1 fix across every removal path. The KEEP_CONTENT
	* move-hoist neutralises only disallowed-tag removals; clobber, mXSS-canary,
	* namespace, comment, processing-instruction and KEEP_CONTENT:false removals
	* all drop their subtree wholesale via `_forceRemove`. On the IN_PLACE path
	* those dropped nodes are detached from the caller's LIVE tree but a
	* handler-bearing original among them (an `<img onerror>`/`<video>` that was
	* loading) keeps its queued resource event, which fires in page scope after
	* sanitize returns. This walks a removed subtree and strips every attribute
	* the active configuration does not allow — so `on*` handlers are cancelled
	* through the SAME allowlist that governs kept nodes, not a separate `/^on/`
	* blocklist. Run synchronously before sanitize returns, i.e. before any
	* queued event can fire. Hook-free by design: these nodes leave the output,
	* so firing attribute hooks for them would be surprising. Clobber-safe reads;
	* a doomed clobbered node may shadow `removeAttribute` (its own attributes are
	* irrelevant — it is discarded — while its non-clobbered descendants, e.g.
	* the `<img>`, are reached and scrubbed).
	*
	* @param root the root of a removed subtree to neutralise
	*/
	const _neutralizeSubtree = function _neutralizeSubtree(root) {
		const stack = [root];
		while (stack.length > 0) {
			const node = stack.pop();
			if ((getNodeType ? getNodeType(node) : node.nodeType) === NODE_TYPE.element) _stripDisallowedAttributes(node);
			const childNodes = getChildNodes(node);
			if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push(childNodes[i]);
		}
	};
	/**
	* _neutralizePatchLinkage
	*
	* IN_PLACE entry pre-pass (declarative-partial-updates / streaming
	* hardening, https://github.com/WICG/declarative-partial-updates).
	*
	* The main walk strips patch linkage (`for`/`patchsrc`) and removes range
	* markers (PIs / markup comments) node-by-node, in document order, AS it
	* reaches each node. On a live in-place root that leaves a window: from the
	* moment the root is connected until the walk arrives at a given node, that
	* node's linkage is live. A patch applied on connection/stream can fire as
	* a microtask during the walk and inject or teleport an unsanitized DOM
	* range into a region the iterator has already passed and will not revisit,
	* so the post-return "tree is sanitized" contract is violated. Sweep the
	* whole tree once up front and sever every linkage before the walk begins,
	* closing that window.
	*
	* This CANNOT undo a patch that already fired before sanitize ran — that is
	* the irreducible "do not IN_PLACE a live-connected attacker tree" caveat —
	* but it closes everything from sanitize-start onward. Gated on SAFE_FOR_XML
	* to group with the rest of the declarative-partial-updates handling and
	* stay overridable, consistent with the codebase.
	*
	* Clobber-safe traversal (cached childNodes getter); per-node try/catch so a
	* clobbered root cannot defeat the sweep of its non-clobbered descendants.
	*
	* NOTE (pending real-Chrome confirmation, see test/declarative-patch-probe
	* .html Q1): this mirrors the existing policy of keeping `for` on
	* <label>/<output>. If the shipping feature can drive a patch through a
	* surviving `for`-on-label/output + `id` pair, this pre-pass and the
	* attribute check at _isBasicCustomElement's caller must additionally drop
	* that pair on the IN_PLACE path. Left as-is until the taxonomy is verified.
	*
	* @param root the in-place root to sweep
	*/
	const _neutralizePatchLinkage = function _neutralizePatchLinkage(root) {
		if (!SAFE_FOR_XML) return;
		const stack = [root];
		while (stack.length > 0) {
			const node = stack.pop();
			const nodeType = getNodeType ? getNodeType(node) : node.nodeType;
			if (nodeType === NODE_TYPE.processingInstruction || nodeType === NODE_TYPE.comment && regExpTest(COMMENT_MARKUP_PROBE, node.data)) {
				try {
					remove(node);
				} catch (_) {}
				continue;
			}
			if (nodeType === NODE_TYPE.element) {
				const element = node;
				const lcTag = transformCaseFunc(getNodeName ? getNodeName(node) : node.nodeName);
				try {
					if (element.hasAttribute && element.hasAttribute("patchsrc")) element.removeAttribute("patchsrc");
					if (element.hasAttribute && element.hasAttribute("for") && lcTag !== "label" && lcTag !== "output") element.removeAttribute("for");
				} catch (_) {}
			}
			const childNodes = getChildNodes(node);
			if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push(childNodes[i]);
		}
	};
	/**
	* _initDocument
	*
	* @param dirty - a string of dirty markup
	* @return a DOM, filled with the dirty markup
	*/
	const _initDocument = function _initDocument(dirty) {
		let doc = null;
		let leadingWhitespace = null;
		if (FORCE_BODY) dirty = "<remove></remove>" + dirty;
		else {
			const matches = stringMatch(dirty, /^[\r\n\t ]+/);
			leadingWhitespace = matches && matches[0];
		}
		if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && NAMESPACE === HTML_NAMESPACE) dirty = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><head></head><body>" + dirty + "</body></html>";
		const dirtyPayload = trustedTypesPolicy ? _createTrustedHTML(dirty) : dirty;
		if (NAMESPACE === HTML_NAMESPACE) try {
			doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
		} catch (_) {}
		if (!doc || !doc.documentElement) {
			doc = implementation.createDocument(NAMESPACE, "template", null);
			try {
				doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
			} catch (_) {}
		}
		const body = doc.body || doc.documentElement;
		if (dirty && leadingWhitespace) body.insertBefore(document.createTextNode(leadingWhitespace), body.childNodes[0] || null);
		if (NAMESPACE === HTML_NAMESPACE) return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? "html" : "body")[0];
		return WHOLE_DOCUMENT ? doc.documentElement : body;
	};
	/**
	* Creates a NodeIterator object that you can use to traverse filtered lists of nodes or elements in a document.
	*
	* @param root The root element or node to start traversing on.
	* @return The created NodeIterator
	*/
	const _createNodeIterator = function _createNodeIterator(root) {
		return createNodeIterator.call(root.ownerDocument || root, root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
	};
	/**
	* Replace template expression syntax (mustache, ERB, template
	* literal) with a space; shared by all SAFE_FOR_TEMPLATES scrub
	* sites. Order matters: mustache, then ERB, then template literal.
	*
	* @param value the string to scrub
	* @returns the scrubbed string
	*/
	const _stripTemplateExpressions = function _stripTemplateExpressions(value) {
		value = stringReplace(value, MUSTACHE_EXPR$1, " ");
		value = stringReplace(value, ERB_EXPR$1, " ");
		value = stringReplace(value, TMPLIT_EXPR$1, " ");
		return value;
	};
	/**
	* Strip template-engine expressions ({{...}}, ${...}, <%...%>) from the
	* character data of an element subtree. Used as the final safety net for
	* SAFE_FOR_TEMPLATES on every DOM-returning code path so that expressions
	* which only form after text-node normalization (e.g. fragments split across
	* stripped elements) cannot survive into a template-evaluating framework.
	*
	* Walks text/comment/CDATA/processing-instruction nodes and mutates `.data`
	* in place rather than round-tripping through innerHTML. This preserves
	* descendant node references (important for IN_PLACE callers), avoids a
	* serialize/reparse cycle, and reads literal character data — which means
	* `<%...%>` in text content matches the ERB regex against its real bytes
	* instead of the HTML-entity-escaped form innerHTML would produce.
	*
	* Attribute values are not visited here; SAFE_FOR_TEMPLATES handling for
	* attributes is performed during the per-node `_sanitizeAttributes` pass.
	*
	* @param node The root element whose character data should be scrubbed.
	*/
	const _scrubTemplateExpressions2 = function _scrubTemplateExpressions(node) {
		var _node$querySelectorAl;
		node.normalize();
		const walker = createNodeIterator.call(node.ownerDocument || node, node, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_CDATA_SECTION | NodeFilter.SHOW_PROCESSING_INSTRUCTION, null);
		let currentNode = walker.nextNode();
		while (currentNode) {
			currentNode.data = _stripTemplateExpressions(currentNode.data);
			currentNode = walker.nextNode();
		}
		const templates = (_node$querySelectorAl = node.querySelectorAll) === null || _node$querySelectorAl === void 0 ? void 0 : _node$querySelectorAl.call(node, "template");
		if (templates) arrayForEach(templates, (tmpl) => {
			if (_isDocumentFragment(tmpl.content)) _scrubTemplateExpressions2(tmpl.content);
		});
	};
	/**
	* _isClobbered
	*
	* Detect DOM-clobbering on HTMLFormElement nodes. Form is the only HTML
	* interface with [LegacyOverrideBuiltIns]; a descendant element with a
	* `name` attribute matching a prototype property shadows that property
	* on direct reads. We use this check at the IN_PLACE entry-point and
	* during attribute sanitization to refuse clobbered forms.
	*
	* @param element element to check for clobbering attacks
	* @return true if clobbered, false if safe
	*/
	const _isClobbered = function _isClobbered(element) {
		const realTagName = getNodeName ? getNodeName(element) : null;
		if (typeof realTagName !== "string") return false;
		if (transformCaseFunc(realTagName) !== "form") return false;
		return typeof element.nodeName !== "string" || typeof element.textContent !== "string" || typeof element.removeChild !== "function" || element.attributes !== getAttributes(element) || typeof element.removeAttribute !== "function" || typeof element.setAttribute !== "function" || typeof element.namespaceURI !== "string" || typeof element.insertBefore !== "function" || typeof element.hasChildNodes !== "function" || element.nodeType !== getNodeType(element) || element.childNodes !== getChildNodes(element);
	};
	/**
	* Checks whether the given value is a DocumentFragment from any realm.
	*
	* The realm-independent replacement reads `nodeType` through the cached
	* Node.prototype getter and compares to the DOCUMENT_FRAGMENT_NODE
	* constant (11). nodeType is a numeric value resolved from the node's
	* internal slot, identical across realms for the same kind of node.
	*
	* @param value object to check
	* @return true if value is a DocumentFragment-shaped node from any realm
	*/
	const _isDocumentFragment = function _isDocumentFragment(value) {
		if (!getNodeType || typeof value !== "object" || value === null) return false;
		try {
			return getNodeType(value) === NODE_TYPE.documentFragment;
		} catch (_) {
			return false;
		}
	};
	/**
	* Checks whether the given object is a DOM node, including nodes that
	* originate from a different window/realm (e.g. an iframe's
	* contentDocument). The previous `value instanceof Node` check was
	* realm-bound: nodes from a different window failed it, causing
	* sanitize() to silently stringify them and reset IN_PLACE to false,
	* returning the original node unsanitized. See GHSA-4w3q-35jp-p934.
	*
	* @param value object to check whether it's a DOM node
	* @return true if value is a DOM node from any realm
	*/
	const _isNode = function _isNode(value) {
		if (!getNodeType || typeof value !== "object" || value === null) return false;
		try {
			return typeof getNodeType(value) === "number";
		} catch (_) {
			return false;
		}
	};
	function _executeHooks(hooks, currentNode, data) {
		if (hooks.length === 0) return;
		arrayForEach(hooks, (hook) => {
			hook.call(DOMPurify, currentNode, data, CONFIG);
		});
	}
	/**
	* Structural-threat checks that condemn a node regardless of the
	* allowlists: mXSS via namespace confusion, risky CSS construction,
	* processing instructions, markup-bearing comments. Pure predicate;
	* the caller removes. Check order is load-bearing.
	*
	* @param currentNode the node to inspect
	* @param tagName the node's transformCaseFunc'd tag name
	* @return true if the node must be removed
	*/
	const _isUnsafeNode = function _isUnsafeNode(currentNode, tagName) {
		if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.textContent) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.innerHTML)) return true;
		if (SAFE_FOR_XML && currentNode.namespaceURI === HTML_NAMESPACE && tagName === "style" && _isNode(currentNode.firstElementChild)) return true;
		if (currentNode.nodeType === NODE_TYPE.processingInstruction) return true;
		if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(COMMENT_MARKUP_PROBE, currentNode.data)) return true;
		return false;
	};
	/**
	* Handle a node whose tag is forbidden or not allowlisted: keep
	* allowed custom elements (false return exits _sanitizeElements
	* early - the namespace and fallback-tag removal checks are
	* intentionally skipped for kept custom elements), else hoist
	* content per KEEP_CONTENT and remove.
	*
	* A kept custom element is the ONLY case in which this function
	* returns false, so the caller uses that return value to run the
	* afterSanitizeElements hook on the kept element and keep the
	* element-hook lifecycle consistent with normal allowlisted
	* elements (GHSA-c2j3-45gr-mqc4).
	*
	* @param currentNode the disallowed node
	* @param tagName the node's transformCaseFunc'd tag name
	* @return true if the node was removed, false if kept
	*/
	const _sanitizeDisallowedNode = function _sanitizeDisallowedNode(currentNode, tagName) {
		if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName)) {
			if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) return false;
			if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName)) return false;
		}
		if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
			const parentNode = getParentNode(currentNode);
			const childNodes = getChildNodes(currentNode);
			if (childNodes && parentNode) {
				const childCount = childNodes.length;
				for (let i = childCount - 1; i >= 0; --i) {
					const hoisted = IN_PLACE ? childNodes[i] : cloneNode(childNodes[i], true);
					parentNode.insertBefore(hoisted, getNextSibling(currentNode));
				}
			}
		}
		_forceRemove(currentNode);
		return true;
	};
	/**
	* _sanitizeElements
	*
	* @protect nodeName
	* @protect textContent
	* @protect removeChild
	* @param currentNode to check for permission to exist
	* @return true if node was killed, false if left alive
	*/
	const _sanitizeElements = function _sanitizeElements(currentNode, root) {
		_executeHooks(hooks.beforeSanitizeElements, currentNode, null);
		if (currentNode !== root && getParentNode(currentNode) === null) return true;
		if (_isClobbered(currentNode)) {
			_forceRemove(currentNode);
			return true;
		}
		const tagName = transformCaseFunc(getNodeName ? getNodeName(currentNode) : currentNode.nodeName);
		_executeHooks(hooks.uponSanitizeElement, currentNode, {
			tagName,
			allowedTags: ALLOWED_TAGS
		});
		if (currentNode !== root && getParentNode(currentNode) === null) return true;
		if (_isUnsafeNode(currentNode, tagName)) {
			_forceRemove(currentNode);
			return true;
		}
		if (FORBID_TAGS[tagName] || !(EXTRA_ELEMENT_HANDLING.tagCheck instanceof Function && EXTRA_ELEMENT_HANDLING.tagCheck(tagName)) && !ALLOWED_TAGS[tagName]) {
			const removed = _sanitizeDisallowedNode(currentNode, tagName);
			if (removed === false) _executeHooks(hooks.afterSanitizeElements, currentNode, null);
			return removed;
		}
		if ((getNodeType ? getNodeType(currentNode) : currentNode.nodeType) === NODE_TYPE.element && !_checkValidNamespace(currentNode)) {
			_forceRemove(currentNode);
			return true;
		}
		if ((tagName === "noscript" || tagName === "noembed" || tagName === "noframes") && regExpTest(FALLBACK_TAG_CLOSE, currentNode.innerHTML)) {
			_forceRemove(currentNode);
			return true;
		}
		if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
			const content = _stripTemplateExpressions(currentNode.textContent);
			if (currentNode.textContent !== content) {
				arrayPush(DOMPurify.removed, { element: currentNode.cloneNode() });
				currentNode.textContent = content;
			}
		}
		_executeHooks(hooks.afterSanitizeElements, currentNode, null);
		return false;
	};
	/**
	* _isValidAttribute
	*
	* @param lcTag Lowercase tag name of containing element.
	* @param lcName Lowercase attribute name.
	* @param value Attribute value.
	* @return Returns true if `value` is valid, otherwise false.
	*/
	const _isValidAttribute = function _isValidAttribute(lcTag, lcName, value) {
		if (FORBID_ATTR[lcName]) return false;
		if (SAFE_FOR_XML && lcName === "patchsrc") return false;
		if (SAFE_FOR_XML && lcName === "for" && lcTag !== "label" && lcTag !== "output") return false;
		if (SANITIZE_DOM && (lcName === "id" || lcName === "name") && (value in document || value in formElement)) return false;
		const nameIsPermitted = ALLOWED_ATTR[lcName] || EXTRA_ELEMENT_HANDLING.attributeCheck instanceof Function && EXTRA_ELEMENT_HANDLING.attributeCheck(lcName, lcTag);
		if (ALLOW_DATA_ATTR && regExpTest(DATA_ATTR$1, lcName));
		else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR$1, lcName));
		else if (!nameIsPermitted) if (_isBasicCustomElement(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName, lcTag)) || lcName === "is" && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value)));
		else return false;
		else if (URI_SAFE_ATTRIBUTES[lcName]);
		else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE$1, "")));
		else if ((lcName === "src" || lcName === "xlink:href" || lcName === "href") && lcTag !== "script" && stringIndexOf(value, "data:") === 0 && DATA_URI_TAGS[lcTag]);
		else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA$1, stringReplace(value, ATTR_WHITESPACE$1, "")));
		else if (value) return false;
		return true;
	};
	const RESERVED_CUSTOM_ELEMENT_NAMES = addToSet({}, [
		"annotation-xml",
		"color-profile",
		"font-face",
		"font-face-format",
		"font-face-name",
		"font-face-src",
		"font-face-uri",
		"missing-glyph"
	]);
	/**
	* _isBasicCustomElement
	* checks if at least one dash is included in tagName, and it's not the first char
	* for more sophisticated checking see https://github.com/sindresorhus/validate-element-name
	*
	* @param tagName name of the tag of the node to sanitize
	* @returns Returns true if the tag name meets the basic criteria for a custom element, otherwise false.
	*/
	const _isBasicCustomElement = function _isBasicCustomElement(tagName) {
		return !RESERVED_CUSTOM_ELEMENT_NAMES[stringToLowerCase(tagName)] && regExpTest(CUSTOM_ELEMENT$1, tagName);
	};
	/**
	* Wrap an attribute value in the matching Trusted Types object when
	* the active policy requires it. Namespaced attributes pass through
	* unchanged (no TT support yet, see
	* https://bugs.chromium.org/p/chromium/issues/detail?id=1305293).
	*
	* @param lcTag lowercase tag name of the containing element
	* @param lcName lowercase attribute name
	* @param namespaceURI the attribute's namespace, if any
	* @param value the attribute value to wrap
	* @return the value, wrapped when Trusted Types demand it
	*/
	const _applyTrustedTypesToAttribute = function _applyTrustedTypesToAttribute(lcTag, lcName, namespaceURI, value) {
		if (trustedTypesPolicy && typeof trustedTypes === "object" && typeof trustedTypes.getAttributeType === "function" && !namespaceURI) switch (trustedTypes.getAttributeType(lcTag, lcName)) {
			case "TrustedHTML": return _createTrustedHTML(value);
			case "TrustedScriptURL": return _createTrustedScriptURL(value);
		}
		return value;
	};
	/**
	* Write a modified attribute value back onto the element. On
	* success, re-probe for clobbering introduced by the new value and
	* remove the element when found; otherwise pop the removal entry
	* recorded by the earlier _removeAttribute (long-standing pairing
	* with the SANITIZE_NAMED_PROPS path - do not "fix" casually). On
	* failure, remove the attribute instead.
	*
	* @param currentNode the element carrying the attribute
	* @param name the attribute name as present on the element
	* @param namespaceURI the attribute's namespace, if any
	* @param value the new attribute value
	*/
	const _setAttributeValue = function _setAttributeValue(currentNode, name, namespaceURI, value) {
		try {
			if (namespaceURI) currentNode.setAttributeNS(namespaceURI, name, value);
			else currentNode.setAttribute(name, value);
			if (_isClobbered(currentNode)) _forceRemove(currentNode);
			else arrayPop(DOMPurify.removed);
		} catch (_) {
			_removeAttribute(name, currentNode);
		}
	};
	/**
	* _sanitizeAttributes
	*
	* @protect attributes
	* @protect nodeName
	* @protect removeAttribute
	* @protect setAttribute
	*
	* @param currentNode to sanitize
	*/
	const _sanitizeAttributes = function _sanitizeAttributes(currentNode) {
		_executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
		const attributes = currentNode.attributes;
		if (!attributes || _isClobbered(currentNode)) return;
		const hookEvent = {
			attrName: "",
			attrValue: "",
			keepAttr: true,
			allowedAttributes: ALLOWED_ATTR,
			forceKeepAttr: void 0
		};
		let l = attributes.length;
		const lcTag = transformCaseFunc(currentNode.nodeName);
		while (l--) {
			const attr = attributes[l];
			const name = attr.name, namespaceURI = attr.namespaceURI, attrValue = attr.value;
			const lcName = transformCaseFunc(name);
			const initValue = attrValue;
			let value = name === "value" ? initValue : stringTrim(initValue);
			hookEvent.attrName = lcName;
			hookEvent.attrValue = value;
			hookEvent.keepAttr = true;
			hookEvent.forceKeepAttr = void 0;
			_executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
			value = hookEvent.attrValue;
			if (SANITIZE_NAMED_PROPS && (lcName === "id" || lcName === "name") && stringIndexOf(value, SANITIZE_NAMED_PROPS_PREFIX) !== 0) {
				_removeAttribute(name, currentNode);
				value = SANITIZE_NAMED_PROPS_PREFIX + value;
			}
			if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, value)) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (lcName === "attributename" && stringMatch(value, "href")) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (hookEvent.forceKeepAttr) continue;
			if (!hookEvent.keepAttr) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(SELF_CLOSING_TAG, value)) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (SAFE_FOR_TEMPLATES) value = _stripTemplateExpressions(value);
			if (!_isValidAttribute(lcTag, lcName, value)) {
				_removeAttribute(name, currentNode);
				continue;
			}
			value = _applyTrustedTypesToAttribute(lcTag, lcName, namespaceURI, value);
			if (value !== initValue) _setAttributeValue(currentNode, name, namespaceURI, value);
		}
		_executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
	};
	/**
	* _sanitizeShadowDOM
	*
	* @param fragment to iterate over recursively
	*/
	const _sanitizeShadowDOM2 = function _sanitizeShadowDOM(fragment) {
		let shadowNode = null;
		const shadowIterator = _createNodeIterator(fragment);
		_executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
		while (shadowNode = shadowIterator.nextNode()) {
			_executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
			_sanitizeElements(shadowNode, fragment);
			_sanitizeAttributes(shadowNode);
			if (_isDocumentFragment(shadowNode.content)) _sanitizeShadowDOM2(shadowNode.content);
			if ((getNodeType ? getNodeType(shadowNode) : shadowNode.nodeType) === NODE_TYPE.element) {
				const innerSr = getShadowRoot(shadowNode);
				if (_isDocumentFragment(innerSr)) {
					_sanitizeAttachedShadowRoots(innerSr);
					_sanitizeShadowDOM2(innerSr);
				}
			}
		}
		_executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
	};
	/**
	* _sanitizeAttachedShadowRoots
	*
	* Walks `root` and feeds every attached shadow root we encounter into
	* the existing _sanitizeShadowDOM pipeline. The default node iterator
	* does not descend into shadow trees, so nodes inside an attached
	* shadow root would otherwise be skipped entirely.
	*
	* Two real input paths put attached shadow roots in front of us:
	*   1. IN_PLACE on a DOM node that already has shadow roots attached.
	*   2. DOM-node input where importNode(dirty, true) deep-clones the
	*      shadow root because it was created with `clonable: true`.
	*
	* This pass runs once, up front, so the main iteration loop (and the
	* existing _sanitizeShadowDOM template-content recursion) stay
	* untouched — string-input paths are not affected.
	*
	* @param root the subtree root to walk for attached shadow roots
	*/
	const _sanitizeAttachedShadowRoots = function _sanitizeAttachedShadowRoots(root) {
		const stack = [{
			node: root,
			shadow: null
		}];
		while (stack.length > 0) {
			const item = stack.pop();
			if (item.shadow) {
				_sanitizeShadowDOM2(item.shadow);
				continue;
			}
			const node = item.node;
			const isElement = (getNodeType ? getNodeType(node) : node.nodeType) === NODE_TYPE.element;
			const childNodes = getChildNodes(node);
			if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push({
				node: childNodes[i],
				shadow: null
			});
			if (isElement) {
				const rootName = getNodeName ? getNodeName(node) : null;
				if (typeof rootName === "string" && transformCaseFunc(rootName) === "template") {
					const content = node.content;
					if (_isDocumentFragment(content)) stack.push({
						node: content,
						shadow: null
					});
				}
			}
			if (isElement) {
				const sr = getShadowRoot(node);
				if (_isDocumentFragment(sr)) stack.push({
					node: null,
					shadow: sr
				}, {
					node: sr,
					shadow: null
				});
			}
		}
	};
	DOMPurify.sanitize = function(dirty) {
		let cfg = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		let body = null;
		let importedNode = null;
		let currentNode = null;
		let returnNode = null;
		IS_EMPTY_INPUT = !dirty;
		if (IS_EMPTY_INPUT) dirty = "<!-->";
		if (typeof dirty !== "string" && !_isNode(dirty)) {
			dirty = stringifyValue(dirty);
			if (typeof dirty !== "string") throw typeErrorCreate("dirty is not a string, aborting");
		}
		if (!DOMPurify.isSupported) return dirty;
		if (SET_CONFIG) {
			ALLOWED_TAGS = SET_CONFIG_ALLOWED_TAGS;
			ALLOWED_ATTR = SET_CONFIG_ALLOWED_ATTR;
		} else _parseConfig(cfg);
		if (hooks.uponSanitizeElement.length > 0 || hooks.uponSanitizeAttribute.length > 0) ALLOWED_TAGS = clone(ALLOWED_TAGS);
		if (hooks.uponSanitizeAttribute.length > 0) ALLOWED_ATTR = clone(ALLOWED_ATTR);
		DOMPurify.removed = [];
		const inPlace = IN_PLACE && typeof dirty !== "string" && _isNode(dirty);
		if (inPlace) {
			_neutralizePatchLinkage(dirty);
			const nn = getNodeName ? getNodeName(dirty) : dirty.nodeName;
			if (typeof nn === "string") {
				const tagName = transformCaseFunc(nn);
				if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
					_neutralizeRoot(dirty);
					throw typeErrorCreate("root node is forbidden and cannot be sanitized in-place");
				}
			}
			if (_isClobbered(dirty)) {
				_neutralizeRoot(dirty);
				throw typeErrorCreate("root node is clobbered and cannot be sanitized in-place");
			}
			try {
				_sanitizeAttachedShadowRoots(dirty);
			} catch (error) {
				_neutralizeRoot(dirty);
				throw error;
			}
		} else if (_isNode(dirty)) {
			body = _initDocument("<!---->");
			importedNode = body.ownerDocument.importNode(dirty, true);
			if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === "BODY") body = importedNode;
			else if (importedNode.nodeName === "HTML") body = importedNode;
			else body.appendChild(importedNode);
			_sanitizeAttachedShadowRoots(importedNode);
		} else {
			if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT && dirty.indexOf("<") === -1) return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(dirty) : dirty;
			body = _initDocument(dirty);
			if (!body) return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : "";
		}
		if (body && FORCE_BODY) _forceRemove(body.firstChild);
		const walkRoot = inPlace ? dirty : body;
		const nodeIterator = _createNodeIterator(walkRoot);
		try {
			while (currentNode = nodeIterator.nextNode()) {
				_sanitizeElements(currentNode, walkRoot);
				_sanitizeAttributes(currentNode);
				if (_isDocumentFragment(currentNode.content)) _sanitizeShadowDOM2(currentNode.content);
			}
		} catch (error) {
			if (inPlace) {
				_neutralizeRoot(dirty);
				arrayForEach(DOMPurify.removed, (entry) => {
					if (entry.element) _neutralizeSubtree(entry.element);
				});
			}
			throw error;
		}
		if (inPlace) {
			arrayForEach(DOMPurify.removed, (entry) => {
				if (entry.element) _neutralizeSubtree(entry.element);
			});
			if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(dirty);
			return dirty;
		}
		if (RETURN_DOM) {
			if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(body);
			if (RETURN_DOM_FRAGMENT) {
				returnNode = createDocumentFragment.call(body.ownerDocument);
				while (body.firstChild) returnNode.appendChild(body.firstChild);
			} else returnNode = body;
			if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) returnNode = importNode.call(originalDocument, returnNode, true);
			return returnNode;
		}
		let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
		if (WHOLE_DOCUMENT && ALLOWED_TAGS["!doctype"] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) serializedHTML = "<!DOCTYPE " + body.ownerDocument.doctype.name + ">\n" + serializedHTML;
		if (SAFE_FOR_TEMPLATES) serializedHTML = _stripTemplateExpressions(serializedHTML);
		return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(serializedHTML) : serializedHTML;
	};
	DOMPurify.setConfig = function() {
		let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		_parseConfig(cfg);
		SET_CONFIG = true;
		SET_CONFIG_ALLOWED_TAGS = ALLOWED_TAGS;
		SET_CONFIG_ALLOWED_ATTR = ALLOWED_ATTR;
	};
	DOMPurify.clearConfig = function() {
		CONFIG = null;
		SET_CONFIG = false;
		SET_CONFIG_ALLOWED_TAGS = null;
		SET_CONFIG_ALLOWED_ATTR = null;
		trustedTypesPolicy = defaultTrustedTypesPolicy;
		emptyHTML = "";
	};
	DOMPurify.isValidAttribute = function(tag, attr, value) {
		if (!CONFIG) _parseConfig({});
		const lcTag = transformCaseFunc(tag);
		const lcName = transformCaseFunc(attr);
		return _isValidAttribute(lcTag, lcName, value);
	};
	DOMPurify.addHook = function(entryPoint, hookFunction) {
		if (typeof hookFunction !== "function") return;
		if (!objectHasOwnProperty(hooks, entryPoint)) return;
		arrayPush(hooks[entryPoint], hookFunction);
	};
	DOMPurify.removeHook = function(entryPoint, hookFunction) {
		if (!objectHasOwnProperty(hooks, entryPoint)) return;
		if (hookFunction !== void 0) {
			const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
			return index === -1 ? void 0 : arraySplice(hooks[entryPoint], index, 1)[0];
		}
		return arrayPop(hooks[entryPoint]);
	};
	DOMPurify.removeHooks = function(entryPoint) {
		if (!objectHasOwnProperty(hooks, entryPoint)) return;
		hooks[entryPoint] = [];
	};
	DOMPurify.removeAllHooks = function() {
		hooks = _createHooksMap();
	};
	return DOMPurify;
}
var purify = createDOMPurify();
var RICH_TEXT_TAGS = [
	"a",
	"abbr",
	"address",
	"article",
	"aside",
	"b",
	"bdi",
	"bdo",
	"big",
	"blockquote",
	"br",
	"caption",
	"center",
	"cite",
	"code",
	"col",
	"colgroup",
	"dd",
	"del",
	"div",
	"dl",
	"dt",
	"em",
	"fieldset",
	"font",
	"footer",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"header",
	"hr",
	"i",
	"img",
	"ins",
	"label",
	"legend",
	"li",
	"mark",
	"nav",
	"ol",
	"p",
	"pre",
	"q",
	"rt",
	"ruby",
	"s",
	"section",
	"small",
	"span",
	"strong",
	"sub",
	"sup",
	"table",
	"tbody",
	"td",
	"tfoot",
	"th",
	"thead",
	"tr",
	"tt",
	"u",
	"ul"
];
var richTextTagSet = new Set(RICH_TEXT_TAGS);
var spaceCharacters = {
	ensp: " ",
	emsp: " ",
	nbsp: "\xA0"
};
function sanitizeRichText(html) {
	return purify.sanitize(String(html ?? ""), {
		ALLOWED_TAGS: RICH_TEXT_TAGS,
		ALLOW_DATA_ATTR: true,
		ALLOW_UNKNOWN_PROTOCOLS: false,
		FORBID_ATTR: [
			"srcdoc",
			"formaction",
			"xlink:href"
		]
	});
}
function appendRichTextNode(parent, node, spaceType) {
	if (!node || typeof node !== "object") return;
	if (node.type === "text") {
		const replacement = spaceCharacters[spaceType] ?? " ";
		parent.append(document.createTextNode(String(node.text ?? "").replaceAll(" ", replacement)));
		return;
	}
	const tagName = String(node.name ?? "").toLowerCase();
	if (!richTextTagSet.has(tagName)) return;
	const element = document.createElement(tagName);
	if (node.attrs && typeof node.attrs === "object" && !Array.isArray(node.attrs)) for (const [name, value] of Object.entries(node.attrs)) try {
		element.setAttribute(name, String(value ?? ""));
	} catch {}
	for (const child of Array.isArray(node.children) ? node.children : []) appendRichTextNode(element, child, spaceType);
	parent.append(element);
}
function renderRichTextNodes(nodes, spaceType) {
	const container = document.createElement("div");
	for (const node of nodes) appendRichTextNode(container, node, spaceType);
	return container.innerHTML;
}
var _hoisted_1$7 = ["innerHTML"];
var _sfc_main$11 = {
	__name: "RichText",
	props: {
		/**
		* 节点列表/HTML String
		*/
		nodes: {
			type: [Array, String],
			default: () => []
		},
		/**
		* 显示连续空格
		* ensp	中文字符空格一半大小
		* emsp	中文字符空格大小
		* nbsp	根据字体设置的空格大小
		*/
		space: {
			type: String,
			validator: (value) => [
				"ensp",
				"emsp",
				"nbsp"
			].includes(value)
		},
		/**
		* 文本是否可选，该属性会使节点显示为 block
		*/
		userSelect: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const props = __props;
		const sanitizedHtml = /* @__PURE__ */ ref("");
		const scopeId = inject("info", {})?.sId;
		/**
		* 为已经清理过的 HTML 注入组件 scopeId（如 data-v-xxx）。
		*/
		function injectScopeIdToHtml(html, id) {
			if (!html || !id) return html;
			const doc = new DOMParser().parseFromString(html, "text/html");
			for (const element of doc.body.querySelectorAll("*")) element.setAttribute(id, "");
			return doc.body.innerHTML;
		}
		watchEffect(() => {
			const nodes = /* @__PURE__ */ toRaw(props.nodes);
			const htmlContent = typeof nodes === "string" ? nodes : renderRichTextNodes(Array.isArray(nodes) ? nodes : [], props.space);
			sanitizedHtml.value = injectScopeIdToHtml(sanitizeRichText(htmlContent), scopeId);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
				class: { "dd-rich-text": __props.userSelect },
				innerHTML: unref(sanitizedHtml)
			}), null, 16, _hoisted_1$7);
		};
	}
};
var rich_text_exports = /* @__PURE__ */ __exportAll({ default: () => rich_text_default });
var rich_text_default = withInstall(_sfc_main$11);
var _sfc_main$10 = {
	__name: "RootPortal",
	props: { enable: {
		type: Boolean,
		default: true
	} },
	setup(__props) {
		return (_ctx, _cache) => {
			return __props.enable ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createBaseVNode("span", mergeProps(_ctx.$attrs, { class: "dd-root-portal-host" }), null, 16), (openBlock(), createBlock(Teleport, { to: "html" }, [renderSlot(_ctx.$slots, "default")]))], 64)) : (openBlock(), createElementBlock("span", mergeProps({ key: 1 }, _ctx.$attrs, { class: "dd-root-portal-content" }), [renderSlot(_ctx.$slots, "default")], 16));
		};
	}
};
var root_portal_exports = /* @__PURE__ */ __exportAll({ default: () => root_portal_default });
var root_portal_default = withInstall(_sfc_main$10);
var _sfc_main$9 = {
	__name: "ScrollView",
	props: {
		/**
		* 允许横向滚动
		*/
		scrollX: {
			type: Boolean,
			default: false
		},
		/**
		* 允许纵向滚动
		*/
		scrollY: {
			type: Boolean,
			default: false
		},
		/**
		* 距顶部/左边多远时，触发 scrolltoupper 事件
		*/
		upperThreshold: {
			type: [Number, String],
			default: 50
		},
		/**
		* 距底部/右边多远时，触发 scrolltolower 事件
		*/
		lowerThreshold: {
			type: [Number, String],
			default: 50
		},
		/**
		* 设置竖向滚动条位置
		*/
		scrollTop: { type: [Number, String] },
		/**
		* 设置横向滚动条位置
		*/
		scrollLeft: { type: [Number, String] },
		/**
		* 值应为某子元素id（id不能以数字开头）。设置哪个方向可滚动，则在哪个方向滚动到该元素
		*/
		scrollIntoView: { type: String },
		/**
		* 在设置滚动条位置时使用动画过渡
		*/
		scrollWithAnimation: {
			type: Boolean,
			default: false
		},
		/**
		* iOS点击顶部状态栏、安卓双击标题栏时，滚动条返回顶部，只支持竖向。自 2.27.3 版本开始，若非显式设置为 false，则在显示尺寸大于屏幕 90% 时自动开启。
		*/
		enableBackToTop: {
			type: Boolean,
			default: false
		},
		/**
		* TODO: 开启 passive 特性，能优化一定的滚动性能
		*/
		enablePassive: {
			type: Boolean,
			default: false
		},
		/**
		* 开启自定义下拉刷新
		*/
		refresherEnabled: {
			type: Boolean,
			default: false
		},
		/**
		* 设置自定义下拉刷新阈值
		*/
		refresherThreshold: {
			type: Number,
			default: 45
		},
		/**
		* 设置自定义下拉刷新默认样式，支持设置 black | white | none， none 表示不使用默认样式
		*/
		refresherDefaultStyle: {
			type: String,
			default: "black",
			validator: (value) => {
				return [
					"black",
					"white",
					"none"
				].includes(value);
			}
		},
		/**
		* 设置自定义下拉刷新区域背景颜色，默认为透明
		*/
		refresherBackground: { type: String },
		/**
		* 设置当前下拉刷新状态，true 表示下拉刷新已经被触发，false 表示下拉刷新未被触发
		*/
		refresherTriggered: {
			type: Boolean,
			default: false
		},
		/**
		* iOS 下 scroll-view 边界弹性控制 (同时开启 enhanced 属性后生效)
		*/
		bounces: {
			type: Boolean,
			default: true
		},
		/**
		* 滚动条显隐控制 (同时开启 enhanced 属性后生效)
		*/
		showScrollbar: {
			type: Boolean,
			default: true
		},
		/**
		* 滑动减速速率控制, 仅在 iOS 下生效 (同时开启 enhanced 属性后生效)
		*/
		fastDeceleration: {
			type: Boolean,
			default: false
		},
		/**
		* 启用 flexbox 布局。开启后，当前节点声明了 display: flex 就会成为 flex container，并作用于其孩子节点
		*/
		enableFlex: {
			type: Boolean,
			default: false
		},
		/**
		* 开启 scroll anchoring 特性，即控制滚动位置不随内容变化而抖动，仅在 iOS 下生效，安卓下可参考 CSS overflow-anchor 属性
		*/
		scrollAnchoring: {
			type: Boolean,
			default: false
		},
		/**
		* 启用 scroll-view 增强特性，启用后可通过 ScrollViewContext 操作 scroll-view
		*/
		enhanced: {
			type: Boolean,
			default: false
		},
		/**
		* 分页滑动效果 (同时开启 enhanced 属性后生效)
		*/
		pagingEnabled: {
			type: Boolean,
			default: false
		},
		/**
		* 使 scroll-view 下的 position sticky 特性生效，否则滚动一屏后 sticky 元素会被隐藏
		*/
		usingSticky: {
			type: Boolean,
			default: false
		},
		/** 是否允许滚动（enhanced 模式能力，Web 同样遵循） */
		scrollEnabled: {
			type: Boolean,
			default: true
		},
		/** 是否将 scroll 事件节流到约一帧一次 */
		throttle: {
			type: Boolean,
			default: true
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		const scrollView = /* @__PURE__ */ ref(null);
		const hideScrollBar = computed(() => {
			if (props.enhanced) return !props.showScrollbar;
			return true;
		});
		let lastScrollLeft = 0;
		let lastScrollTop = 0;
		let lastScrollToUpperTime = 0;
		let lastScrollToLowerTime = 0;
		let lastScrollEventTime = 0;
		function handleScroll(event) {
			if (props.throttle && event.timeStamp - lastScrollEventTime < 20) return;
			lastScrollEventTime = event.timeStamp;
			const { scrollTop, scrollLeft, scrollHeight, scrollWidth, clientHeight, clientWidth } = scrollView.value;
			const deltaX = lastScrollLeft - scrollLeft;
			const deltaY = lastScrollTop - scrollTop;
			lastScrollLeft = scrollLeft;
			lastScrollTop = scrollTop;
			triggerEvent("scroll", {
				event,
				info,
				detail: {
					scrollLeft,
					scrollTop,
					scrollHeight,
					scrollWidth,
					deltaX,
					deltaY
				}
			});
			if (props.scrollY) {
				if (scrollTop <= props.upperThreshold && deltaY > 0 && event.timeStamp - lastScrollToUpperTime > 200) {
					lastScrollToUpperTime = event.timeStamp;
					triggerEvent("scrolltoupper", {
						event,
						info,
						detail: { direction: "top" }
					});
				}
				if (scrollTop + clientHeight >= scrollHeight - props.lowerThreshold && deltaY < 0 && event.timeStamp - lastScrollToLowerTime > 200) {
					lastScrollToLowerTime = event.timeStamp;
					triggerEvent("scrolltolower", {
						event,
						info,
						detail: { direction: "bottom" }
					});
				}
			}
			if (props.scrollX) {
				if (scrollLeft <= props.upperThreshold && deltaX > 0 && event.timeStamp - lastScrollToUpperTime > 200) {
					lastScrollToUpperTime = event.timeStamp;
					triggerEvent("scrolltoupper", {
						event,
						info,
						detail: { direction: "left" }
					});
				}
				if (scrollLeft + clientWidth >= scrollWidth - props.lowerThreshold && deltaX < 0 && event.timeStamp - lastScrollToLowerTime > 200) {
					lastScrollToLowerTime = event.timeStamp;
					triggerEvent("scrolltolower", {
						event,
						info,
						detail: { direction: "right" }
					});
				}
			}
		}
		function handleTouchMove(event) {
			if (props.scrollEnabled && (props.scrollX || props.scrollY)) triggerEvent("touchmove", {
				event,
				info
			});
			else event.preventDefault();
		}
		let refresherStartY;
		let refresherDistance = 0;
		let refreshing = false;
		function handleTouchStart(event) {
			if (!props.scrollEnabled) return;
			if (props.refresherEnabled && scrollView.value?.scrollTop <= 0) {
				refresherStartY = event.touches?.[0]?.clientY;
				refresherDistance = 0;
			}
			if (props.enhanced) triggerEvent("dragstart", {
				event,
				info,
				detail: getScrollDetail()
			});
		}
		function getScrollDetail(extra = {}) {
			const element = scrollView.value;
			return {
				scrollLeft: element?.scrollLeft || 0,
				scrollTop: element?.scrollTop || 0,
				...extra
			};
		}
		function handleEnhancedTouchMove(event) {
			if (refresherStartY !== void 0) {
				refresherDistance = Math.max((event.touches?.[0]?.clientY || refresherStartY) - refresherStartY, 0);
				if (refresherDistance > 0) triggerEvent("refresherpulling", {
					event,
					info,
					detail: { dy: refresherDistance }
				});
			}
			if (props.enhanced) triggerEvent("dragging", {
				event,
				info,
				detail: getScrollDetail()
			});
		}
		function handleTouchEnd(event) {
			if (refresherStartY !== void 0) {
				if (refresherDistance >= props.refresherThreshold) {
					refreshing = true;
					triggerEvent("refresherrefresh", {
						event,
						info,
						detail: { dy: refresherDistance }
					});
				} else if (refresherDistance > 0) triggerEvent("refresherabort", {
					event,
					info,
					detail: { dy: refresherDistance }
				});
				refresherStartY = void 0;
				refresherDistance = 0;
			}
			if (props.enhanced) triggerEvent("dragend", {
				event,
				info,
				detail: getScrollDetail()
			});
		}
		watch(() => props.refresherTriggered, (triggered, previous) => {
			if (triggered && !previous && !refreshing) {
				refreshing = true;
				triggerEvent("refresherrefresh", {
					info,
					detail: { dy: props.refresherThreshold }
				});
			} else if (!triggered && previous && refreshing) {
				refreshing = false;
				triggerEvent("refresherrestore", {
					info,
					detail: { dy: 0 }
				});
			}
		});
		watch(() => [props.scrollTop, props.scrollLeft], ([newScrollTop, newScrollLeft]) => {
			if (scrollView.value) scrollView.value.scrollTo({
				top: newScrollTop === void 0 ? scrollView.value.scrollTop : Number(newScrollTop) || 0,
				left: newScrollLeft === void 0 ? scrollView.value.scrollLeft : Number(newScrollLeft) || 0,
				behavior: props.scrollWithAnimation ? "smooth" : "auto"
			});
		}, { flush: "post" });
		function scrollToChild(id) {
			if (!id || !scrollView.value) return;
			const escapedId = window.CSS?.escape ? CSS.escape(id) : id.replace(/(["'\\#.:[\],>+~*^$|=()])/g, "\\$1");
			const target = scrollView.value.querySelector(`#${escapedId}`);
			if (!target) return;
			const rootRect = scrollView.value.getBoundingClientRect();
			const targetRect = target.getBoundingClientRect();
			scrollView.value.scrollTo({
				top: props.scrollY ? scrollView.value.scrollTop + targetRect.top - rootRect.top : scrollView.value.scrollTop,
				left: props.scrollX ? scrollView.value.scrollLeft + targetRect.left - rootRect.left : scrollView.value.scrollLeft,
				behavior: props.scrollWithAnimation ? "smooth" : "auto"
			});
		}
		watch(() => props.scrollIntoView, scrollToChild, { flush: "post" });
		onMounted(() => {
			if (scrollView.value) {
				if (props.scrollTop !== void 0) scrollView.value.scrollTop = Number(props.scrollTop) || 0;
				if (props.scrollLeft !== void 0) scrollView.value.scrollLeft = Number(props.scrollLeft) || 0;
				if (props.scrollIntoView) scrollToChild(props.scrollIntoView);
			}
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				ref_key: "scrollView",
				ref: scrollView
			}, _ctx.$attrs, {
				class: ["dd-scroll-view", [{
					"scroll-x": Boolean(props.scrollX),
					"scroll-y": Boolean(props.scrollY),
					"scroll-disabled": !props.scrollEnabled,
					"hide-scrollbar": unref(hideScrollBar)
				}]],
				onScroll: handleScroll,
				onTouchstart: handleTouchStart,
				onTouchmove: _cache[0] || (_cache[0] = ($event) => {
					handleTouchMove($event);
					handleEnhancedTouchMove($event);
				}),
				onTouchend: handleTouchEnd,
				onTouchcancel: handleTouchEnd
			}), [renderSlot(_ctx.$slots, "default")], 16);
		};
	}
};
var scroll_view_exports = /* @__PURE__ */ __exportAll({ default: () => scroll_view_default });
var scroll_view_default = withInstall(_sfc_main$9);
var _hoisted_1$6 = [
	"id",
	"aria-valuemin",
	"aria-valuemax",
	"aria-valuenow",
	"aria-disabled"
];
var _hoisted_2$4 = { class: "dd-slider-wrapper" };
var _hoisted_3$1 = ["hidden"];
var _hoisted_4$1 = {
	"parse-text-content": "",
	style: { "width": "3ch" }
};
var _sfc_main$8 = {
	__name: "Slider",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* name，为表单使用
		*/
		name: { type: String },
		/**
		* 最小值
		*/
		min: {
			type: Number,
			default: 0,
			required: false
		},
		/**
		* 最大值
		*/
		max: {
			type: Number,
			default: 100,
			required: false
		},
		/**
		* 步长，取值必须大于 0，并且可被(max - min)整除
		*/
		step: {
			type: Number,
			default: 1,
			required: false
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 当前取值
		*/
		value: {
			type: Number,
			default: 0,
			required: false
		},
		/**
		* 背景条的颜色（请使用 backgroundColor）
		*/
		color: {
			type: String,
			default: "#e9e9e9",
			required: false
		},
		/**
		* 已选择的颜色（请使用 activeColor）
		*/
		selectedColor: {
			type: String,
			default: "#1aad19",
			required: false
		},
		/**
		* 进度条激活态颜色
		*/
		activeColor: {
			type: String,
			default: "#1aad19",
			required: false
		},
		/**
		* 进度条非激活态颜色
		*/
		backgroundColor: {
			type: String,
			default: "#e9e9e9",
			required: false
		},
		/**
		* 滑块的大小，取值范围为 12 - 28
		*/
		blockSize: {
			type: Number,
			default: 28,
			required: false,
			validator: (value) => value >= 12 && value <= 28
		},
		/**
		* 滑块的颜色
		*/
		blockColor: {
			type: String,
			default: "#ffffff",
			required: false
		},
		/**
		* 是否显示当前 value
		*/
		showValue: {
			type: Boolean,
			default: false,
			required: false
		},
		autoFill: {
			type: String,
			default: ""
		}
	},
	setup(__props) {
		const props = __props;
		const valColor = computed(() => {
			const attrs = info.attrs || {};
			if ("activeColor" in attrs || "active-color" in attrs) return props.activeColor;
			if ("selectedColor" in attrs || "selected-color" in attrs) return props.selectedColor;
			return props.activeColor;
		});
		const backColor = computed(() => {
			return { backgroundColor: props.backgroundColor || props.color };
		});
		function roundToStep(value) {
			const min = Number(props.min);
			const max = Number(props.max);
			const step = Math.max(Number(props.step) || 1, Number.EPSILON);
			return Math.min(Math.max(min + Math.round((Math.min(Math.max(value, min), max) - min) / step) * step, min), max);
		}
		const sliderHandle = /* @__PURE__ */ ref(null);
		const disValue = /* @__PURE__ */ ref(roundToStep(Number(props.value)));
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		collectFormValue?.(props.name, disValue.value);
		const range = computed(() => Number(props.max) - Number(props.min));
		const percent = computed(() => {
			return range.value > 0 ? (disValue.value - Number(props.min)) / range.value * 100 : 0;
		});
		let isDragging = false;
		function startDrag() {
			if (props.disabled) return;
			isDragging = true;
		}
		const info = useInfo();
		watch(() => props.value, (value) => {
			disValue.value = roundToStep(Number(value));
			collectFormValue?.(props.name, disValue.value);
		});
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue: () => disValue.value,
			reset: () => {
				disValue.value = Number(props.min);
				collectFormValue?.(props.name, disValue.value);
			}
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		const blockStyle = computed(() => ({
			backgroundColor: props.blockColor,
			height: `${props.blockSize}px`,
			marginLeft: `${-props.blockSize / 2}px`,
			marginTop: `${-props.blockSize / 2}px`,
			width: `${props.blockSize}px`
		}));
		function drag(event) {
			if (!isDragging || Boolean(props.disabled)) return;
			if (event.cancelable) event.preventDefault();
			updateValue(event);
		}
		function updateValue(event, eventType = "changing") {
			const clientX = event.touches ? event.touches[0].clientX : event.clientX;
			const rect = sliderHandle.value?.getBoundingClientRect();
			if (!rect?.width) return;
			const disV = roundToStep((clientX - rect.left) / rect.width * range.value + Number(props.min));
			disValue.value = disV;
			collectFormValue?.(props.name, disV);
			triggerEvent(eventType, {
				event,
				info,
				detail: { value: disV }
			});
		}
		function endDrag(event) {
			if (!isDragging || Boolean(props.disabled)) return;
			isDragging = false;
			triggerEvent("change", {
				event,
				info,
				detail: { value: disValue.value }
			});
		}
		function handleClick(event) {
			if (isDragging) {
				isDragging = false;
				return;
			}
			if (props.disabled) return;
			updateValue(event, "change");
		}
		onMounted(() => {
			window.addEventListener("mousemove", drag);
			window.addEventListener("mouseup", endDrag);
			window.addEventListener("touchmove", drag, { passive: false });
			window.addEventListener("touchend", endDrag);
			window.addEventListener("touchcancel", endDrag);
		});
		onBeforeUnmount(() => {
			window.removeEventListener("mousemove", drag);
			window.removeEventListener("mouseup", endDrag);
			window.removeEventListener("touchmove", drag);
			window.removeEventListener("touchend", endDrag);
			window.removeEventListener("touchcancel", endDrag);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, {
				class: ["dd-slider", { "dd-slider-disabled": __props.disabled }],
				role: "slider",
				"aria-valuemin": __props.min,
				"aria-valuemax": __props.max,
				"aria-valuenow": unref(disValue),
				"aria-disabled": __props.disabled
			}), [createBaseVNode("div", _hoisted_2$4, [createBaseVNode("div", {
				ref_key: "sliderHandle",
				ref: sliderHandle,
				class: "dd-slider-tap-area",
				onClick: handleClick
			}, [createBaseVNode("div", {
				class: "dd-slider-handle-wrapper",
				style: normalizeStyle(unref(backColor))
			}, [
				createBaseVNode("div", {
					class: "dd-slider-handle",
					style: normalizeStyle({
						...unref(blockStyle),
						left: `${unref(percent)}%`,
						backgroundColor: "transparent"
					}),
					onTouchstart: startDrag,
					onMousedown: startDrag
				}, null, 36),
				createBaseVNode("div", {
					class: "dd-slider-thumb",
					style: normalizeStyle({
						...unref(blockStyle),
						left: `${unref(percent)}%`
					})
				}, null, 4),
				createBaseVNode("div", {
					class: "dd-slider-track",
					style: normalizeStyle({
						width: `${unref(percent)}%`,
						backgroundColor: unref(valColor)
					})
				}, null, 4),
				_cache[0] || (_cache[0] = createBaseVNode("div", { class: "dd-slider-step" }, null, -1))
			], 4)], 512), createBaseVNode("span", {
				class: "dd-slider-value",
				hidden: !__props.showValue
			}, [createBaseVNode("p", _hoisted_4$1, toDisplayString(unref(disValue)), 1)], 8, _hoisted_3$1)])], 16, _hoisted_1$6);
		};
	}
};
var slider_exports = /* @__PURE__ */ __exportAll({ default: () => slider_default });
var slider_default = withInstall(_sfc_main$8);
var _hoisted_1$5 = ["aria-label"];
var _hoisted_2$3 = ["data-dot-index"];
var _sfc_main$7 = {
	__name: "Swiper",
	props: {
		/**
		* 是否显示面板指示点
		*/
		indicatorDots: {
			type: Boolean,
			default: false
		},
		/**
		* 指示点颜色
		*/
		indicatorColor: {
			type: String,
			default: "rgba(0, 0, 0, .3)"
		},
		/**
		* 当前选中的指示点颜色
		*/
		indicatorActiveColor: {
			type: String,
			default: "#000000"
		},
		/**
		* 是否自动切换
		*/
		autoplay: {
			type: Boolean,
			default: false
		},
		/**
		* 当前所在滑块的 index
		*/
		current: {
			type: Number,
			default: 0
		},
		/** 当前所在滑块的 item-id，优先于 current */
		currentItemId: {
			type: String,
			default: ""
		},
		/** 跳过不可见滑块的内容布局 */
		skipHiddenItemLayout: {
			type: Boolean,
			default: false
		},
		/**
		* 自动切换时间间隔
		*/
		interval: {
			type: Number,
			default: 5e3
		},
		/**
		* 滑动动画时长
		*/
		duration: {
			type: Number,
			default: 500
		},
		/**
		* 是否衔接滑动(循环滚动)
		*/
		circular: {
			type: Boolean,
			default: false
		},
		/**
		* 滑动方向是否为纵向
		*/
		vertical: {
			type: Boolean,
			default: false
		},
		/**
		* 同时显示的滑块数量
		*/
		displayMultipleItems: {
			type: Number,
			default: 1
		},
		/**
		* 前边距，可用于露出前一项的一小部分，接受 px 和 rpx 值
		*/
		previousMargin: {
			type: String,
			default: "0px"
		},
		/**
		* 指定 swiper 切换缓动动画类型
		* default	默认缓动函数
		* linear	线性动画
		* easeInCubic	缓入动画
		* easeOutCubic	缓出动画
		* easeInOutCubic	缓入缓出动画
		*/
		easingFunction: {
			type: String,
			default: "default",
			validator: (value) => {
				return [
					"default",
					"linear",
					"easeInCubic",
					"easeOutCubic",
					"easeInOutCubic"
				].includes(value);
			}
		},
		/**
		* 后边距，可用于露出后一项的一小部分，接受 px 和 rpx 值
		*/
		nextMargin: {
			type: String,
			default: "0px"
		},
		/**
		* 当 swiper-item 的个数大于等于 2，关闭 circular 并且开启 previous-margin 或 next-margin 的时候，可以指定这个边距是否应用到第一个、最后一个元素
		*/
		snapToEdge: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const props = __props;
		const info = useInfo();
		const slots = useSlots();
		const slotCount = /* @__PURE__ */ ref(0);
		const slotItems = /* @__PURE__ */ ref([]);
		const leadingClonedItems = /* @__PURE__ */ ref([]);
		const trailingClonedItems = /* @__PURE__ */ ref([]);
		const currentIndex = /* @__PURE__ */ ref(props.current);
		let isInternalChange = false;
		function findSwiperItems(nodes) {
			const res = [];
			const stack = Array.isArray(nodes) ? [...nodes].reverse() : [];
			const visited = /* @__PURE__ */ new WeakSet();
			while (stack.length) {
				const vnode = stack.pop();
				if (!vnode || typeof vnode !== "object" || visited.has(vnode)) continue;
				visited.add(vnode);
				if (vnode.type?.__name === "SwiperItem") {
					res.push(vnode);
					continue;
				}
				let children = vnode.children;
				if (children?.default && typeof children.default === "function") children = children.default();
				if (Array.isArray(children)) for (let i = children.length - 1; i >= 0; i--) stack.push(children[i]);
			}
			return res;
		}
		function cloneSwiperItems(items, position) {
			return items.map((item, idx) => cloneVNode(item, {
				key: `${position}-${idx}-${item.key ?? idx}`,
				"data-dd-cloned": ""
			}));
		}
		const swiperSliders = /* @__PURE__ */ ref(null);
		const swiperFrame = /* @__PURE__ */ ref(null);
		let startX = 0;
		let startY = 0;
		let isDragging = false;
		let isPointerDown = false;
		let directionChecked = false;
		let containerRect = {
			width: 0,
			height: 0
		};
		let moveX = 0;
		let moveY = 0;
		let startTime = 0;
		let lastPositionX = 0;
		let lastPositionY = 0;
		let rafId;
		let intervalId;
		let source = "";
		const wrapperStyle = /* @__PURE__ */ ref({
			transform: props.vertical ? `translateY(-${props.current}00%)` : `translateX(-${props.current}00%)`,
			transition: `transform ${props.duration}ms ease`,
			flexDirection: props.vertical ? "column" : "row"
		});
		const wrapperEventStyle = computed(() => {
			return { touchAction: props.vertical ? "pan-x" : "pan-y" };
		});
		const easingParsed = computed(() => {
			switch (props.easingFunction) {
				case "linear": return "linear";
				case "easeInCubic": return "ease-in";
				case "easeOutCubic": return "ease-out";
				case "easeInOutCubic": return "ease-in-out";
				default: return "ease-in";
			}
		});
		const normalizedDisplayMultipleItems = computed(() => {
			return Math.max(1, Number(props.displayMultipleItems) || 1);
		});
		const circularEnabled = computed(() => {
			return props.circular && slotCount.value > normalizedDisplayMultipleItems.value;
		});
		const maxCurrent = computed(() => {
			return Math.max(slotCount.value - normalizedDisplayMultipleItems.value, 0);
		});
		const hasClonedItems = computed(() => {
			return leadingClonedItems.value.length > 0 || trailingClonedItems.value.length > 0;
		});
		function normalizeCurrent(current) {
			const total = slotCount.value;
			if (!total) return 0;
			const roundedCurrent = Math.round(Number(current) || 0);
			if (circularEnabled.value) return (roundedCurrent % total + total) % total;
			return Math.min(Math.max(roundedCurrent, 0), maxCurrent.value);
		}
		function getVisibleCurrent(current = currentIndex.value) {
			return normalizeCurrent(current);
		}
		function getItemId(current = currentIndex.value) {
			const item = slotItems.value[getVisibleCurrent(current)];
			return item?.props?.itemId ?? item?.props?.["item-id"] ?? "";
		}
		function getIndexByItemId(itemId) {
			return slotItems.value.findIndex((item) => (item?.props?.itemId ?? item?.props?.["item-id"] ?? "") === itemId);
		}
		function isActiveDot(index) {
			const current = getVisibleCurrent();
			const displayCount = normalizedDisplayMultipleItems.value;
			return current <= index && index < current + displayCount || index < current + displayCount - slotCount.value;
		}
		function getDotStyle(index) {
			return { backgroundColor: isActiveDot(index) ? props.indicatorActiveColor : props.indicatorColor };
		}
		watchEffect(() => {
			if (slots.default) {
				const res = findSwiperItems(slots.default());
				slotCount.value = res.length;
				slotItems.value = res;
				if (circularEnabled.value) {
					leadingClonedItems.value = cloneSwiperItems(res.slice(-normalizedDisplayMultipleItems.value), "leading");
					trailingClonedItems.value = cloneSwiperItems(res.slice(0, normalizedDisplayMultipleItems.value), "trailing");
				} else {
					leadingClonedItems.value = [];
					trailingClonedItems.value = [];
				}
			} else {
				slotCount.value = 0;
				slotItems.value = [];
				leadingClonedItems.value = [];
				trailingClonedItems.value = [];
			}
			if (props.autoplay) startAutoplay();
			else stopAutoplay();
		});
		function getVelocity(distance, time) {
			const velocity = distance / Math.max(time, 16);
			return Math.sign(velocity) * Math.abs(velocity) ** 1.05;
		}
		function checkDirection(deltaX, deltaY, event) {
			if (directionChecked) {
				if (isDragging && event.cancelable) event.preventDefault();
				return;
			}
			const absDeltaX = Math.abs(deltaX);
			const absDeltaY = Math.abs(deltaY);
			if (absDeltaX < 2 && absDeltaY < 2) return;
			if (props.vertical) {
				isDragging = absDeltaX < absDeltaY;
				if (isDragging && event.cancelable) event.preventDefault();
			} else {
				isDragging = absDeltaX > absDeltaY;
				if (isDragging && absDeltaX > absDeltaY && event.cancelable) event.preventDefault();
			}
			directionChecked = true;
		}
		function requestMargin() {
			if (!swiperSliders.value || !swiperFrame.value) return;
			const previousMargin = props.previousMargin ? transformRpx(props.previousMargin) : "";
			const nextMargin = props.nextMargin ? transformRpx(props.nextMargin) : "";
			const itemSize = `${Math.abs(100 / normalizedDisplayMultipleItems.value)}%`;
			if (props.vertical) {
				swiperSliders.value.style.left = 0;
				swiperSliders.value.style.right = 0;
				swiperSliders.value.style.top = previousMargin;
				swiperSliders.value.style.bottom = nextMargin;
				swiperFrame.value.style.width = "100%";
				swiperFrame.value.style.height = itemSize;
			} else {
				swiperSliders.value.style.left = previousMargin;
				swiperSliders.value.style.right = nextMargin;
				swiperSliders.value.style.top = 0;
				swiperSliders.value.style.bottom = 0;
				swiperFrame.value.style.height = "100%";
				swiperFrame.value.style.width = itemSize;
			}
		}
		function calcSnapPosition(position) {
			if (!props.snapToEdge || circularEnabled.value || slotCount.value < 2 || !swiperSliders.value || !swiperFrame.value) return position;
			const axisOffset = props.vertical ? "offsetTop" : "offsetLeft";
			const axisSize = props.vertical ? "offsetHeight" : "offsetWidth";
			const frameSize = swiperFrame.value[axisSize] || 1;
			if (position === 0 && props.previousMargin) return swiperSliders.value[axisOffset] / frameSize;
			if (position === maxCurrent.value && props.nextMargin) {
				const trailingMargin = swiperSliders.value.parentElement[axisSize] - swiperSliders.value[axisOffset] - swiperSliders.value[axisSize];
				return maxCurrent.value - trailingMargin / frameSize;
			}
			return position;
		}
		function getTranslatePosition(position, skipSnap = false) {
			const normalizedPosition = hasClonedItems.value ? position + leadingClonedItems.value.length : position;
			return skipSnap ? normalizedPosition : calcSnapPosition(normalizedPosition);
		}
		function applyTransform(position, skipSnap = false) {
			const translateValue = getTranslatePosition(position, skipSnap);
			wrapperStyle.value.transform = `translate${props.vertical ? "Y" : "X"}(-${translateValue * 100}%)`;
		}
		function setNewCurrent(newCurrent) {
			if (!circularEnabled.value || newCurrent !== -1 && newCurrent !== slotCount.value) newCurrent = normalizeCurrent(newCurrent);
			if (newCurrent === currentIndex.value) return;
			currentIndex.value = newCurrent;
			updateTransform();
			triggerEvent("change", {
				info,
				detail: {
					current: getVisibleCurrent(newCurrent),
					currentItemId: getItemId(newCurrent),
					source
				}
			});
		}
		watch([
			() => props.vertical,
			() => props.autoplay,
			() => props.current,
			() => props.currentItemId,
			() => props.previousMargin,
			() => props.nextMargin,
			() => props.circular,
			() => props.displayMultipleItems,
			() => props.snapToEdge,
			() => props.interval
		], ([newVertical, newAutoplay, newCurrent, newCurrentItemId, newPreviousMargin, newNextMargin, newCircular, newDisplayMultipleItems, newSnapToEdge, newInterval], [oldVertical, oldAutoplay, _oldCurrent, oldCurrentItemId, oldPreviousMargin, oldNextMargin, oldCircular, oldDisplayMultipleItems, oldSnapToEdge, oldInterval]) => {
			if (oldVertical !== newVertical) {
				wrapperStyle.value.flexDirection = newVertical ? "column" : "row";
				requestMargin();
				updateTransform();
				wrapperStyle.value.transition = "none";
			}
			if (oldAutoplay !== newAutoplay || oldInterval !== newInterval) if (newAutoplay) startAutoplay();
			else stopAutoplay();
			if (oldDisplayMultipleItems !== newDisplayMultipleItems) {
				currentIndex.value = normalizeCurrent(currentIndex.value);
				requestMargin();
				updateTransform();
				wrapperStyle.value.transition = "none";
			}
			const itemIdIndex = newCurrentItemId ? getIndexByItemId(newCurrentItemId) : -1;
			if (newCurrentItemId !== oldCurrentItemId && itemIdIndex >= 0 && !isInternalChange) {
				source = "";
				setNewCurrent(itemIdIndex);
			} else if (newCurrent !== currentIndex.value && !isInternalChange && !newCurrentItemId) {
				source = "";
				setNewCurrent(newCurrent);
			}
			if (oldPreviousMargin !== newPreviousMargin || newNextMargin !== oldNextMargin || oldSnapToEdge !== newSnapToEdge) {
				requestMargin();
				updateTransform();
				wrapperStyle.value.transition = "none";
			}
			if (oldCircular !== newCircular) {
				currentIndex.value = normalizeCurrent(currentIndex.value);
				updateTransform();
				wrapperStyle.value.transition = "none";
			}
		});
		watch(slotCount, () => {
			const itemIdIndex = props.currentItemId ? getIndexByItemId(props.currentItemId) : -1;
			if (itemIdIndex >= 0) currentIndex.value = itemIdIndex;
			if (currentIndex.value !== -1 && currentIndex.value !== slotCount.value) currentIndex.value = normalizeCurrent(currentIndex.value);
			if (swiperFrame.value) {
				applyTransform(currentIndex.value);
				wrapperStyle.value.transition = "none";
			}
		});
		function startDrag(event) {
			if (!event.touches && event.button !== 0) return;
			isPointerDown = true;
			stopAutoplay();
			if (rafId) {
				cancelAnimationFrame(rafId);
				rafId = void 0;
			}
			if (wrapperStyle.value.transition && wrapperStyle.value.transition !== "none") handleTransitionEnd({ type: "transitionend" });
			wrapperStyle.value.transition = "none";
			startTime = Date.now();
			isDragging = false;
			directionChecked = false;
			startX = event.touches ? event.touches[0].clientX : event.clientX;
			startY = event.touches ? event.touches[0].clientY : event.clientY;
			moveX = 0;
			moveY = 0;
			containerRect = {
				width: swiperFrame.value.offsetWidth,
				height: swiperFrame.value.offsetHeight
			};
			const rect = swiperFrame.value.getBoundingClientRect();
			lastPositionX = rect.x;
			lastPositionY = rect.y;
		}
		function drag(event) {
			if (!isPointerDown) return;
			moveX = (event.touches ? event.touches[0].clientX : event.clientX) - startX;
			moveY = (event.touches ? event.touches[0].clientY : event.clientY) - startY;
			checkDirection(moveX, moveY, event);
			if (!isDragging) return;
			if (rafId) cancelAnimationFrame(rafId);
			rafId = requestAnimationFrame(() => {
				let move = props.vertical ? moveY : moveX;
				const containerSize = props.vertical ? containerRect.height : containerRect.width;
				const moveRatio = move / containerSize;
				move = move * 1.1;
				if (!circularEnabled.value) {
					const isAtStart = currentIndex.value === 0;
					const isAtEnd = currentIndex.value === maxCurrent.value;
					if (isAtStart && move > 0 || isAtEnd && move < 0) {
						const dampingCurve = .6 - .3 / (Math.abs(moveRatio) + .8);
						move = move * dampingCurve;
					}
				}
				if (props.vertical) {
					const translateY = -getTranslatePosition(currentIndex.value) * 100 + move / containerRect.height * 100;
					wrapperStyle.value.transform = `translateY(${translateY}%)`;
				} else {
					const translateX = -getTranslatePosition(currentIndex.value) * 100 + move / containerRect.width * 100;
					wrapperStyle.value.transform = `translateX(${translateX}%)`;
				}
			});
		}
		function endDrag() {
			if (!isPointerDown) return;
			isPointerDown = false;
			directionChecked = false;
			if (!isDragging) {
				applyTransform(currentIndex.value);
				startAutoplay();
				return;
			}
			const elapsedTime = Date.now() - startTime;
			if (rafId) {
				cancelAnimationFrame(rafId);
				rafId = void 0;
			}
			const move = props.vertical ? moveY : moveX;
			if (move === 0) {
				isDragging = false;
				startAutoplay();
				return;
			}
			const velocity = getVelocity(move, elapsedTime);
			const VELOCITY_THRESHOLD = .15;
			const DISTANCE_THRESHOLD = .15;
			const containerSize = props.vertical ? containerRect.height : containerRect.width;
			const moveRatio = Math.abs(move) / containerSize;
			const fallback = () => {
				const isAtEdge = hasClonedItems.value ? currentIndex.value === -1 || currentIndex.value === slotCount.value : currentIndex.value === 0 || currentIndex.value === maxCurrent.value;
				const velocityFactor = Math.min(Math.max(Math.abs(velocity) * 2.5, .6), 2);
				const distanceFactor = Math.min(Math.max(moveRatio * 1.8, .5), 1.5);
				const combinedFactor = velocityFactor * .7 + distanceFactor * .3;
				const adjustedDuration = Math.max(Math.min(Math.round(props.duration / combinedFactor), props.duration), 150);
				let dynamicEasing;
				if (Math.abs(velocity) > .5 || moveRatio > .3) dynamicEasing = "cubic-bezier(0.175, 0.885, 0.32, 1.275)";
				else if (isAtEdge) dynamicEasing = "cubic-bezier(0.34, 1.56, 0.64, 1)";
				else dynamicEasing = easingParsed.value;
				wrapperStyle.value.transition = `transform ${adjustedDuration}ms ${dynamicEasing}`;
				applyTransform(currentIndex.value);
			};
			if (slotCount.value > normalizedDisplayMultipleItems.value) if (Math.abs(velocity) > VELOCITY_THRESHOLD || moveRatio > DISTANCE_THRESHOLD) {
				const speedFactor = Math.min(Math.max(Math.abs(velocity) * 3.5, .8), 4);
				const distanceFactor = Math.min(Math.max(moveRatio * 1.8, .6), 1.8);
				const combinedFactor = speedFactor * .8 + distanceFactor * .2;
				const newDuration = Math.max(Math.min(Math.round(props.duration / combinedFactor), props.duration), 100);
				let dynamicEasing;
				if (Math.abs(velocity) > .8) dynamicEasing = "cubic-bezier(0.25, 0.1, 0.25, 1.0)";
				else dynamicEasing = easingParsed.value;
				wrapperStyle.value.transition = `transform ${newDuration}ms ${dynamicEasing}`;
				source = "touch";
				if (move > 0) prevSlide(fallback);
				else nextSlide(fallback);
			} else fallback();
			else fallback();
			isDragging = false;
			startAutoplay();
		}
		function nextSlide(fallback) {
			const newCurrent = circularEnabled.value ? currentIndex.value + 1 : Math.min(currentIndex.value + 1, maxCurrent.value);
			if (newCurrent === currentIndex.value) {
				fallback?.();
				return;
			}
			isInternalChange = true;
			setNewCurrent(newCurrent);
		}
		function prevSlide(fallback) {
			const newCurrent = circularEnabled.value ? currentIndex.value - 1 : Math.max(currentIndex.value - 1, 0);
			if (newCurrent === currentIndex.value) {
				fallback?.();
				return;
			}
			isInternalChange = true;
			setNewCurrent(newCurrent);
		}
		function handleTransitionEnd(event) {
			isInternalChange = false;
			if (circularEnabled.value) {
				if (currentIndex.value === slotCount.value) {
					currentIndex.value = 0;
					applyTransform(0, true);
					wrapperStyle.value.transition = "none";
				} else if (currentIndex.value === -1) {
					currentIndex.value = slotCount.value - 1;
					applyTransform(currentIndex.value, true);
					wrapperStyle.value.transition = "none";
				}
			}
			if (rafId) {
				cancelAnimationFrame(rafId);
				rafId = void 0;
			}
			triggerEvent("animationfinish", {
				event,
				info,
				detail: {
					current: getVisibleCurrent(),
					currentItemId: getItemId(),
					source
				}
			});
		}
		function updateTransform() {
			if (rafId) {
				cancelAnimationFrame(rafId);
				rafId = void 0;
			}
			if (swiperFrame.value) {
				const rect = swiperFrame.value.getBoundingClientRect();
				lastPositionX = rect.x;
				lastPositionY = rect.y;
			}
			applyTransform(currentIndex.value);
			wrapperStyle.value.transition = `transform ${props.duration}ms ${easingParsed.value}`;
			rafId = requestAnimationFrame(monitorAnimation);
		}
		function monitorAnimation() {
			if (rafId) {
				cancelAnimationFrame(rafId);
				rafId = void 0;
			}
			const rect = swiperFrame.value.getBoundingClientRect();
			if (props.vertical) {
				const dy = lastPositionY - rect.y;
				triggerEvent("transition", {
					info,
					detail: {
						dx: 0,
						dy
					}
				});
			} else {
				const dx = lastPositionX - rect.x;
				triggerEvent("transition", {
					info,
					detail: {
						dx,
						dy: 0
					}
				});
			}
		}
		function startAutoplay() {
			stopAutoplay();
			if (props.autoplay && slotCount.value > normalizedDisplayMultipleItems.value) intervalId = setInterval(() => {
				if (isDragging) return;
				source = "autoplay";
				isInternalChange = true;
				if (circularEnabled.value) setNewCurrent(currentIndex.value + 1);
				else setNewCurrent(currentIndex.value < maxCurrent.value ? currentIndex.value + 1 : 0);
			}, props.interval);
		}
		function stopAutoplay() {
			if (intervalId) {
				clearInterval(intervalId);
				intervalId = null;
			}
		}
		onMounted(() => {
			requestMargin();
			const itemIdIndex = props.currentItemId ? getIndexByItemId(props.currentItemId) : -1;
			currentIndex.value = normalizeCurrent(itemIdIndex >= 0 ? itemIdIndex : currentIndex.value);
			applyTransform(currentIndex.value);
			wrapperStyle.value.transition = "none";
			startAutoplay();
		});
		onBeforeUnmount(() => {
			stopAutoplay();
			cancelAnimationFrame(rafId);
			rafId = null;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: ["dd-swiper", { "dd-swiper-skip-hidden": __props.skipHiddenItemLayout }] }), [createBaseVNode("div", {
				class: "dd-swiper-wrapper",
				style: normalizeStyle(unref(wrapperEventStyle)),
				"aria-label": Boolean(props.vertical) ? "可竖向滚动" : "可横向滚动",
				onTouchstart: startDrag,
				onTouchmove: drag,
				onTouchend: endDrag,
				onTouchcancel: endDrag,
				onMousedown: startDrag,
				onMousemove: drag,
				onMouseup: endDrag,
				onMouseleave: endDrag
			}, [createBaseVNode("div", {
				ref_key: "swiperSliders",
				ref: swiperSliders,
				class: "dd-swiper-slides"
			}, [createBaseVNode("div", {
				ref_key: "swiperFrame",
				ref: swiperFrame,
				class: "dd-swiper-slide-frame",
				style: normalizeStyle(unref(wrapperStyle)),
				onTransitionend: handleTransitionEnd
			}, [
				unref(leadingClonedItems).length ? (openBlock(true), createElementBlock(Fragment, { key: 0 }, renderList(unref(leadingClonedItems), (clonedItem, idx) => {
					return openBlock(), createBlock(resolveDynamicComponent(clonedItem), {
						key: `leading-${idx}`,
						"data-dd-cloned": ""
					});
				}), 128)) : createCommentVNode("", true),
				renderSlot(_ctx.$slots, "default"),
				unref(trailingClonedItems).length ? (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(trailingClonedItems), (clonedItem, idx) => {
					return openBlock(), createBlock(resolveDynamicComponent(clonedItem), {
						key: `trailing-${idx}`,
						"data-dd-cloned": ""
					});
				}), 128)) : createCommentVNode("", true)
			], 36)], 512), Boolean(props.indicatorDots) && unref(slotCount) > 0 ? (openBlock(), createElementBlock("div", {
				key: 0,
				class: normalizeClass(["dd-swiper-dots", {
					"dd-swiper-dots-horizontal": !Boolean(props.vertical),
					"dd-swiper-dots-vertical": Boolean(props.vertical)
				}])
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(slotCount), (idx) => {
				return openBlock(), createElementBlock("div", {
					key: idx,
					"data-dot-index": idx - 1,
					class: normalizeClass(["dd-swiper-dot", { "dd-swiper-dot-active": isActiveDot(idx - 1) }]),
					style: normalizeStyle(getDotStyle(idx - 1))
				}, null, 14, _hoisted_2$3);
			}), 128))], 2)) : createCommentVNode("", true)], 44, _hoisted_1$5)], 16);
		};
	}
};
var swiper_exports = /* @__PURE__ */ __exportAll({ default: () => swiper_default });
var swiper_default = withInstall(_sfc_main$7);
var _hoisted_1$4 = ["item-id"];
var _sfc_main$6 = {
	__name: "SwiperItem",
	props: { 
	/**
	* 该 swiper-item 的标识符
	*/
itemId: { type: String } },
	setup(__props) {
		const props = __props;
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
				class: "dd-swiper-item",
				"item-id": props.itemId
			}), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_1$4);
		};
	}
};
var swiper_item_exports = /* @__PURE__ */ __exportAll({ default: () => swiper_item_default });
var swiper_item_default = withInstall(_sfc_main$6);
var _hoisted_1$3 = [
	"id",
	"tabindex",
	"aria-checked",
	"aria-disabled",
	"onKeydown"
];
var _hoisted_2$2 = [
	"id",
	"tabindex",
	"aria-checked",
	"aria-disabled",
	"onKeydown"
];
var _sfc_main$5 = {
	__name: "Switch",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		name: { type: String },
		/**
		* 是否选中
		*/
		checked: {
			type: Boolean,
			default: false
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false
		},
		/**
		* 样式，有效值 switch, checkbox
		*/
		type: {
			type: String,
			default: "switch",
			validator: (value) => {
				return ["switch", "checkbox"].includes(value);
			}
		},
		/**
		* switch 的颜色，同 css 的 color
		*/
		color: {
			type: String,
			default: "#04BE02"
		},
		autoFill: {
			type: String,
			default: ""
		}
	},
	setup(__props) {
		const props = __props;
		const isOn = /* @__PURE__ */ ref(props.checked);
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		watch(() => props.checked, (newVal) => {
			isOn.value = newVal;
			collectFormValue?.(props.name, isOn.value);
		}, { immediate: true });
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue: () => isOn.value,
			reset: () => {
				isOn.value = false;
				collectFormValue?.(props.name, isOn.value);
			}
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		const computedStyle = computed(() => {
			const checkedColor = isOn.value ? props.color ?? "#04BE02" : void 0;
			if (props.type === "checkbox") return { color: checkedColor };
			else return { backgroundColor: checkedColor };
		});
		const info = useInfo();
		function handleClicked(event) {
			if (!props.disabled) {
				isOn.value = !isOn.value;
				collectFormValue?.(props.name, isOn.value);
				triggerEvent("change", {
					event,
					info,
					detail: { value: isOn.value }
				});
			}
		}
		return (_ctx, _cache) => {
			return __props.type === "checkbox" ? (openBlock(), createElementBlock("div", mergeProps({
				key: 0,
				id: __props.id
			}, _ctx.$attrs, {
				class: ["dd-checkbox-input", {
					"dd-checkbox-input-checked": unref(isOn),
					"dd-checkbox-input-disabled": __props.disabled
				}],
				"data-dd-label-target": "",
				role: "checkbox",
				tabindex: __props.disabled ? -1 : 0,
				"aria-checked": unref(isOn),
				"aria-disabled": __props.disabled,
				onClick: handleClicked,
				onKeydown: [withKeys(withModifiers(handleClicked, ["prevent"]), ["enter"]), withKeys(withModifiers(handleClicked, ["prevent"]), ["space"])]
			}), [createBaseVNode("i", {
				class: "dd-checkbox-input-inner",
				style: normalizeStyle(unref(computedStyle))
			}, null, 4)], 16, _hoisted_1$3)) : (openBlock(), createElementBlock("div", mergeProps({
				key: 1,
				id: __props.id
			}, _ctx.$attrs, {
				class: ["dd-switch-input", {
					"dd-switch-input-checked": unref(isOn),
					"dd-switch-input-disabled": __props.disabled
				}],
				"data-dd-label-target": "",
				role: "switch",
				tabindex: __props.disabled ? -1 : 0,
				"aria-checked": unref(isOn),
				"aria-disabled": __props.disabled,
				onClick: handleClicked,
				onKeydown: [withKeys(withModifiers(handleClicked, ["prevent"]), ["enter"]), withKeys(withModifiers(handleClicked, ["prevent"]), ["space"])]
			}), [createBaseVNode("i", {
				class: "dd-switch-input-inner",
				style: normalizeStyle(unref(computedStyle))
			}, null, 4)], 16, _hoisted_2$2));
		};
	}
};
var switch_exports = /* @__PURE__ */ __exportAll({ default: () => switch_default });
var switch_default = withInstall(_sfc_main$5);
var _sfc_main$4 = {
	__name: "Template",
	props: {
		is: {
			type: String,
			required: true
		},
		data: { type: Object }
	},
	setup(__props) {
		const props = __props;
		const tplCom = computed(() => {
			return `dd-tpl-${props.is}`;
		});
		const bindProps = computed(() => {
			return { ...props.data || {} };
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(resolveDynamicComponent(unref(tplCom)), normalizeProps(guardReactiveProps({
				..._ctx.$attrs,
				data: unref(bindProps)
			})), null, 16);
		};
	}
};
var template_exports = /* @__PURE__ */ __exportAll({ default: () => template_default });
var template_default = withInstall(_sfc_main$4);
var _sfc_main$3 = {
	__name: "Text",
	props: {
		/** @deprecated 请使用 user-select */
		selectable: {
			type: Boolean,
			default: false
		},
		/**
		* 文本是否可选，该属性会使文本节点显示为 inline-block
		*/
		userSelect: {
			type: Boolean,
			default: false
		},
		/**
		* 显示连续空格
		* ensp	中文字符空格一半大小
		* emsp	中文字符空格大小
		* nbsp	根据字体设置的空格大小
		*/
		space: {
			type: String,
			validator: (value) => {
				return [
					"ensp",
					"emsp",
					"nbsp"
				].includes(value);
			}
		},
		/**
		* 是否解码
		* decode可以解析的有 &nbsp; &lt; &gt; &amp; &apos; &ensp; &emsp;
		*/
		decode: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const props = __props;
		const textRef = /* @__PURE__ */ ref(null);
		function htmlDecode(e) {
			const spaces = {
				nbsp: "\xA0",
				ensp: " ",
				emsp: " "
			};
			if (spaces[props.space]) e = e.replace(/ /g, spaces[props.space]);
			if (props.decode) e = e.replace(/&nbsp;/g, "\xA0").replace(/&ensp;/g, " ").replace(/&emsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&apos;/g, "'").replace(/&amp;/g, "&");
			return e;
		}
		function transformTextNodes() {
			if (textRef.value) {
				const walker = document.createTreeWalker(textRef.value, NodeFilter.SHOW_TEXT);
				const nodes = [];
				let node = walker.nextNode();
				while (node) {
					nodes.push(node);
					node = walker.nextNode();
				}
				for (const textNode of nodes) {
					const text = textNode.nodeValue;
					const decodedText = htmlDecode(text);
					const splitText = decodedText.split("\\n");
					if (splitText.length > 1) {
						const newNode = document.createDocumentFragment();
						for (let i = 0; i < splitText.length; i++) {
							newNode.appendChild(document.createTextNode(splitText[i]));
							if (i < splitText.length - 1) newNode.appendChild(document.createElement("br"));
						}
						textNode.parentNode.replaceChild(newNode, textNode);
					} else if (decodedText !== text) {
						const newNode = document.createTextNode(decodedText);
						textNode.parentNode.replaceChild(newNode, textNode);
					}
				}
			}
		}
		onMounted(transformTextNodes);
		onUpdated(transformTextNodes);
		const info = useInfo();
		if (hasEvent(info, "tap")) useTapEvents(textRef, (event) => {
			triggerEvent("tap", {
				event,
				info
			});
		});
		const canSelect = computed(() => props.userSelect || props.selectable);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", mergeProps({
				ref_key: "textRef",
				ref: textRef
			}, _ctx.$attrs, { class: ["dd-text", { "dd-text-selectable": unref(canSelect) }] }), [renderSlot(_ctx.$slots, "default")], 16);
		};
	}
};
var text_exports = /* @__PURE__ */ __exportAll({ default: () => text_default });
var text_default = withInstall(_sfc_main$3);
var _hoisted_1$2 = [
	"id",
	"value",
	"disabled",
	"maxlength",
	"autocomplete"
];
var _sfc_main$2 = {
	__name: "Textarea",
	props: {
		/**
		* id，为 label 使用
		*/
		id: { type: String },
		/**
		* name，为表单使用
		*/
		name: { type: String },
		/**
		* 输入框的内容
		*/
		value: {
			type: String,
			required: false,
			default: ""
		},
		/**
		* 输入框为空时占位符
		*/
		placeholder: {
			type: String,
			required: false
		},
		/**
		* 指定 placeholder 的样式，目前仅支持color,font-size和font-weight
		*/
		placeholderStyle: {
			type: [String, Object],
			required: false,
			default() {
				return {};
			}
		},
		/**
		* 是否禁用
		*/
		disabled: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 最大输入长度，设置为 -1 的时候不限制最大长度
		*/
		maxlength: {
			type: Number,
			default: 140,
			required: false
		},
		/**
		* 自动聚焦，拉起键盘
		*/
		autoFocus: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 获取焦点
		*/
		focus: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 是否自动增高，设置auto-height时，style.height不生效
		*/
		autoHeight: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 指定光标与键盘的距离。取textarea距离底部的距离和cursor-spacing指定的距离的最小值作为光标与键盘的距离
		*/
		cursorSpacing: {
			type: Number,
			default: 0,
			required: false
		},
		/**
		* 指定focus时的光标位置
		*/
		cursor: {
			type: Number,
			default: -1,
			required: false
		},
		/**
		* 是否显示键盘上方带有"完成"按钮那一栏
		*/
		showConfirmBar: {
			type: Boolean,
			default: true,
			required: false
		},
		/**
		* 光标起始位置，自动聚集时有效，需与selection-end搭配使用
		*/
		selectionStart: {
			type: Number,
			default: -1,
			required: false
		},
		/**
		* 光标结束位置，自动聚集时有效，需与selection-start搭配使用
		*/
		selectionEnd: {
			type: Number,
			default: -1,
			required: false
		},
		/**
		* 键盘弹起时，是否自动上推页面
		*/
		adjustPosition: {
			type: Boolean,
			default: true,
			required: false
		},
		/**
		* focus时，点击页面的时候不收起键盘
		*/
		holdKeyboard: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 是否去掉 iOS 下的默认内边距
		*/
		disableDefaultPadding: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 设置键盘右下角按钮的文字
		*/
		confirmType: {
			type: String,
			default: "return",
			required: false,
			validator: (value) => [
				"send",
				"search",
				"next",
				"go",
				"done",
				"return"
			].includes(value)
		},
		/**
		* 点击键盘右下角按钮时是否保持键盘不收起
		*/
		confirmHold: {
			type: Boolean,
			default: false,
			required: false
		},
		/**
		* 键盘对齐位置
		*/
		adjustKeyboardTo: {
			type: String,
			default: "cursor",
			required: false,
			validator: (value) => ["cursor", "bottom"].includes(value)
		},
		/**
		* 指定 placeholder 的样式类，目前仅支持color,font-size和font-weight
		*/
		placeholderClass: {
			type: String,
			default: "textarea-placeholder"
		},
		/**
		* 如果 textarea 是在一个 position:fixed 的区域，需要显示指定属性 fixed 为 true
		*/
		fixed: {
			type: Boolean,
			default: false
		},
		keyboardAppearance: {
			type: String,
			default: "default"
		},
		confirm: {
			type: Boolean,
			default: true
		},
		autoFill: {
			type: String,
			default: ""
		}
	},
	emits: ["update:value"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const computedPlaceholderStyle = computed(() => {
			const placeholderColor = () => {
				if (typeof props.placeholderStyle === "string") {
					const match = props.placeholderStyle.match(/color:([^;]+)/);
					if (match) return match[1].trim();
				} else if (props.placeholderStyle && typeof props.placeholderStyle === "object") {
					if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "color")) return props.placeholderStyle.color;
				}
				return "rgba(0,0,0,.3)";
			};
			const placeholderFontSize = () => {
				let size;
				if (typeof props.placeholderStyle === "string") {
					const match = props.placeholderStyle.match(/font-size:([^;]+)/);
					if (match) size = match[1].trim();
				} else if (props.placeholderStyle && typeof props.placeholderStyle === "object") {
					if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-size")) size = props.placeholderStyle["font-size"];
				}
				return size ? transformRpx(size) : "inherit";
			};
			const placeholderFontWeight = () => {
				if (typeof props.placeholderStyle === "string") {
					const match = props.placeholderStyle.match(/font-weight:([^;]+)/);
					if (match) return match[1].trim();
				} else if (props.placeholderStyle && typeof props.placeholderStyle === "object") {
					if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-weight")) return props.placeholderStyle["font-weight"];
				}
				return "inherit";
			};
			return {
				color: placeholderColor(),
				fontSize: placeholderFontSize(),
				fontWeight: placeholderFontWeight()
			};
		});
		const collectFormValue = inject("collectFormValue", void 0);
		const registerFormControl = inject("registerFormControl", void 0);
		collectFormValue?.(props.name, props.value);
		const textareaRef = /* @__PURE__ */ ref(null);
		const keyCode = /* @__PURE__ */ ref(null);
		const iValue = /* @__PURE__ */ ref(props.value);
		const unregisterFormControl = registerFormControl?.({
			getName: () => props.name,
			getValue: () => iValue.value,
			reset: () => {
				iValue.value = "";
				collectFormValue?.(props.name, iValue.value);
			}
		});
		onBeforeUnmount(() => unregisterFormControl?.());
		const placeholderShow = computed(() => {
			return iValue.value === void 0 || iValue.value === null || iValue.value === "" || typeof iValue.value === "string" && iValue.value.length === 0;
		});
		/**
		* 自定义 v-focus 指令
		*/
		const vFocus = { mounted: (el) => {
			if (!props.autoFocus && !props.focus) return;
			el.focus();
			applySelection(el);
		} };
		function applySelection(element = textareaRef.value) {
			if (!element?.setSelectionRange) return;
			const cursor = Number(props.cursor);
			const start = cursor >= 0 ? cursor : Number(props.selectionStart);
			const end = cursor >= 0 ? cursor : Number(props.selectionEnd);
			if (start >= 0) element.setSelectionRange(start, end >= 0 ? end : start);
		}
		watch([() => props.focus, () => props.value], ([nF, nV], [, preV]) => {
			if (nF) {
				textareaRef.value.focus();
				applySelection();
			}
			if (preV !== nV) iValue.value = nV;
		});
		const wrapperRef = /* @__PURE__ */ ref(null);
		const info = useInfo();
		const keyboardAccessoryVisible = /* @__PURE__ */ ref(false);
		provide("keyboardAccessoryVisible", keyboardAccessoryVisible);
		useKeyboardHeight(info, keyboardAccessoryVisible);
		function handleKeydown(event) {
			keyCode.value = event.keyCode;
			if (event.keyCode === 13) {
				if (!props.confirmHold) event.target.blur();
				triggerEvent("confirm", {
					event,
					info,
					detail: { value: event.target.value }
				});
			}
		}
		let lastLineCount;
		function updateLineInfo(event) {
			const element = textareaRef.value;
			if (!element) return;
			const style = window.getComputedStyle(element);
			const fontSize = Number.parseFloat(style.fontSize) || 16;
			const lineHeight = Number.parseFloat(style.lineHeight) || fontSize * 1.2;
			const height = Math.max(element.scrollHeight, lineHeight);
			const lineCount = Math.max(Math.floor(height / lineHeight), 1);
			if (props.autoHeight) wrapperRef.value.style.height = `${height}px`;
			if (lineCount !== lastLineCount) {
				lastLineCount = lineCount;
				triggerEvent("linechange", {
					event,
					info,
					detail: {
						height,
						heightRpx: height * 750 / Math.max(window.innerWidth, 1),
						lineCount
					}
				});
			}
		}
		onMounted(() => nextTick(() => updateLineInfo()));
		watch(() => [props.value, props.autoHeight], () => nextTick(() => updateLineInfo()));
		function handleWrapperEvent(event) {
			if (event.target.tagName.toLowerCase() !== "textarea") return;
			const value = event.target.value;
			switch (event.type) {
				case "input":
					collectFormValue?.(props.name, value);
					iValue.value = value;
					emit("update:value", value);
					triggerEvent("input", {
						event,
						info,
						detail: {
							value,
							cursor: event.target.selectionEnd,
							keyCode: keyCode.value
						},
						success: (data) => {
							iValue.value = data.value ?? data;
							emit("update:value", data.value ?? data);
						}
					});
					updateLineInfo(event);
					break;
				case "focusin":
					keyboardAccessoryVisible.value = true;
					applySelection(event.target);
					triggerEvent("focus", {
						event,
						info,
						detail: { value }
					});
					if (!isDesktop && props.adjustPosition) {
						const element = wrapperRef.value;
						if (!element) return;
						const bottom = getActualBottom(element);
						invokeAPI("adjustPosition", {
							bridgeId: info.bridgeId,
							params: { bottom }
						});
					}
					break;
				case "focusout":
					keyboardAccessoryVisible.value = false;
					triggerEvent("blur", {
						event,
						info,
						detail: {
							value,
							cursor: event.target.selectionEnd
						}
					});
					break;
				case "change":
					triggerEvent("change", {
						event,
						info,
						detail: { value }
					});
					break;
			}
		}
		const wrapperClass = computed(() => {
			return {
				"dd-textarea-wrapper": true,
				"dd-textarea-disabled": props.disabled
			};
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", mergeProps({
				ref_key: "wrapperRef",
				ref: wrapperRef
			}, _ctx.$attrs, {
				class: unref(wrapperClass),
				role: "textbox",
				"data-dd-label-target": "",
				onInput: handleWrapperEvent,
				onFocusin: handleWrapperEvent,
				onFocusout: handleWrapperEvent,
				onChange: handleWrapperEvent
			}), [
				withDirectives(createBaseVNode("textarea", {
					id: __props.id,
					ref_key: "textareaRef",
					ref: textareaRef,
					class: "dd-textarea",
					value: unref(iValue),
					disabled: __props.disabled,
					maxlength: __props.maxlength,
					autocomplete: __props.autoFill || void 0,
					onKeydown: handleKeydown
				}, null, 40, _hoisted_1$2), [[vFocus]]),
				withDirectives(createBaseVNode("div", {
					class: normalizeClass(["dd-textarea-placeholder", __props.placeholderClass]),
					style: normalizeStyle(unref(computedPlaceholderStyle))
				}, toDisplayString(__props.placeholder), 7), [[vShow, unref(placeholderShow)]]),
				renderSlot(_ctx.$slots, "default")
			], 16);
		};
	}
};
var textarea_exports = /* @__PURE__ */ __exportAll({ default: () => textarea_default });
var textarea_default = withInstall(_sfc_main$2);
var _hoisted_1$1 = ["id", "data-dimina-native-id"];
var _hoisted_2$1 = ["id"];
var _hoisted_3 = ["id"];
var _hoisted_4 = [
	"id",
	"src",
	"controls",
	"autoplay",
	"loop",
	"muted",
	"poster",
	"referrerpolicy"
];
var type$1 = "native/video";
var _sfc_main$1 = {
	__name: "Video",
	props: {
		/**
		* 组件 id
		*/
		id: {
			type: String,
			default: () => `video-${Math.random().toString(36).slice(2, 10)}`
		},
		/**
		* 要播放视频的资源地址，支持网络路径、本地临时路径
		*/
		src: {
			type: String,
			default: ""
		},
		/**
		* 指定视频时长
		*/
		duration: {
			type: Number,
			default: 0
		},
		/**
		* 是否显示默认播放控件（播放/暂停按钮、播放进度、时间）
		*/
		controls: {
			type: Boolean,
			required: false,
			default: true
		},
		autoplay: {
			type: Boolean,
			default: false
		},
		loop: {
			type: Boolean,
			default: false
		},
		muted: {
			type: Boolean,
			default: false
		},
		initialTime: {
			type: Number,
			default: 0
		},
		objectFit: {
			type: String,
			default: "contain"
		},
		poster: {
			type: String,
			default: ""
		},
		pageGesture: {
			type: Boolean,
			default: false
		},
		direction: {
			type: [Number, String],
			default: -1
		},
		showProgress: {
			type: Boolean,
			default: true
		},
		showFullscreenBtn: {
			type: Boolean,
			default: true
		},
		showPlayBtn: {
			type: Boolean,
			default: true
		},
		showCenterPlayBtn: {
			type: Boolean,
			default: true
		},
		enableProgressGesture: {
			type: Boolean,
			default: true
		},
		showMuteBtn: {
			type: Boolean,
			default: false
		},
		title: {
			type: String,
			default: ""
		},
		playBtnPosition: {
			type: String,
			default: "bottom"
		},
		enablePlayGesture: {
			type: Boolean,
			default: false
		},
		autoPauseIfNavigate: {
			type: Boolean,
			default: true
		},
		autoPauseIfOpenNative: {
			type: Boolean,
			default: true
		},
		vslideGesture: {
			type: Boolean,
			default: false
		},
		vslideGestureInFullscreen: {
			type: Boolean,
			default: true
		},
		adUnitId: {
			type: String,
			default: ""
		},
		unitId: {
			type: String,
			default: ""
		},
		adPlayTime: {
			type: Number,
			default: 0
		},
		danmuBtn: {
			type: Boolean,
			default: false
		},
		enableDanmu: {
			type: Boolean,
			default: false
		},
		danmuList: {
			type: Array,
			default: () => []
		},
		live: {
			type: [Number, Boolean],
			default: false
		},
		customCache: {
			type: Boolean,
			default: true
		},
		blockSize: {
			type: Number,
			default: 0
		},
		posterForCrawler: {
			type: String,
			default: ""
		},
		showLiveBtn: {
			type: Boolean,
			default: true
		},
		showBottomProgress: {
			type: Boolean,
			default: true
		},
		showCenterProgressDuration: {
			type: Boolean,
			default: false
		},
		showVolumeBtn: {
			type: Boolean,
			default: false
		},
		showCastingButton: {
			type: Boolean,
			default: false
		},
		seekType: {
			type: String,
			default: "accurate"
		},
		pictureInPictureMode: {
			type: [Array, String],
			default: ""
		},
		pictureInPictureShowProgress: {
			type: Boolean,
			default: false
		},
		enableAutoRotation: {
			type: Boolean,
			default: false
		},
		showScreenLockButton: {
			type: Boolean,
			default: false
		},
		showSnapshotButton: {
			type: Boolean,
			default: false
		},
		showBackgroundPlaybackButton: {
			type: Boolean,
			default: false
		},
		backgroundPoster: {
			type: String,
			default: ""
		},
		referrerPolicy: {
			type: String,
			default: "no-referrer"
		},
		isDrm: {
			type: Boolean,
			default: false
		},
		provisionUrl: {
			type: String,
			default: ""
		},
		certificateUrl: {
			type: String,
			default: ""
		},
		licenseUrl: {
			type: String,
			default: ""
		},
		preferredPeakBitRate: {
			type: Number,
			default: -1
		}
	},
	setup(__props) {
		const props = __props;
		const rootRef = /* @__PURE__ */ ref();
		const info = useInfo();
		const isNativeVideo = computed(() => isAndroid || isIOS || isHarmonyOS);
		let syncFrameId = 0;
		let lastRectKey = "";
		const nativeEventOffs = [];
		let resizeObserver;
		let nativeMounted = false;
		function getRect() {
			const element = rootRef.value;
			if (!element) return {};
			const rect = element.getBoundingClientRect();
			return {
				left: rect.left,
				top: rect.top,
				width: rect.width,
				height: rect.height,
				pageLeft: rect.left + window.scrollX,
				pageTop: rect.top + window.scrollY,
				scrollX: window.scrollX,
				scrollY: window.scrollY,
				viewportWidth: window.innerWidth,
				viewportHeight: window.innerHeight
			};
		}
		function getNativeParams() {
			return {
				type: type$1,
				id: props.id,
				src: props.src,
				duration: props.duration,
				controls: props.controls,
				autoplay: props.autoplay,
				loop: props.loop,
				muted: props.muted,
				initialTime: props.initialTime,
				objectFit: props.objectFit,
				poster: props.poster,
				pageGesture: props.pageGesture,
				direction: props.direction,
				showProgress: props.showProgress,
				showFullscreenBtn: props.showFullscreenBtn,
				showPlayBtn: props.showPlayBtn,
				showCenterPlayBtn: props.showCenterPlayBtn,
				enableProgressGesture: props.enableProgressGesture,
				showMuteBtn: props.showMuteBtn,
				title: props.title,
				playBtnPosition: props.playBtnPosition,
				enablePlayGesture: props.enablePlayGesture,
				autoPauseIfNavigate: props.autoPauseIfNavigate,
				autoPauseIfOpenNative: props.autoPauseIfOpenNative,
				vslideGesture: props.vslideGesture,
				vslideGestureInFullscreen: props.vslideGestureInFullscreen,
				adUnitId: props.adUnitId,
				unitId: props.unitId,
				adPlayTime: props.adPlayTime,
				danmuBtn: props.danmuBtn,
				enableDanmu: props.enableDanmu,
				danmuList: props.danmuList,
				live: props.live,
				customCache: props.customCache,
				blockSize: props.blockSize,
				posterForCrawler: props.posterForCrawler,
				showLiveBtn: props.showLiveBtn,
				showBottomProgress: props.showBottomProgress,
				showCenterProgressDuration: props.showCenterProgressDuration,
				showVolumeBtn: props.showVolumeBtn,
				showCastingButton: props.showCastingButton,
				seekType: props.seekType,
				pictureInPictureMode: props.pictureInPictureMode,
				pictureInPictureShowProgress: props.pictureInPictureShowProgress,
				enableAutoRotation: props.enableAutoRotation,
				showScreenLockButton: props.showScreenLockButton,
				showSnapshotButton: props.showSnapshotButton,
				showBackgroundPlaybackButton: props.showBackgroundPlaybackButton,
				backgroundPoster: props.backgroundPoster,
				referrerPolicy: props.referrerPolicy,
				isDrm: props.isDrm,
				provisionUrl: props.provisionUrl,
				certificateUrl: props.certificateUrl,
				licenseUrl: props.licenseUrl,
				preferredPeakBitRate: props.preferredPeakBitRate,
				hidden: rootRef.value?.hasAttribute("hidden") || false,
				rect: getRect()
			};
		}
		function invokeNative(apiName) {
			if (!isNativeVideo.value) return;
			if (apiName === "propsUpdate" && !nativeMounted) return;
			invokeAPI(apiName, {
				bridgeId: info.bridgeId,
				params: getNativeParams()
			});
		}
		function syncRect(force = false) {
			const rectKey = JSON.stringify({
				...getRect(),
				hidden: rootRef.value?.hasAttribute("hidden") || false
			});
			if (force || rectKey !== lastRectKey) {
				lastRectKey = rectKey;
				invokeNative("propsUpdate");
			}
		}
		function scheduleSyncRect() {
			if (syncFrameId) return;
			syncFrameId = requestAnimationFrame(() => {
				syncFrameId = 0;
				syncRect();
			});
		}
		function bindNativeEvent(nativeEvent, eventType, detailFactory = (msg) => msg) {
			const off = onEvent(nativeEvent, (msg) => {
				if (msg.id !== props.id) return;
				triggerEvent(eventType, {
					type: eventType,
					info,
					detail: detailFactory(msg)
				});
			});
			nativeEventOffs.push(off);
		}
		function executeWebVideoCommand(msg) {
			const video = rootRef.value;
			if (!video || msg.id !== props.id) return;
			switch (msg.command) {
				case "play":
					video.play()?.catch((error) => {
						triggerEvent("error", {
							info,
							detail: { errMsg: error?.message || "video play failed" }
						});
					});
					break;
				case "pause":
					video.pause();
					break;
				case "stop":
					video.pause();
					video.currentTime = 0;
					break;
				case "seek":
					video.currentTime = Number(msg.position) || 0;
					break;
				case "playbackRate":
					video.playbackRate = Number(msg.rate) || 1;
					break;
				case "requestFullScreen":
					video.requestFullscreen?.() || video.webkitRequestFullscreen?.();
					break;
				case "exitFullScreen":
					document.exitFullscreen?.() || document.webkitExitFullscreen?.();
					break;
				case "exitPictureInPicture":
					document.pictureInPictureElement && document.exitPictureInPicture?.();
					break;
				default: break;
			}
		}
		function bindVideoContextEvent() {
			const off = onEvent("videoContext", (msg) => {
				if (msg.id !== props.id) return;
				if (isNativeVideo.value) {
					invokeAPI("videoContext", {
						bridgeId: info.bridgeId,
						params: msg
					});
					return;
				}
				executeWebVideoCommand(msg);
			});
			nativeEventOffs.push(off);
		}
		function triggerVideoEvent(type, event, detail = {}) {
			triggerEvent(type, {
				event,
				info,
				detail
			});
		}
		function handleLoadedMetadata(event) {
			const video = event.target;
			if (props.initialTime > 0 && Number.isFinite(video.duration)) video.currentTime = Math.min(props.initialTime, video.duration);
			triggerVideoEvent("loadedmetadata", event, { duration: video.duration || 0 });
		}
		function handleProgress(event) {
			const video = event.target;
			const buffered = video.buffered;
			triggerVideoEvent("progress", event, {
				buffered: buffered?.length ? buffered.end(buffered.length - 1) : 0,
				duration: video.duration || 0
			});
		}
		onMounted(() => {
			bindVideoContextEvent();
			if (!isNativeVideo.value) return;
			if (isAndroid) ensureNativeLayerTouchBridge();
			bindNativeEvent("bindplay", "play");
			bindNativeEvent("bindpause", "pause");
			bindNativeEvent("bindended", "ended");
			bindNativeEvent("bindwaiting", "waiting");
			bindNativeEvent("binderror", "error");
			bindNativeEvent("bindloadeddata", "loadeddata");
			bindNativeEvent("bindloadstart", "loadstart");
			bindNativeEvent("bindloadedmetadata", "loadedmetadata");
			bindNativeEvent("bindfullscreenchange", "fullscreenchange");
			bindNativeEvent("bindprogress", "progress");
			bindNativeEvent("bindseeking", "seeking");
			bindNativeEvent("bindseeked", "seeked");
			bindNativeEvent("bindcontrolstoggle", "controlstoggle");
			bindNativeEvent("bindenterpictureinpicture", "enterpictureinpicture");
			bindNativeEvent("bindleavepictureinpicture", "leavepictureinpicture");
			bindNativeEvent("bindpreloadedmetadata", "preloadedmetadata");
			bindNativeEvent("bindrendererror", "rendererror");
			bindNativeEvent("bindseekcomplete", "seekcomplete");
			bindNativeEvent("bindinsertweblayerfailed", "insertweblayerfailed");
			bindNativeEvent("bindinsertweblayersuccess", "insertweblayersuccess");
			bindNativeEvent("bindtimeupdate", "timeupdate", (msg) => ({
				currentTime: msg.currentTime,
				duration: msg.duration
			}));
			nextTick(() => {
				nativeMounted = true;
				invokeNative("componentMount");
				lastRectKey = JSON.stringify({
					...getRect(),
					hidden: rootRef.value?.hasAttribute("hidden") || false
				});
				window.addEventListener("resize", scheduleSyncRect);
				window.addEventListener("scroll", scheduleSyncRect, true);
				if (window.ResizeObserver && rootRef.value) {
					resizeObserver = new ResizeObserver(scheduleSyncRect);
					resizeObserver.observe(rootRef.value);
				}
			});
		});
		watch(() => getNativeParams(), () => invokeNative("propsUpdate"), { deep: true });
		onBeforeUnmount(() => {
			if (syncFrameId) cancelAnimationFrame(syncFrameId);
			resizeObserver?.disconnect();
			window.removeEventListener("resize", scheduleSyncRect);
			window.removeEventListener("scroll", scheduleSyncRect, true);
			invokeNative("componentUnmount");
			nativeMounted = false;
			nativeEventOffs.splice(0).forEach((off) => off());
		});
		return (_ctx, _cache) => {
			return unref(isAndroid) ? (openBlock(), createElementBlock("embed", mergeProps({
				key: 0,
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef,
				width: "300",
				height: "225"
			}, _ctx.$attrs, {
				class: "dd-video",
				"data-dimina-native-type": "native/video",
				"data-dimina-native-id": __props.id,
				type: "application/view",
				comp_type: type$1
			}), null, 16, _hoisted_1$1)) : unref(isIOS) ? (openBlock(), createElementBlock("div", mergeProps({
				key: 1,
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef
			}, _ctx.$attrs, { class: "dd-video" }), [..._cache[13] || (_cache[13] = [createBaseVNode("div", { class: "dd-video-container" }, [createBaseVNode("div", { style: {
				"width": "101%",
				"height": "101%"
			} })], -1)])], 16, _hoisted_2$1)) : unref(isHarmonyOS) ? (openBlock(), createElementBlock("embed", mergeProps({
				key: 2,
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef
			}, _ctx.$attrs, {
				class: "dd-video",
				type: type$1
			}), null, 16, _hoisted_3)) : unref(isDesktop) ? (openBlock(), createElementBlock("video", mergeProps({
				key: 3,
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef,
				width: "300",
				height: "225"
			}, _ctx.$attrs, {
				class: "dd-video",
				src: __props.src,
				controls: __props.controls,
				autoplay: __props.autoplay,
				loop: __props.loop,
				muted: __props.muted,
				poster: __props.poster || __props.posterForCrawler,
				referrerpolicy: __props.referrerPolicy,
				playsinline: true,
				"webkit-playsinline": true,
				style: { objectFit: __props.objectFit },
				onPlay: _cache[0] || (_cache[0] = ($event) => triggerVideoEvent("play", $event)),
				onPause: _cache[1] || (_cache[1] = ($event) => triggerVideoEvent("pause", $event)),
				onEnded: _cache[2] || (_cache[2] = ($event) => triggerVideoEvent("ended", $event)),
				onWaiting: _cache[3] || (_cache[3] = ($event) => triggerVideoEvent("waiting", $event)),
				onError: _cache[4] || (_cache[4] = ($event) => triggerVideoEvent("error", $event, { errMsg: $event.target?.error?.message || "video error" })),
				onLoadstart: _cache[5] || (_cache[5] = ($event) => triggerVideoEvent("loadstart", $event)),
				onLoadeddata: _cache[6] || (_cache[6] = ($event) => triggerVideoEvent("loadeddata", $event)),
				onLoadedmetadata: handleLoadedMetadata,
				onProgress: handleProgress,
				onSeeking: _cache[7] || (_cache[7] = ($event) => triggerVideoEvent("seeking", $event, { currentTime: $event.target?.currentTime || 0 })),
				onSeeked: _cache[8] || (_cache[8] = ($event) => triggerVideoEvent("seeked", $event, { currentTime: $event.target?.currentTime || 0 })),
				onFullscreenchange: _cache[9] || (_cache[9] = ($event) => triggerVideoEvent("fullscreenchange", $event, {
					fullScreen: Boolean(_ctx.document.fullscreenElement),
					direction: __props.direction
				})),
				onEnterpictureinpicture: _cache[10] || (_cache[10] = ($event) => triggerVideoEvent("enterpictureinpicture", $event)),
				onLeavepictureinpicture: _cache[11] || (_cache[11] = ($event) => triggerVideoEvent("leavepictureinpicture", $event)),
				onTimeupdate: _cache[12] || (_cache[12] = ($event) => triggerVideoEvent("timeupdate", $event, {
					currentTime: $event.target?.currentTime || 0,
					duration: $event.target?.duration || 0
				}))
			}), null, 16, _hoisted_4)) : (openBlock(), createElementBlock("div", mergeProps({ key: 4 }, _ctx.$attrs, { class: "dd-video dd-video-placeholder" }), " 未实现组件 ", 16));
		};
	}
};
var video_exports = /* @__PURE__ */ __exportAll({ default: () => video_default });
var video_default = withInstall(_sfc_main$1);
var view_exports = /* @__PURE__ */ __exportAll({ default: () => view_default });
var view_default = withInstall(_sfc_main$32);
var _hoisted_1 = ["id", "src"];
var _hoisted_2 = ["id"];
var UNMATCHED_SURROGATE_PAIR_REPLACE = "$1�$2";
var type = "native/webview";
var _sfc_main = {
	__name: "WebView",
	props: {
		id: {
			type: String,
			default: () => `webview-${useId()}`
		},
		src: {
			type: String,
			default: ""
		}
	},
	setup(__props) {
		const props = __props;
		const ENCODE_CHARS_REGEXP = /(?:[^\x21\x25\x26-\x3B\x3D\x3F-\x5B\x5D\x5F\x7E]|%(?:[^0-9A-F]|[0-9A-F][^0-9A-F]|$))+/gi;
		const UNMATCHED_SURROGATE_PAIR_REGEXP = /(^|[^\uD800-\uDBFF])[\uDC00-\uDFFF]|[\uD800-\uDBFF]([^\uDC00-\uDFFF]|$)/g;
		const rootRef = /* @__PURE__ */ ref();
		const url = computed(() => props.src.replace(UNMATCHED_SURROGATE_PAIR_REGEXP, UNMATCHED_SURROGATE_PAIR_REPLACE).replace(ENCODE_CHARS_REGEXP, encodeURI));
		const info = useInfo();
		const nativeEventOffs = [];
		function getEventAttrs() {
			const eventAttrs = {};
			for (const attrName in info.attrs) if (attrName.startsWith("bind") || attrName.startsWith("catch")) eventAttrs[attrName.replace(/^(?:bind:|bind|catch:|catch)/, "")] = info.attrs[attrName];
			return eventAttrs;
		}
		function getNativeParams() {
			return {
				type,
				url: url.value,
				src: url.value,
				id: props.id,
				attributes: {
					moduleId: info.moduleId,
					attrs: getEventAttrs(),
					src: url.value,
					javascript: `
				function handleSdkFn(){
					window.__wxjs_environment = 'miniprogram';
					var sdk = document.createElement('script');
					sdk.onload = function(){ window.dispatchEvent(new Event('didiJsBridgeLoaded')); };
					sdk.src = 'https://dpubstatic.udache.com/static/dpubimg/UBi0mvYdYcbwXv5qZ9ANw_jdimina_next.js?' + Date.now();
					document.getElementsByTagName('html')[0].appendChild(sdk);
				}
				handleSdkFn();`
				}
			};
		}
		function invokeNative(apiName) {
			if (isDesktop) return;
			invokeAPI(apiName, {
				bridgeId: info.bridgeId,
				params: getNativeParams()
			});
		}
		function bindNativeEvent(nativeEvent, eventType, detailFactory = (msg) => msg) {
			const off = onEvent(nativeEvent, (msg) => {
				if (msg.id !== void 0 && msg.id !== props.id && msg.webviewId !== props.id) return;
				triggerEvent(eventType, {
					type: eventType,
					info,
					detail: detailFactory(msg)
				});
			});
			nativeEventOffs.push(off);
		}
		function handleDesktopMessage(event) {
			if (event.source !== rootRef.value?.contentWindow) return;
			triggerEvent("message", {
				type: "message",
				info,
				detail: { data: event.data }
			});
		}
		function handleDesktopLoad(event) {
			triggerEvent("load", {
				type: "load",
				event,
				info,
				detail: { src: url.value }
			});
		}
		function handleDesktopError(event) {
			triggerEvent("error", {
				type: "error",
				event,
				info,
				detail: {
					url: url.value,
					fullUrl: url.value
				}
			});
		}
		onMounted(() => {
			if (isDesktop) {
				window.addEventListener("message", handleDesktopMessage);
				return;
			}
			bindNativeEvent("bindmessage", "message", (msg) => ({ data: msg.data }));
			bindNativeEvent("bindload", "load", (msg) => ({
				src: msg.src || msg.url,
				id: msg.id
			}));
			bindNativeEvent("binderror", "error", (msg) => ({
				url: msg.url,
				fullUrl: msg.fullUrl,
				id: msg.id
			}));
			invokeNative("componentMount");
		});
		watch(() => [props.id, url.value], () => invokeNative("propsUpdate"));
		onBeforeUnmount(() => {
			window.removeEventListener("message", handleDesktopMessage);
			invokeNative("componentUnmount");
			nativeEventOffs.splice(0).forEach((off) => off());
		});
		return (_ctx, _cache) => {
			return unref(isDesktop) ? (openBlock(), createElementBlock("iframe", mergeProps({
				key: 0,
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef
			}, _ctx.$attrs, {
				class: "dd-web-view dd-web-view-pc",
				src: unref(url),
				onLoad: handleDesktopLoad,
				onError: handleDesktopError
			}), null, 16, _hoisted_1)) : (openBlock(), createElementBlock("embed", mergeProps({
				key: 1,
				id: __props.id,
				ref_key: "rootRef",
				ref: rootRef
			}, _ctx.$attrs, {
				class: "dd-web-view",
				type
			}), null, 16, _hoisted_2));
		};
	}
};
var web_view_exports = /* @__PURE__ */ __exportAll({ default: () => web_view_default });
var web_view_default = withInstall(_sfc_main);
var components = Object.values(/* @__PURE__ */ Object.assign({
	"./component/block/index.js": block_exports,
	"./component/button/index.js": button_exports,
	"./component/camera/index.js": camera_exports,
	"./component/canvas/index.js": canvas_exports,
	"./component/checkbox/index.js": checkbox_exports,
	"./component/checkbox-group/index.js": checkbox_group_exports,
	"./component/component-host/index.js": component_host_exports,
	"./component/cover-image/index.js": cover_image_exports,
	"./component/cover-view/index.js": cover_view_exports,
	"./component/form/index.js": form_exports,
	"./component/icon/index.js": icon_exports,
	"./component/image/index.js": image_exports,
	"./component/input/index.js": input_exports,
	"./component/keyboard-accessory/index.js": keyboard_accessory_exports,
	"./component/label/index.js": label_exports,
	"./component/map/index.js": map_exports,
	"./component/movable-area/index.js": movable_area_exports,
	"./component/movable-view/index.js": movable_view_exports,
	"./component/navigation-bar/index.js": navigation_bar_exports,
	"./component/navigator/index.js": navigator_exports,
	"./component/open-data/index.js": open_data_exports,
	"./component/page-meta/index.js": page_meta_exports,
	"./component/picker/index.js": picker_exports,
	"./component/picker-view/index.js": picker_view_exports,
	"./component/picker-view-column/index.js": picker_view_column_exports,
	"./component/progress/index.js": progress_exports,
	"./component/radio/index.js": radio_exports,
	"./component/radio-group/index.js": radio_group_exports,
	"./component/rich-text/index.js": rich_text_exports,
	"./component/root-portal/index.js": root_portal_exports,
	"./component/scroll-view/index.js": scroll_view_exports,
	"./component/slider/index.js": slider_exports,
	"./component/swiper/index.js": swiper_exports,
	"./component/swiper-item/index.js": swiper_item_exports,
	"./component/switch/index.js": switch_exports,
	"./component/template/index.js": template_exports,
	"./component/text/index.js": text_exports,
	"./component/textarea/index.js": textarea_exports,
	"./component/video/index.js": video_exports,
	"./component/view/index.js": view_exports,
	"./component/web-view/index.js": web_view_exports
})).map((module) => {
	return module.default;
});
var EXTERNAL_CLASS_SCOPE_ATTRIBUTE = "data-dd-external-class-scope";
var LEGACY_COMPONENT_TAG_ALIASES = { "component-host": ["dd-wrapper"] };
function transformAnimation(el, propertyValue) {
	if (!propertyValue?.actions?.length) return;
	let currentIndex = 0;
	const actions = propertyValue.actions;
	function executeAnimation() {
		if (currentIndex >= actions.length) return;
		const currentAction = actions[currentIndex];
		const style = animationToStyle(currentAction);
		const animation = el.animate(style.keyframes, style.options);
		animation.onfinish = () => {
			currentIndex++;
			executeAnimation();
		};
	}
	executeAnimation();
}
var directiveStyleState = /* @__PURE__ */ new WeakMap();
function snapshotStyle(style) {
	return new Map(Array.from(style, (name) => [name, {
		priority: style.getPropertyPriority(name),
		value: style.getPropertyValue(name)
	}]));
}
function restoreDirectiveStyle(el) {
	const originalDeclarations = directiveStyleState.get(el);
	if (!originalDeclarations) return;
	for (const name of originalDeclarations.keys()) el.style.removeProperty(name);
	for (const [name, declaration] of originalDeclarations) if (declaration) el.style.setProperty(name, declaration.value, declaration.priority);
	directiveStyleState.delete(el);
}
function transformCss(el, val) {
	const convertedStyle = transformRpx(val);
	if (typeof convertedStyle !== "string" || !convertedStyle.trim()) return;
	const before = snapshotStyle(el.style);
	el.style.cssText += convertedStyle;
	const after = snapshotStyle(el.style);
	const originalDeclarations = /* @__PURE__ */ new Map();
	const declarationNames = /* @__PURE__ */ new Set([...before.keys(), ...after.keys()]);
	for (const name of declarationNames) {
		const previous = before.get(name);
		const current = after.get(name);
		if (previous?.value !== current?.value || previous?.priority !== current?.priority) originalDeclarations.set(name, previous || null);
	}
	if (originalDeclarations.size) directiveStyleState.set(el, originalDeclarations);
}
function parseDataset(el, vnode) {
	el._ds = getDataAttributes(vnode.ctx.attrs, deepToRaw);
}
function parseExternalClass(el, instance, vnode) {
	const ctx = vnode.ctx;
	if (instance.props && Array.isArray(ctx.provides.externalClasses)) for (const externalClass of ctx.provides.externalClasses) {
		const clsName = instance.props[toCamelCase(externalClass)];
		if (clsName) {
			el.className = replaceExternalClassTokens(el.className, externalClass, clsName);
			if (!el.hasAttribute(instance.sId)) el.setAttribute(instance.sId, "");
			const scopeTokens = new Set((el.getAttribute(EXTERNAL_CLASS_SCOPE_ATTRIBUTE) || "").split(/\s+/).filter(Boolean));
			scopeTokens.add(instance.sId);
			el.setAttribute(EXTERNAL_CLASS_SCOPE_ATTRIBUTE, [...scopeTokens].join(" "));
		}
	}
}
function collectEventBindings(props = {}) {
	const eventBindings = {};
	for (const [attrName, handler] of Object.entries(props || {})) {
		const match = attrName.match(/^(capture-)?(bind|catch)(?::)?(.+)$/);
		if (!match || handler === void 0 || handler === null || handler === "") continue;
		const [, capture, listenerType, eventType] = match;
		const bindingType = capture ? listenerType === "catch" ? "captureCatch" : "captureBind" : listenerType;
		eventBindings[eventType] = eventBindings[eventType] || {};
		eventBindings[eventType][bindingType] = handler;
	}
	return eventBindings;
}
function getEventBindingRecord(el, binding, vnode) {
	const target = vnode.component?.proxy;
	return el._ddEventBindings?.find((record) => record.owner === binding.instance && record.target === target && record.nodeType === binding.value);
}
function mountEventBindingRecord(el, binding, vnode) {
	const record = {
		owner: binding.instance,
		target: vnode.component?.proxy,
		nodeType: binding.value,
		eventAttr: collectEventBindings(vnode.props)
	};
	el._ddEventBindings = el._ddEventBindings || [];
	el._ddEventBindings.push(record);
}
function updateEventBindingRecord(el, binding, vnode) {
	const record = getEventBindingRecord(el, binding, vnode);
	if (record) record.eventAttr = collectEventBindings(vnode.props);
}
function removeEventBindingRecord(el, binding, vnode) {
	const record = getEventBindingRecord(el, binding, vnode);
	if (!record) return;
	const index = el._ddEventBindings.indexOf(record);
	if (index >= 0) el._ddEventBindings.splice(index, 1);
}
function Components(app) {
	app.directive("c-style", {
		mounted(el, binding) {
			transformCss(el, binding.value);
		},
		beforeUpdate(el) {
			restoreDirectiveStyle(el);
		},
		updated(el, binding) {
			transformCss(el, binding.value);
		}
	});
	app.directive("c-animation", {
		mounted(el, binding) {
			transformAnimation(el, binding.value);
		},
		updated(el, binding) {
			transformAnimation(el, binding.value);
		}
	});
	app.directive("c-data", {
		mounted(el, _binding, vnode) {
			parseDataset(el, vnode);
		},
		updated(el, _binding, vnode) {
			parseDataset(el, vnode);
		}
	});
	app.directive("c-class", {
		mounted(el, binding, vnode) {
			parseExternalClass(el, binding.instance, vnode);
		},
		updated(el, binding, vnode) {
			parseExternalClass(el, binding.instance, vnode);
		}
	});
	app.directive("c-prop-bindings", { mounted(el, binding) {
		el._propBindings = binding.value || {};
	} });
	app.directive("c-event-node", {
		mounted(el, binding, vnode) {
			mountEventBindingRecord(el, binding, vnode);
		},
		updated(el, binding, vnode) {
			updateEventBindingRecord(el, binding, vnode);
		},
		beforeUnmount(el, binding, vnode) {
			removeEventBindingRecord(el, binding, vnode);
		}
	});
	return components.forEach((component) => {
		component.mixins = [{ inheritAttrs: false }];
		install(app, component);
		for (const alias of LEGACY_COMPONENT_TAG_ALIASES[component.__tagName] || []) app.component(alias, component);
	});
}
components.map((obj) => obj.__tagName);
function appendSlotResult(target, result) {
	if (Array.isArray(result)) target.push(...result);
	else if (result !== null && result !== void 0) target.push(result);
}
function withDynamicSlotKey(slot) {
	if (!slot.key) return slot.fn;
	return (...args) => {
		const result = slot.fn(...args);
		if (result) result.key = slot.key;
		return result;
	};
}
function mergeSlotFunctions(existing, incoming) {
	return (...args) => {
		const existingResult = existing(...args);
		const incomingResult = incoming(...args);
		const merged = [];
		appendSlotResult(merged, existingResult);
		appendSlotResult(merged, incomingResult);
		const key = incomingResult?.key ?? existingResult?.key;
		if (key !== void 0) merged.key = key;
		return merged;
	};
}
/**
* Vue createSlots 对同名动态插槽采用覆盖语义；小程序需要按声明顺序合并内容。
*/
function createMiniProgramSlots(slots, dynamicSlots) {
	const addSlot = (slot) => {
		if (!slot) return;
		const slotFunction = withDynamicSlotKey(slot);
		const existing = slots[slot.name];
		slots[slot.name] = existing ? mergeSlotFunctions(existing, slotFunction) : slotFunction;
	};
	for (const slot of dynamicSlots || []) if (Array.isArray(slot)) slot.forEach(addSlot);
	else addSlot(slot);
	return slots;
}
var COMPONENT_HOST_ATTRIBUTE = "data-dd-component-host";
var STYLE_ISOLATION_ATTRIBUTE = "data-dd-style-isolation";
var STYLE_HOST_ATTRIBUTE = "data-dd-style-host";
var WXML_STYLE_PROP = "diminaWxmlStyle";
function createTemplateData() {
	const data = /* @__PURE__ */ reactive({});
	return {
		data,
		templateData: new Proxy(data, { getOwnPropertyDescriptor(target, key) {
			return Reflect.getOwnPropertyDescriptor(target, key) || (typeof key === "string" && !key.startsWith("$") && !key.startsWith("_") ? {
				configurable: true,
				enumerable: false,
				value: void 0
			} : void 0);
		} })
	};
}
function normalizeStyleIsolation(value) {
	if (value === "shared") return "shared";
	if (value === "apply-shared") return "apply-shared";
	return "isolated";
}
function acceptsGlobalStyles(styleIsolation) {
	return styleIsolation === "apply-shared" || styleIsolation === "shared";
}
function markComponentHost(vnode, styleIsolation, styleScopeId) {
	if (!vnode || typeof vnode !== "object") return vnode;
	return cloneVNode(vnode, {
		[COMPONENT_HOST_ATTRIBUTE]: "",
		[STYLE_ISOLATION_ATTRIBUTE]: styleIsolation,
		[STYLE_HOST_ATTRIBUTE]: styleScopeId
	});
}
function addStyleHostToken(element, styleScopeId) {
	const tokens = new Set((element.getAttribute(STYLE_HOST_ATTRIBUTE) || "").split(/\s+/).filter(Boolean));
	tokens.add(styleScopeId);
	element.setAttribute(STYLE_HOST_ATTRIBUTE, [...tokens].join(" "));
}
function normalizeEventAttributes(attrs = {}) {
	const eventAttr = {};
	for (const [attrName, handler] of Object.entries(attrs)) {
		const match = attrName.match(/^(capture-)?(bind|catch)(?::)?(.+)$/);
		if (!match || handler === void 0 || handler === null || handler === "") continue;
		const [, capture, listenerType, eventType] = match;
		const bindingType = capture ? listenerType === "catch" ? "captureCatch" : "captureBind" : listenerType;
		eventAttr[eventType] = eventAttr[eventType] || {};
		eventAttr[eventType][bindingType] = handler;
	}
	return eventAttr;
}
function orderEventBindingRecords(records = []) {
	const remaining = [...records];
	const ordered = [];
	while (remaining.length > 0) {
		const innerIndex = remaining.findIndex((candidate) => !remaining.some((other) => other !== candidate && other.owner === candidate.target));
		ordered.push(...remaining.splice(innerIndex >= 0 ? innerIndex : 0, 1));
	}
	return ordered;
}
function isElementNode(node) {
	return node?.nodeType === 1 && typeof node.setAttribute === "function";
}
function applyStyleScopeAttributes(root, scopeIds, inheritedAccess, pageScopeId) {
	if (!isElementNode(root)) return;
	const visit = (element, canReceiveInheritedStyles) => {
		const isComponentHost = element.hasAttribute(COMPONENT_HOST_ATTRIBUTE);
		const hostAcceptsGlobalStyles = isComponentHost && acceptsGlobalStyles(normalizeStyleIsolation(element.getAttribute(STYLE_ISOLATION_ATTRIBUTE)));
		const isPageOwnedNode = pageScopeId && element.hasAttribute(pageScopeId);
		const receivesGlobalStyles = canReceiveInheritedStyles || hostAcceptsGlobalStyles || isPageOwnedNode;
		if (receivesGlobalStyles) for (const scopeId of scopeIds) element.setAttribute(scopeId, "");
		const childAccess = isComponentHost ? hostAcceptsGlobalStyles : receivesGlobalStyles;
		for (const child of element.children) visit(child, childAccess);
	};
	visit(root, inheritedAccess);
}
function canReceiveStylesFromParent(node, ownerRoot, pageScopeId) {
	let current = node.parentElement;
	while (current) {
		if (current.hasAttribute(COMPONENT_HOST_ATTRIBUTE)) return acceptsGlobalStyles(normalizeStyleIsolation(current.getAttribute(STYLE_ISOLATION_ATTRIBUTE)));
		if (pageScopeId && current.hasAttribute(pageScopeId)) return true;
		if (current === ownerRoot) return true;
		current = current.parentElement;
	}
	return false;
}
function observeStyleScopeRoot(root, scopeIds, pageScopeId) {
	if (!isElementNode(root) || scopeIds.length === 0) return null;
	applyStyleScopeAttributes(root, scopeIds, true, pageScopeId);
	const observer = new MutationObserver((records) => {
		for (const record of records) for (const node of record.addedNodes) {
			if (!isElementNode(node)) continue;
			applyStyleScopeAttributes(node, scopeIds, canReceiveStylesFromParent(node, root, pageScopeId), pageScopeId);
		}
	});
	observer.observe(root, {
		childList: true,
		subtree: true
	});
	return observer;
}
function collectVNodeRootElements(vnode, result = []) {
	if (!vnode) return result;
	if (Array.isArray(vnode)) {
		for (const child of vnode) collectVNodeRootElements(child, result);
		return result;
	}
	if (vnode.component?.subTree) return collectVNodeRootElements(vnode.component.subTree, result);
	if (vnode.suspense?.activeBranch) return collectVNodeRootElements(vnode.suspense.activeBranch, result);
	if (vnode.type === Fragment) return collectVNodeRootElements(vnode.children, result);
	if (isElementNode(vnode.el) && !result.includes(vnode.el)) result.push(vnode.el);
	return result;
}
function installStyleScopeSync(roots, scopeIds, pageScopeId) {
	const normalizedScopeIds = [...new Set(scopeIds.filter(Boolean))];
	const observers = roots.map((root) => observeStyleScopeRoot(root, normalizedScopeIds, pageScopeId)).filter(Boolean);
	return () => observers.forEach((observer) => observer.disconnect());
}
function hasVNodeProp(vnodeProps, name) {
	if (!vnodeProps) return false;
	if (Object.prototype.hasOwnProperty.call(vnodeProps, name)) return true;
	const kebabName = name.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
	return Object.prototype.hasOwnProperty.call(vnodeProps, kebabName);
}
function getVNodeProp(vnodeProps, name) {
	if (!vnodeProps) return void 0;
	if (Object.prototype.hasOwnProperty.call(vnodeProps, name)) return vnodeProps[name];
	return vnodeProps[name.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`)];
}
function applyWxmlStyleProperty(propertySchemas, values, vnode) {
	const normalizedValues = { ...values };
	if (propertySchemas?.style && hasVNodeProp(vnode?.props, WXML_STYLE_PROP)) normalizedValues.style = getVNodeProp(vnode.props, WXML_STYLE_PROP);
	delete normalizedValues[WXML_STYLE_PROP];
	return normalizedValues;
}
function normalizeStaticBooleanAttributes(propertySchemas, values, vnode) {
	const normalizedValues = { ...values };
	const dynamicProps = new Set(vnode?.dynamicProps || []);
	for (const [name, schema] of Object.entries(propertySchemas || {})) {
		if (schema.type !== Boolean || normalizedValues[name] !== "" || !hasVNodeProp(vnode?.props, name)) continue;
		const kebabName = name.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
		if (!dynamicProps.has(name) && !dynamicProps.has(kebabName)) normalizedValues[name] = true;
	}
	return normalizedValues;
}
var VUE_RUNTIME_HELPERS = {
	_Fragment: Fragment,
	_createTextVNode: createTextVNode,
	_createVNode: createVNode,
	_createBlock: createBlock,
	_createCommentVNode: createCommentVNode,
	_createElementBlock: createElementBlock,
	_createElementVNode: createBaseVNode,
	_createSlots: createMiniProgramSlots,
	_normalizeClass: normalizeClass,
	_normalizeStyle: normalizeStyle,
	_openBlock: openBlock,
	_renderList: renderList,
	_renderSlot: renderSlot,
	_resolveComponent: resolveComponent,
	_resolveDirective: resolveDirective,
	_resolveDynamicComponent: resolveDynamicComponent,
	_toDisplayString: toDisplayString,
	_withCtx: withCtx,
	_withDirectives: withDirectives
};
var CANVAS_NODE_TYPE = "dimina-canvas-node";
var TYPED_ARRAY_CTORS = {
	Int8Array,
	Uint8Array,
	Uint8ClampedArray,
	Int16Array,
	Uint16Array,
	Int32Array,
	Uint32Array,
	Float32Array,
	Float64Array
};
var WEBGL_PARAMETER_NAMES = [
	"VERSION",
	"SHADING_LANGUAGE_VERSION",
	"VENDOR",
	"RENDERER",
	"MAX_VIEWPORT_DIMS",
	"ALIASED_POINT_SIZE_RANGE",
	"ALIASED_LINE_WIDTH_RANGE",
	"COMPRESSED_TEXTURE_FORMATS",
	"MAX_TEXTURE_SIZE",
	"MAX_CUBE_MAP_TEXTURE_SIZE",
	"MAX_RENDERBUFFER_SIZE",
	"MAX_VERTEX_ATTRIBS",
	"MAX_TEXTURE_IMAGE_UNITS",
	"MAX_VERTEX_TEXTURE_IMAGE_UNITS",
	"MAX_COMBINED_TEXTURE_IMAGE_UNITS",
	"MAX_VERTEX_UNIFORM_VECTORS",
	"MAX_FRAGMENT_UNIFORM_VECTORS",
	"MAX_VARYING_VECTORS",
	"RED_BITS",
	"GREEN_BITS",
	"BLUE_BITS",
	"ALPHA_BITS",
	"DEPTH_BITS",
	"STENCIL_BITS",
	"SUBPIXEL_BITS",
	"SAMPLE_BUFFERS",
	"SAMPLES",
	"MAX_3D_TEXTURE_SIZE",
	"MAX_ARRAY_TEXTURE_LAYERS",
	"MAX_COLOR_ATTACHMENTS",
	"MAX_DRAW_BUFFERS",
	"MAX_ELEMENT_INDEX",
	"MAX_ELEMENTS_INDICES",
	"MAX_ELEMENTS_VERTICES",
	"MAX_FRAGMENT_INPUT_COMPONENTS",
	"MAX_SAMPLES",
	"MAX_SERVER_WAIT_TIMEOUT",
	"MAX_TEXTURE_LOD_BIAS",
	"MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS",
	"MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS",
	"MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS",
	"MAX_UNIFORM_BLOCK_SIZE",
	"MAX_UNIFORM_BUFFER_BINDINGS",
	"MAX_VARYING_COMPONENTS",
	"MAX_VERTEX_OUTPUT_COMPONENTS",
	"UNIFORM_BUFFER_OFFSET_ALIGNMENT"
];
var WEBGL_PRECISION_NAMES = [
	"LOW_FLOAT",
	"MEDIUM_FLOAT",
	"HIGH_FLOAT",
	"LOW_INT",
	"MEDIUM_INT",
	"HIGH_INT"
];
function collectNumericConstants(value) {
	const constants = {};
	const visited = /* @__PURE__ */ new Set();
	for (let current = value; current && current !== Object.prototype; current = Object.getPrototypeOf(current)) for (const name of Object.getOwnPropertyNames(current)) {
		if (visited.has(name) || !/^[A-Z][A-Z0-9_]*$/.test(name)) continue;
		visited.add(name);
		try {
			if (typeof value[name] === "number") constants[name] = value[name];
		} catch {}
	}
	return constants;
}
function serializeCanvasResult(value, resolveResourceId) {
	if (value === null || value === void 0 || typeof value === "string" || typeof value === "number" || typeof value === "boolean") return value;
	const resourceId = resolveResourceId?.(value);
	if (resourceId) return { __canvasResourceId: resourceId };
	if (ArrayBuffer.isView(value)) return {
		__canvasTypedArray: value.constructor.name,
		data: Array.from(value)
	};
	if (Array.isArray(value)) return value.map((item) => serializeCanvasResult(item, resolveResourceId));
	if (typeof value === "object") {
		const result = {};
		const keys = new Set(Object.keys(value));
		for (const key of [
			"alpha",
			"antialias",
			"depth",
			"desynchronized",
			"failIfMajorPerformanceCaveat",
			"powerPreference",
			"premultipliedAlpha",
			"preserveDrawingBuffer",
			"stencil",
			"name",
			"precision",
			"rangeMax",
			"rangeMin",
			"size",
			"type"
		]) if (key in value) keys.add(key);
		for (const key of keys) {
			const serialized = serializeCanvasResult(value[key], resolveResourceId);
			if (serialized !== void 0) result[key] = serialized;
		}
		return result;
	}
}
function describeWebGLContext(context, includeExtensionConstants = true) {
	if (!context) return null;
	const constants = collectNumericConstants(context);
	const parameters = {};
	for (const name of WEBGL_PARAMETER_NAMES) {
		const pname = context[name];
		if (typeof pname !== "number") continue;
		try {
			parameters[pname] = serializeCanvasResult(context.getParameter(pname));
		} catch {}
	}
	let supportedExtensions = [];
	try {
		supportedExtensions = context.getSupportedExtensions?.() || [];
	} catch {}
	const extensions = {};
	for (const name of supportedExtensions) {
		if (!includeExtensionConstants) {
			extensions[name] = { constants: {} };
			continue;
		}
		try {
			const extension = context.getExtension(name);
			extensions[name] = { constants: extension ? collectNumericConstants(extension) : {} };
		} catch {
			extensions[name] = { constants: {} };
		}
	}
	const shaderPrecisionFormats = {};
	for (const shaderName of ["VERTEX_SHADER", "FRAGMENT_SHADER"]) for (const precisionName of WEBGL_PRECISION_NAMES) {
		const shaderType = context[shaderName];
		const precisionType = context[precisionName];
		if (typeof shaderType !== "number" || typeof precisionType !== "number") continue;
		try {
			const format = context.getShaderPrecisionFormat(shaderType, precisionType);
			if (format) shaderPrecisionFormats[`${shaderType}:${precisionType}`] = serializeCanvasResult(format);
		} catch {}
	}
	let contextAttributes = null;
	try {
		contextAttributes = serializeCanvasResult(context.getContextAttributes?.());
	} catch {}
	return {
		supported: true,
		constants,
		parameters,
		contextAttributes,
		supportedExtensions,
		extensions,
		shaderPrecisionFormats,
		drawingBufferWidth: context.drawingBufferWidth,
		drawingBufferHeight: context.drawingBufferHeight,
		contextLost: Boolean(context.isContextLost?.())
	};
}
function probeWebGLCapabilities() {
	const capabilities = {};
	for (const contextType of ["webgl", "webgl2"]) {
		const canvas = document.createElement("canvas");
		canvas.width = 1;
		canvas.height = 1;
		let context = null;
		try {
			context = canvas.getContext(contextType);
			if (!context && contextType === "webgl") context = canvas.getContext("experimental-webgl");
		} catch {}
		capabilities[contextType] = context ? describeWebGLContext(context) : { supported: false };
		try {
			context?.getExtension?.("WEBGL_lose_context")?.loseContext?.();
		} catch {}
	}
	return capabilities;
}
function isCanvasElement(element) {
	return element?.tagName?.toLowerCase() === "canvas";
}
var Runtime = class {
	constructor() {
		this.app = null;
		this.pageId = null;
		this.instance = /* @__PURE__ */ new Map();
		this.moduleIds = /* @__PURE__ */ new WeakMap();
		this.moduleRootIds = /* @__PURE__ */ new WeakMap();
		this.setupData = /* @__PURE__ */ new Map();
		this.initializedModules = /* @__PURE__ */ new Set();
		this.preInitUpdates = /* @__PURE__ */ new Map();
		this.intersectionObservers = /* @__PURE__ */ new Map();
		this.mediaQueryObservers = /* @__PURE__ */ new Map();
		this.componentAnimations = /* @__PURE__ */ new Map();
		this.performanceObservers = /* @__PURE__ */ new Map();
		this.canvasNodes = /* @__PURE__ */ new Map();
		this.canvasResources = /* @__PURE__ */ new Map();
		this.canvasRafIds = /* @__PURE__ */ new Map();
		this.canvasCapabilities = null;
		this._pendingSetups = /* @__PURE__ */ new Map();
		this._instanceWaiters = /* @__PURE__ */ new Map();
		this.handleBeforeUnload = this.handleBeforeUnload.bind(this);
		this.installVueRuntimeHelpers();
		window.addEventListener("beforeunload", this.handleBeforeUnload);
	}
	installVueRuntimeHelpers(target = window) {
		Object.assign(target, VUE_RUNTIME_HELPERS);
	}
	handleBeforeUnload() {
		if (this.intersectionObservers.size > 0) {
			for (const observers of this.intersectionObservers.values()) observers.forEach((observer) => observer.disconnect());
			this.intersectionObservers.clear();
		}
		for (const { mediaQueryList, listener } of this.mediaQueryObservers.values()) {
			mediaQueryList.removeEventListener?.("change", listener);
			mediaQueryList.removeListener?.(listener);
		}
		this.mediaQueryObservers.clear();
		for (const animations of this.componentAnimations.values()) animations.forEach((animation) => animation.cancel());
		this.componentAnimations.clear();
		for (const observer of this.performanceObservers.values()) observer.disconnect();
		this.performanceObservers.clear();
	}
	syncReactiveState(state, nextState = {}) {
		for (const key in state) if (!(key in nextState)) delete state[key];
		Object.assign(state, nextState);
	}
	/**
	* 首次渲染
	* [Container] resourceLoaded -> [Service] firstRender -> [Render] firstRender
	* @param {*} opts
	*/
	firstRender(opts) {
		const { bridgeId, pagePath, pageId, query } = opts;
		const options = this.makeOptions({
			path: pagePath,
			bridgeId,
			pageId,
			query
		});
		if (this.app != null) this.app.unmount();
		this.app = createApp(options.app);
		this.app.use(Components);
		this.registerTplComponentsByPath(opts.pagePath, bridgeId);
		this.app.mount(document.body);
	}
	registerTplComponentsByPath(path, bridgeId, visited = /* @__PURE__ */ new Set()) {
		if (visited.has(path)) return;
		visited.add(path);
		const module = loader_default.getModuleByPath(path);
		if (!module?.moduleInfo) return;
		const { id, tplComponents = {}, usingComponents = {}, componentPlaceholder = {} } = module.moduleInfo;
		const components = this.createComponent(path, bridgeId, usingComponents, /* @__PURE__ */ new Map(), componentPlaceholder);
		for (const [tplName, render] of Object.entries(tplComponents)) this.app.component(`dd-${tplName}`, this.createTplComponent({
			id,
			components,
			render
		}));
		for (const componentPath of Object.values(usingComponents)) this.registerTplComponentsByPath(componentPath, bridgeId, visited);
	}
	createTplComponent({ id, components, render }) {
		return {
			__scopeId: `data-v-${id}`,
			components,
			props: { data: Object },
			setup(props) {
				const { data: state, templateData } = createTemplateData();
				watchEffect(() => {
					const newData = props.data || {};
					for (const key in state) if (!(key in newData)) delete state[key];
					Object.assign(state, newData);
				});
				return templateData;
			},
			render
		};
	}
	makeOptions(opts) {
		const { path, bridgeId, pageId } = opts;
		const pageModule = loader_default.getModuleByPath(path);
		const { id, appStyleScopeId, sharedStyleScopeIds = [], usingComponents, componentPlaceholder = {}, tplComponents, customTabBar } = pageModule.moduleInfo;
		const pageRender = pageModule.moduleInfo.render;
		const customTabBarComponentName = customTabBar?.componentName;
		const hasCustomTabBar = typeof customTabBarComponentName === "string" && Object.prototype.hasOwnProperty.call(usingComponents || {}, customTabBarComponentName);
		this.pageId = pageId;
		const that = this;
		const rootCom = "dd-page";
		const sId = `data-v-${id}`;
		const globalStyleScopeIds = [
			appStyleScopeId ? `data-v-${appStyleScopeId}` : null,
			sId,
			...sharedStyleScopeIds.map((scopeId) => `data-v-${scopeId}`)
		].filter(Boolean);
		const components = this.createComponent(path, bridgeId, usingComponents, /* @__PURE__ */ new Map(), componentPlaceholder);
		return {
			id,
			tplComponents,
			app: {
				render: () => {
					const _component_dd_page = resolveComponent(rootCom);
					return h(Suspense, { onResolve: () => {
						message_default.invoke({
							type: "domReady",
							target: "container",
							body: { bridgeId }
						});
					} }, { default: () => h(_component_dd_page) });
				},
				components: { [rootCom]: {
					name: path,
					__scopeId: sId,
					async setup(_props, { expose }) {
						expose();
						const vueInstance = getCurrentInstance();
						provide("bridgeId", bridgeId);
						provide("path", path);
						provide(path, { id: that.pageId });
						provide("info", {
							id: that.pageId,
							sId
						});
						const instance = vueInstance.proxy;
						instance.__page__ = true;
						that.setModuleInstance(that.pageId, instance);
						let stopStyleScopeSync = () => {};
						let ticking = false;
						const handleScroll = () => {
							if (!ticking) {
								window.requestAnimationFrame(() => {
									message_default.send({
										type: "pageScroll",
										target: "service",
										body: {
											bridgeId,
											moduleId: that.pageId,
											scrollTop: window.scrollY
										}
									});
									ticking = false;
								});
								ticking = true;
							}
						};
						onMounted(() => {
							stopStyleScopeSync = installStyleScopeSync(collectVNodeRootElements(vueInstance.subTree), globalStyleScopeIds, sId);
							window.addEventListener("scroll", handleScroll, { passive: true });
							nextTick(() => {
								message_default.send({
									type: "pageReady",
									target: "service",
									body: {
										bridgeId,
										moduleId: that.pageId
									}
								});
							});
						});
						onUnmounted(() => {
							stopStyleScopeSync();
							window.removeEventListener("scroll", handleScroll);
						});
						const { data, templateData } = createTemplateData();
						that.setupData.set(that.pageId, data);
						const initData = await message_default.wait(that.pageId);
						that.applyInitialData(that.pageId, data, initData);
						return templateData;
					},
					components,
					render: hasCustomTabBar ? function(...args) {
						return h(Fragment, null, [pageRender.apply(this, args), h(resolveComponent(`dd-${customTabBarComponentName}`))]);
					} : pageRender
				} }
			}
		};
	}
	getParentModuleId(vueInstance) {
		let parent = vueInstance?.parent;
		while (parent) {
			const moduleId = this.moduleIds.get(parent.proxy);
			if (moduleId) return moduleId;
			parent = parent.parent;
		}
	}
	applyInitialData(moduleId, data, initData) {
		const entries = Object.entries(initData);
		for (let i = 0; i < entries.length; i++) {
			const [key, value] = entries[i];
			set(data, key, value);
		}
		const pendingUpdate = this.preInitUpdates.get(moduleId);
		if (pendingUpdate) {
			const pendingData = pendingUpdate.data || pendingUpdate;
			if ((pendingUpdate.changes || []).length > 0) for (const change of pendingUpdate.changes) set(data, change.path, change.value);
			else for (const [key, value] of Object.entries(pendingData)) set(data, key, value);
			this.preInitUpdates.delete(moduleId);
		}
		this.initializedModules.add(moduleId);
		return pendingUpdate;
	}
	refreshProxyAccess(moduleId, changedData) {
		const internal = this.instance.get(moduleId)?.$;
		if (!internal) return;
		const { accessCache, ctx } = internal;
		for (const [key, value] of Object.entries(changedData)) {
			if (accessCache && Object.prototype.hasOwnProperty.call(accessCache, key)) delete accessCache[key];
			if (ctx && !Object.prototype.hasOwnProperty.call(ctx, key)) ctx[key] = value;
		}
		internal.update?.();
	}
	setModuleInstance(moduleId, instance) {
		if (!instance) return;
		this.instance.set(moduleId, instance);
		this.moduleIds.set(instance, moduleId);
		if (this._instanceWaiters.has(moduleId)) {
			this._instanceWaiters.get(moduleId).forEach((resolve) => resolve(instance));
			this._instanceWaiters.delete(moduleId);
		}
	}
	deleteModuleInstance(moduleId) {
		const instance = this.instance.get(moduleId);
		if (instance) this.moduleIds.delete(instance);
		this.instance.delete(moduleId);
	}
	registerModuleRoots(moduleId, roots) {
		for (const root of roots) {
			const moduleIds = this.moduleRootIds.get(root) || [];
			if (!moduleIds.includes(moduleId)) {
				moduleIds.push(moduleId);
				this.moduleRootIds.set(root, moduleIds);
			}
		}
	}
	unregisterModuleRoots(moduleId, roots) {
		for (const root of roots) {
			const moduleIds = this.moduleRootIds.get(root);
			if (!moduleIds) continue;
			const nextModuleIds = moduleIds.filter((id) => id !== moduleId);
			if (nextModuleIds.length > 0) this.moduleRootIds.set(root, nextModuleIds);
			else this.moduleRootIds.delete(root);
		}
	}
	getRenderParentModuleId(roots, moduleId) {
		for (const root of roots) {
			let element = root.parentElement;
			while (element) {
				const parentId = (this.moduleRootIds.get(element) || []).findLast((id) => id !== moduleId);
				if (parentId) return parentId;
				element = element.parentElement;
			}
		}
	}
	collectCustomEventPath(root, targetModuleId) {
		const eventPath = [];
		let element = root;
		while (element) {
			for (const record of orderEventBindingRecords(element._ddEventBindings)) {
				const moduleId = this.moduleIds.get(record.owner);
				const nodeModuleId = this.moduleIds.get(record.target);
				if (!moduleId) continue;
				const isComponentHost = record.nodeType === "component";
				if (element === root && !isComponentHost && moduleId === targetModuleId) continue;
				if (isComponentHost && nodeModuleId === targetModuleId) continue;
				eventPath.push({
					moduleId,
					nodeModuleId,
					isComponentHost,
					eventAttr: record.eventAttr,
					targetInfo: {
						id: element.id,
						dataset: {
							...element.dataset,
							...element._ds
						}
					}
				});
			}
			element = element.parentElement;
		}
		return eventPath;
	}
	createComponent(path, bridgeId, usingComponents, componentCache = /* @__PURE__ */ new Map(), componentPlaceholder = {}) {
		if (!usingComponents || Object.keys(usingComponents).length === 0) return;
		const components = {};
		const that = this;
		for (const [componentName, componentPath] of Object.entries(usingComponents)) {
			let resolvedComponentPath = componentPath;
			let cacheKey = `${path}\0${resolvedComponentPath}`;
			let cachedComponent = componentCache.get(cacheKey);
			if (cachedComponent) {
				components[`dd-${componentName}`] = cachedComponent;
				continue;
			}
			let module = loader_default.getModuleByPath(resolvedComponentPath);
			if (!module?.moduleInfo) {
				const placeholderName = componentPlaceholder[componentName];
				const placeholderPath = placeholderName && usingComponents[placeholderName];
				if (placeholderPath) {
					resolvedComponentPath = placeholderPath;
					cacheKey = `${path}\0${resolvedComponentPath}`;
					cachedComponent = componentCache.get(cacheKey);
					if (cachedComponent) {
						components[`dd-${componentName}`] = cachedComponent;
						continue;
					}
					module = loader_default.getModuleByPath(resolvedComponentPath);
				}
			}
			if (!module?.moduleInfo) continue;
			const { id, usingComponents: subUsing, componentPlaceholder: subPlaceholder = {}, customTabBar } = module.moduleInfo;
			const sId = `data-v-${id}`;
			const styleIsolation = normalizeStyleIsolation(module.moduleInfo.styleIsolation);
			const componentOptions = {
				name: resolvedComponentPath,
				__scopeId: sId,
				components: void 0,
				props: {
					...module.props,
					[WXML_STYLE_PROP]: { type: null }
				},
				async setup(props, { attrs, expose }) {
					const parentInfo = inject("info");
					const parentPath = inject("path");
					const vueInstance = getCurrentInstance();
					expose({
						props,
						sId: vueInstance.vnode.scopeId || parentInfo.sId
					});
					const parentId = that.getParentModuleId(vueInstance) || parentInfo.id;
					const pageInfo = inject(path, null);
					const pageId = pageInfo?.id || parentId;
					const pagePath = pageInfo ? path : parentPath;
					const moduleId = `${id}_${uuid$1()}`;
					provide("info", {
						id: moduleId,
						sId
					});
					provide("path", resolvedComponentPath);
					provide(resolvedComponentPath, {
						id: moduleId,
						pagePath,
						pageId
					});
					const instance = vueInstance.proxy;
					that.setModuleInstance(moduleId, instance);
					const normalizeCurrentProperties = () => normalizePropertyValues(module.propertySchemas, normalizeStaticBooleanAttributes(module.propertySchemas, applyWxmlStyleProperty(module.propertySchemas, deepToRaw(props), vueInstance.vnode), vueInstance.vnode), {
						isAbsent: (name) => !hasVNodeProp(vueInstance.vnode.props, name) && !(name === "style" && hasVNodeProp(vueInstance.vnode.props, WXML_STYLE_PROP)),
						warn: (warning) => console.warn("[system]", "[render]", warning)
					});
					const externalClasses = [];
					for (const [k, v] of Object.entries(module.props ?? {})) if (v.cls) externalClasses.push(k);
					provide("externalClasses", externalClasses);
					const eventAttr = normalizeEventAttributes(attrs);
					const initialProperties = normalizeCurrentProperties();
					const propertyNames = Object.keys(module.propertySchemas || {}).filter((name) => hasVNodeProp(vueInstance.vnode.props, name) || name === "style" && hasVNodeProp(vueInstance.vnode.props, WXML_STYLE_PROP));
					const initDataPromise = message_default.waitAndSend(moduleId, {
						type: "mC",
						target: "service",
						body: {
							bridgeId,
							moduleId,
							path: resolvedComponentPath,
							isCustomTabBar: customTabBar === true,
							pageId,
							parentId,
							eventAttr,
							targetInfo: {
								dataset: getDataAttributes$1(attrs, deepToRaw),
								id: attrs.id,
								class: attrs.class
							},
							properties: initialProperties,
							propertyNames,
							propBindings: null
						}
					});
					let _pendingResolved = false;
					let _resolvePending;
					const _pendingResolve = () => {
						if (_pendingResolved) return;
						_pendingResolved = true;
						_resolvePending?.();
					};
					that._pendingSetups.set(moduleId, new Promise((r) => _resolvePending = r));
					onMounted(() => {
						const roots = collectVNodeRootElements(vueInstance.subTree);
						that.registerModuleRoots(moduleId, roots);
						for (const root of roots) {
							root.setAttribute(COMPONENT_HOST_ATTRIBUTE, "");
							root.setAttribute(STYLE_ISOLATION_ATTRIBUTE, styleIsolation);
							addStyleHostToken(root, id);
						}
						nextTick(() => {
							const renderParentId = that.getRenderParentModuleId(roots, moduleId);
							message_default.send({
								type: "mA",
								target: "service",
								body: {
									bridgeId,
									moduleId,
									parentId: renderParentId || parentId
								}
							});
							const propBindings = instance.$el?._propBindings;
							const eventPath = that.collectCustomEventPath(instance.$el, moduleId);
							message_default.send({
								type: "mR",
								target: "service",
								body: {
									bridgeId,
									moduleId,
									propBindings,
									eventPath
								}
							});
						});
						if (eventAttr.tap) instance.$el.addEventListener("click", (event) => {
							triggerEvent("tap", {
								event,
								info: {
									attrs,
									bridgeId,
									moduleId: pageId
								}
							});
						});
					});
					let unregisterFormControl;
					onUnmounted(() => {
						unregisterFormControl?.();
						const roots = collectVNodeRootElements(vueInstance.subTree);
						that.unregisterModuleRoots(moduleId, roots);
						message_default.send({
							type: "mU",
							target: "service",
							body: {
								bridgeId,
								moduleId
							}
						});
						that.deleteModuleInstance(moduleId);
						that.setupData.delete(moduleId);
						that.initializedModules.delete(moduleId);
						that.preInitUpdates.delete(moduleId);
						that._pendingSetups.delete(moduleId);
						_pendingResolve();
					});
					const { data, templateData } = createTemplateData();
					that.setupData.set(moduleId, data);
					if (module.builtinBehaviors?.has("wx://form-field")) unregisterFormControl = inject("registerFormControl", void 0)?.({
						getName: () => Object.prototype.hasOwnProperty.call(data, "name") ? data.name : props.name,
						getValue: () => Object.prototype.hasOwnProperty.call(data, "value") ? data.value : props.value
					});
					let previousNormalizedProps = initialProperties;
					let isInitialPropsWatch = true;
					watch(() => deepToRaw(props), () => {
						const newProps = isInitialPropsWatch ? initialProperties : normalizeCurrentProperties();
						Object.assign(data, newProps);
						if (isInitialPropsWatch) {
							isInitialPropsWatch = false;
							return;
						}
						const changedProps = Object.entries(newProps).reduce((acc, [key, value]) => {
							if (!deepEqual(value, previousNormalizedProps[key])) acc[key] = value;
							return acc;
						}, {});
						previousNormalizedProps = newProps;
						if (Object.keys(changedProps).length === 0) return;
						message_default.send({
							type: "t",
							target: "service",
							body: {
								bridgeId,
								moduleId,
								methodName: "tO",
								event: changedProps
							}
						});
					}, { immediate: true });
					const initData = await initDataPromise;
					that._pendingSetups.delete(moduleId);
					_pendingResolve();
					that.applyInitialData(moduleId, data, initData);
					return templateData;
				},
				render(...args) {
					return markComponentHost(module.moduleInfo.render.apply(this, args), styleIsolation, id);
				}
			};
			componentCache.set(cacheKey, componentOptions);
			componentOptions.components = this.createComponent(resolvedComponentPath, bridgeId, subUsing, componentCache, subPlaceholder);
			components[`dd-${componentName}`] = componentOptions;
		}
		return components;
	}
	updateModule(opts) {
		const { moduleId, data, changes = [] } = opts;
		const setupData = this.setupData.get(moduleId);
		if (setupData) {
			let hasNewReactiveKey = false;
			const newKeys = {};
			if (!this.initializedModules.has(moduleId)) {
				const pendingUpdate = this.preInitUpdates.get(moduleId) || {
					data: {},
					changes: []
				};
				Object.assign(pendingUpdate.data, data);
				pendingUpdate.changes.push(...changes);
				this.preInitUpdates.set(moduleId, pendingUpdate);
			}
			if (changes.length === 0) for (const key in data) {
				if (!Object.prototype.hasOwnProperty.call(setupData, key)) {
					hasNewReactiveKey = true;
					newKeys[key] = data[key];
				}
				set(setupData, key, data[key]);
			}
			for (const change of changes) {
				const rootKey = change.path[0];
				if (!Object.prototype.hasOwnProperty.call(setupData, rootKey)) hasNewReactiveKey = true;
				set(setupData, change.path, change.value);
				newKeys[rootKey] = setupData[rootKey];
			}
			if (hasNewReactiveKey) this.refreshProxyAccess(moduleId, newKeys);
		} else console.warn("[system]", "[render]", `module ${moduleId} is not exist.`);
	}
	updateModules(opts) {
		const { bridgeId, updates = [], callbackIds = [] } = opts;
		updates.forEach((update) => this.updateModule(update));
		if (callbackIds.length > 0) nextTick(() => {
			callbackIds.forEach((id) => {
				message_default.send({
					type: "triggerCallback",
					target: "service",
					body: {
						bridgeId,
						id
					}
				});
			});
		});
	}
	/**
	* 等待特定 moduleId 的 Vue instance 注册到 this.instance map，
	* 用于 addIntersectionObserver 调用早于 setup 执行的场景（如 Page.onLoad）
	*/
	_waitForInstance(moduleId, timeout = 500) {
		const existing = this.instance.get(moduleId);
		if (existing) return Promise.resolve(existing);
		return new Promise((resolve) => {
			const waiters = this._instanceWaiters.get(moduleId) || [];
			waiters.push(resolve);
			this._instanceWaiters.set(moduleId, waiters);
			setTimeout(() => {
				const w = this._instanceWaiters.get(moduleId);
				if (w) {
					const idx = w.indexOf(resolve);
					if (idx !== -1) w.splice(idx, 1);
					if (w.length === 0) this._instanceWaiters.delete(moduleId);
				}
				resolve(void 0);
			}, timeout);
		});
	}
	async waitForEl(instance, timeout = 500) {
		if (!instance) return;
		if (instance.__page__) return document.body;
		const el = instance.$el;
		if (el) return el;
		return new Promise((resolve) => {
			const observer = new MutationObserver((_, obs) => {
				const el = instance.$el;
				if (el) {
					obs.disconnect();
					resolve(el);
				}
			});
			if (instance.$parent.$el?.nodeType === Node.COMMENT_NODE) observer.observe(document.body, {
				childList: true,
				subtree: true
			});
			else observer.observe(instance.$parent.$el, { childList: true });
			setTimeout(() => {
				observer.disconnect();
				resolve();
			}, timeout);
		});
	}
	async waitForElement(parent, selector, method, timeout = 500) {
		if (!parent[method]) {
			console.warn("[system]", "[render]", `waitForElement method ${method} in ${parent.nodeType}`);
			return null;
		}
		const elements = parent[method](selector);
		if (this.hasMatchedElements(elements)) return elements;
		return new Promise((resolve) => {
			const observer = new MutationObserver((_, obs) => {
				const elements = parent[method](selector);
				if (this.hasMatchedElements(elements)) {
					obs.disconnect();
					resolve(elements);
				}
			});
			observer.observe(parent, {
				childList: true,
				subtree: true
			});
			setTimeout(() => {
				observer.disconnect();
				resolve();
			}, timeout);
		});
	}
	hasMatchedElements(elements) {
		if (!elements) return false;
		if (elements instanceof NodeList || Array.isArray(elements)) return elements.length > 0;
		return true;
	}
	getCanvasNodeId(canvas) {
		if (!canvas.__diminaCanvasNodeId) Object.defineProperty(canvas, "__diminaCanvasNodeId", {
			value: `canvas_${uuid$1()}`,
			configurable: true
		});
		return canvas.__diminaCanvasNodeId;
	}
	getCanvasCapabilities() {
		if (!this.canvasCapabilities) this.canvasCapabilities = probeWebGLCapabilities();
		return this.canvasCapabilities;
	}
	publishCanvasCapabilities(bridgeId) {
		message_default.send({
			type: "canvasCapabilities",
			target: "service",
			body: {
				bridgeId,
				capabilities: this.getCanvasCapabilities()
			}
		});
	}
	registerCanvasNode(canvas, type = canvas.getAttribute?.("type") || "2d") {
		const nodeId = this.getCanvasNodeId(canvas);
		const isNewNode = !this.canvasNodes.has(nodeId);
		const rect = canvas.getBoundingClientRect?.();
		const width = Math.round(rect?.width || 0);
		const height = Math.round(rect?.height || 0);
		if (isNewNode && width > 0 && height > 0) {
			if (canvas.width !== width) canvas.width = width;
			if (canvas.height !== height) canvas.height = height;
		}
		if (isNewNode) this.canvasNodes.set(nodeId, {
			canvas,
			contexts: /* @__PURE__ */ new Map()
		});
		return {
			__diminaNodeType: CANVAS_NODE_TYPE,
			nodeId,
			type,
			width: canvas.width || width || 300,
			height: canvas.height || height || 150,
			webglCapabilities: this.getCanvasCapabilities()
		};
	}
	createOffscreenCanvas({ bridgeId, params }) {
		const { nodeId, width = 300, height = 150, type = "2d" } = params;
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		this.canvasNodes.set(nodeId, {
			canvas,
			type,
			contexts: /* @__PURE__ */ new Map()
		});
		if (type === "webgl" || type === "experimental-webgl" || type === "webgl2") this.publishCanvasCapabilities(bridgeId);
	}
	resolveCanvasArg(value) {
		if (value === null || value === void 0) return value;
		if (Array.isArray(value)) return value.map((item) => this.resolveCanvasArg(item));
		if (typeof value !== "object") return value;
		if (value.__canvasResourceId) return this.canvasResources.get(value.__canvasResourceId);
		if (value.__canvasNodeId) return this.canvasNodes.get(value.__canvasNodeId)?.canvas;
		if (value.__canvasTypedArray) {
			const Ctor = TYPED_ARRAY_CTORS[value.__canvasTypedArray];
			if (Ctor) return new Ctor(value.data || []);
			if (value.__canvasTypedArray === "DataView") return new DataView(new Uint8Array(value.data || []).buffer);
		}
		if (value.__canvasArrayBuffer) return new Uint8Array(value.data || []).buffer;
		const result = {};
		for (const [key, item] of Object.entries(value)) result[key] = this.resolveCanvasArg(item);
		return result;
	}
	getCanvasResource(id) {
		return this.canvasResources.get(id);
	}
	getCanvasResourceId(value) {
		if (value === null || value === void 0) return null;
		for (const [id, resource] of this.canvasResources) if (resource === value) return id;
		return null;
	}
	setCanvasResource(id, value) {
		if (id) this.canvasResources.set(id, value);
	}
	getCanvasImage(imageId) {
		let image = this.getCanvasResource(imageId);
		if (!image) {
			image = new Image();
			image.crossOrigin = "anonymous";
			this.setCanvasResource(imageId, image);
		}
		return image;
	}
	executeCanvasOperation(node, operation, bridgeId) {
		switch (operation.op) {
			case "setCanvasProperty":
				node.canvas[operation.prop] = operation.value;
				break;
			case "getContext": {
				let context = null;
				let statusMessage;
				try {
					context = node.canvas.getContext(operation.contextType, this.resolveCanvasArg(operation.attributes));
				} catch (error) {
					statusMessage = error instanceof Error ? error.message : String(error);
				}
				node.contexts.set(operation.contextId, context);
				this.setCanvasResource(operation.contextId, context);
				const isWebGL = operation.contextType === "webgl" || operation.contextType === "experimental-webgl" || operation.contextType === "webgl2";
				return {
					contextId: operation.contextId,
					context: context ? {
						success: true,
						capabilities: isWebGL ? describeWebGLContext(context, false) : null
					} : {
						success: false,
						statusMessage: statusMessage || `getContext(${operation.contextType}) returned null`
					}
				};
			}
			case "contextSetProperty": {
				const context = this.getCanvasResource(operation.contextId);
				if (context) try {
					context[operation.prop] = this.resolveCanvasArg(operation.value);
				} catch (error) {
					console.warn("[system]", "[render]", `Canvas context property ${operation.prop} failed: ${error}`);
				}
				break;
			}
			case "contextCall": {
				const context = this.getCanvasResource(operation.contextId);
				const method = context?.[operation.method];
				if (typeof method !== "function") break;
				const args = (operation.args || []).map((arg) => this.resolveCanvasArg(arg));
				try {
					const result = method.apply(context, args);
					this.setCanvasResource(operation.resultId, result);
				} catch (error) {
					console.warn("[system]", "[render]", `Canvas context call ${operation.method} failed: ${error}`);
				}
				const feedback = { contextId: operation.contextId };
				if (operation.feedback === "shader") {
					const shader = args[0];
					let metadata = {
						compileStatus: false,
						infoLog: ""
					};
					try {
						metadata = {
							shaderType: context.getShaderParameter(shader, context.SHADER_TYPE),
							compileStatus: context.getShaderParameter(shader, context.COMPILE_STATUS),
							infoLog: context.getShaderInfoLog(shader) || ""
						};
					} catch {}
					feedback.resource = {
						resourceId: operation.args?.[0]?.__canvasResourceId,
						metadata
					};
				} else if (operation.feedback === "program") {
					const program = args[0];
					let metadata = {
						linkStatus: false,
						validateStatus: false,
						infoLog: ""
					};
					try {
						metadata = {
							linkStatus: context.getProgramParameter(program, context.LINK_STATUS),
							validateStatus: context.getProgramParameter(program, context.VALIDATE_STATUS),
							infoLog: context.getProgramInfoLog(program) || ""
						};
					} catch {}
					feedback.resource = {
						resourceId: operation.args?.[0]?.__canvasResourceId,
						metadata
					};
				}
				if (operation.typedArrayUpdateId && Number.isInteger(operation.typedArrayArgIndex)) feedback.typedArray = {
					id: operation.typedArrayUpdateId,
					value: serializeCanvasResult(args[operation.typedArrayArgIndex])
				};
				return feedback;
			}
			case "contextQuery": {
				const context = this.getCanvasResource(operation.contextId);
				const method = context?.[operation.method];
				if (typeof method !== "function") break;
				let value = null;
				try {
					value = method.apply(context, (operation.args || []).map((arg) => this.resolveCanvasArg(arg)));
				} catch (error) {
					console.warn("[system]", "[render]", `Canvas context query ${operation.method} failed: ${error}`);
				}
				return {
					contextId: operation.contextId,
					query: {
						key: operation.key,
						value: serializeCanvasResult(value, (item) => this.getCanvasResourceId(item))
					}
				};
			}
			case "contextFeedback": break;
			case "getExtension": {
				const context = this.getCanvasResource(operation.contextId);
				let extension = null;
				try {
					extension = context?.getExtension?.(operation.name) || null;
				} catch (error) {
					console.warn("[system]", "[render]", `Canvas extension ${operation.name} failed: ${error}`);
				}
				this.setCanvasResource(operation.extensionId, extension);
				break;
			}
			case "extensionCall": {
				const extension = this.getCanvasResource(operation.extensionId);
				const method = extension?.[operation.method];
				if (typeof method === "function") try {
					const result = method.apply(extension, (operation.args || []).map((arg) => this.resolveCanvasArg(arg)));
					this.setCanvasResource(operation.resultId, result);
				} catch (error) {
					console.warn("[system]", "[render]", `Canvas extension call ${operation.method} failed: ${error}`);
				}
				break;
			}
			case "resourceCall": {
				const resource = this.getCanvasResource(operation.resourceId);
				const method = resource?.[operation.method];
				if (typeof method === "function") {
					const result = method.apply(resource, (operation.args || []).map((arg) => this.resolveCanvasArg(arg)));
					this.setCanvasResource(operation.resultId, result);
				}
				break;
			}
			case "createImage":
				this.getCanvasImage(operation.imageId);
				break;
			case "imageSetSrc": {
				const image = this.getCanvasImage(operation.imageId);
				image.onload = () => {
					this.triggerCallback(bridgeId, operation.onload, {
						width: image.width,
						height: image.height
					});
				};
				image.onerror = () => {
					this.triggerCallback(bridgeId, operation.onerror, { errMsg: `createImage:fail ${operation.src}` });
				};
				image.src = operation.src;
				break;
			}
			case "getImageData": {
				const context = this.getCanvasResource(operation.contextId);
				if (context) {
					const imageData = context.getImageData(operation.x, operation.y, operation.width, operation.height);
					this.triggerCallback(bridgeId, operation.callback, {
						data: Array.from(imageData.data),
						width: imageData.width,
						height: imageData.height
					});
				}
				break;
			}
			case "toDataURL": {
				const mimeType = operation.mimeType || "image/png";
				const dataURL = operation.quality !== void 0 ? node.canvas.toDataURL(mimeType, operation.quality) : node.canvas.toDataURL(mimeType);
				this.triggerCallback(bridgeId, operation.callback, dataURL);
				break;
			}
			default: console.warn("[system]", "[render]", `Unsupported canvas node operation: ${operation.op}`);
		}
	}
	canvasNodeFlush({ bridgeId, params }) {
		const node = this.canvasNodes.get(params.nodeId);
		if (!node) {
			console.warn("[system]", "[render]", `canvas node ${params.nodeId} not found`);
			this.triggerCallback(bridgeId, params.feedback, {});
			return;
		}
		const feedback = {
			contexts: {},
			typedArrays: []
		};
		const touchedContexts = /* @__PURE__ */ new Set();
		for (const operation of params.operations || []) {
			if (operation.contextId) touchedContexts.add(operation.contextId);
			const result = this.executeCanvasOperation(node, operation, bridgeId);
			if (!result) continue;
			if (result.contextId) {
				feedback.contexts[result.contextId] ||= {};
				if (result.context) Object.assign(feedback.contexts[result.contextId], result.context);
				if (result.resource?.resourceId) {
					feedback.contexts[result.contextId].resources ||= [];
					feedback.contexts[result.contextId].resources.push(result.resource);
				}
				if (result.query) {
					feedback.contexts[result.contextId].queries ||= [];
					feedback.contexts[result.contextId].queries.push(result.query);
				}
			}
			if (result.typedArray) feedback.typedArrays.push(result.typedArray);
		}
		for (const contextId of params.feedback ? touchedContexts : []) {
			const context = this.getCanvasResource(contextId);
			if (!context || typeof context.getError !== "function") continue;
			feedback.contexts[contextId] ||= {};
			feedback.contexts[contextId].contextLost = Boolean(context.isContextLost?.());
			const errors = [];
			for (let i = 0; i < 32; i++) {
				const error = context.getError();
				if (error === context.NO_ERROR) break;
				errors.push(error);
			}
			if (errors.length > 0) feedback.contexts[contextId].errors = errors;
		}
		this.triggerCallback(bridgeId, params.feedback, feedback);
	}
	canvasNodeRequestAnimationFrame({ bridgeId, params }) {
		const key = `${params.nodeId}:${params.requestId}`;
		const frameId = requestAnimationFrame((timestamp) => {
			this.canvasRafIds.delete(key);
			this.triggerCallback(bridgeId, params.callback, timestamp);
		});
		this.canvasRafIds.set(key, frameId);
	}
	canvasNodeCancelAnimationFrame({ params }) {
		const key = `${params.nodeId}:${params.requestId}`;
		const frameId = this.canvasRafIds.get(key);
		if (frameId !== void 0) {
			cancelAnimationFrame(frameId);
			this.canvasRafIds.delete(key);
		}
	}
	async selectorQuery(opts) {
		const { bridgeId, params: { tasks, success } } = opts;
		const executeQuery = async () => {
			return (await Promise.all(tasks.map(async (task) => {
				const { moduleId, selector, single, fields } = task;
				const el = await this.waitForEl(this.instance.get(moduleId));
				if (!el) {
					console.warn("[system]", "[render]", `module ${moduleId} dom is not exist.`);
					return null;
				}
				if (!el.querySelector) {
					console.warn("system", "[render]", `selectorQuery el node type is ${el.nodeType}`);
					return null;
				}
				const selectors = selector.split(",").map((s) => `${s.trim()}:not([data-dd-cloned] *)`).join(",");
				if (single) {
					const targetElement = el.querySelector(selectors);
					return targetElement ? await this.parseElement(targetElement, fields) : null;
				} else {
					const targetElements = el.querySelectorAll(selectors);
					const results = [];
					for (const el of targetElements) {
						const result = await this.parseElement(el, fields);
						results.push(result);
					}
					return results;
				}
			}))).filter(Boolean);
		};
		try {
			const res = await new Promise((resolve) => {
				requestAnimationFrame(async () => {
					resolve(await executeQuery());
				});
			});
			message_default.send({
				type: "triggerCallback",
				target: "service",
				body: {
					bridgeId,
					id: success,
					args: res
				}
			});
		} catch (error) {
			console.error("[system]", "[render]", "selectorQuery error:", error);
		}
	}
	videoContext(opts) {
		message_default.event.emit("videoContext", opts.params);
	}
	/**
	* 确保元素已准备好（有尺寸）
	*/
	ensureElementReady(element) {
		return new Promise((resolve) => {
			if (this.isElementReady(element)) return resolve(element);
			const observer = new ResizeObserver((entries) => {
				if (entries[0]?.contentRect?.height > 0 || entries[0]?.contentRect?.width > 0) {
					observer.disconnect();
					resolve(element);
				}
			});
			observer.observe(element);
			setTimeout(() => {
				observer.disconnect();
				resolve(element);
			}, 500);
		});
	}
	/**
	* 检查元素是否已准备好（有尺寸）
	*/
	isElementReady(element) {
		if (!element) return false;
		const rect = element.getBoundingClientRect();
		return rect.height > 0 || rect.width > 0;
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.fields.html
	*/
	async parseElement(targetElement, fields) {
		await this.ensureElementReady(targetElement);
		const data = {};
		if (fields.id) data.id = targetElement.id ?? "";
		if (fields.dataset) data.dataset = targetElement._ds;
		if (fields.mark) data.mark = targetElement.dataset?.mark ?? "";
		if (fields.rect) {
			const { left, top, right, bottom, width, height } = this.getElementRect(targetElement);
			data.left = left;
			data.top = top;
			data.right = right;
			data.bottom = bottom;
			data.width = width;
			data.height = height;
		}
		if (fields.size) if (fields.rect) {
			const { width, height } = this.getElementRect(targetElement);
			data.width = width;
			data.height = height;
		} else {
			data.width = targetElement.offsetWidth;
			data.height = targetElement.offsetHeight;
		}
		if (fields.scrollOffset) {
			data.scrollHeight = targetElement.scrollHeight;
			data.scrollLeft = targetElement.scrollLeft;
			data.scrollTop = targetElement.scrollTop;
			data.scrollWidth = targetElement.scrollWidth;
		}
		if (fields.properties && Array.isArray(fields.properties)) {
			const properties = {};
			fields.properties.forEach((prop) => {
				if (prop !== "id" && prop !== "class" && prop !== "style" && !prop.startsWith("bind") && !prop.startsWith("on")) properties[prop] = targetElement.getAttribute(prop) ?? "";
			});
			data.properties = properties;
		}
		if (fields.computedStyle && Array.isArray(fields.computedStyle)) {
			const computedStyle = window.getComputedStyle(targetElement);
			const styles = {};
			fields.computedStyle.forEach((style) => {
				styles[style] = computedStyle.getPropertyValue(style) || "";
			});
			data.computedStyle = styles;
		}
		if (fields.node) data.node = isCanvasElement(targetElement) ? this.registerCanvasNode(targetElement) : null;
		return data;
	}
	getElementRect(element) {
		return element.getBoundingClientRect();
	}
	triggerCallback(bridgeId, id, args = [], data) {
		if (!id) return;
		const body = {
			bridgeId,
			id
		};
		if (args !== void 0) body.args = args;
		if (data !== void 0) body.data = data;
		message_default.send({
			type: "triggerCallback",
			target: "service",
			body
		});
	}
	triggerCanvasFailure(bridgeId, params, errMsg) {
		const result = { errMsg };
		this.triggerCallback(bridgeId, params.fail, [result], result);
		this.triggerCallback(bridgeId, params.complete, [result], result);
	}
	async getCanvasElement(canvasId, moduleId) {
		const selector = `canvas[canvas-id="${canvasId}"]`;
		const scope = moduleId ? await this.waitForEl(this.instance.get(moduleId)) : document.body;
		if (scope?.querySelector) {
			const scopedCanvas = await this.waitForElement(scope, selector, "querySelector");
			if (scopedCanvas) return scopedCanvas;
		}
		return document.querySelector(selector);
	}
	ensureCanvasResolution(canvas) {
		const rect = canvas.getBoundingClientRect();
		const width = Math.max(Math.round(rect.width), 1);
		const height = Math.max(Math.round(rect.height), 1);
		if (canvas.width !== width) canvas.width = width;
		if (canvas.height !== height) canvas.height = height;
	}
	loadCanvasImage(src) {
		return new Promise((resolve, reject) => {
			const image = new Image();
			image.crossOrigin = "anonymous";
			image.onload = () => resolve(image);
			image.onerror = () => reject(/* @__PURE__ */ new Error(`Failed to load image: ${src}`));
			image.src = src;
		});
	}
	async replayCanvasActions(context, actions = []) {
		const state = { fontSize: 10 };
		const applyFont = () => {
			context.font = `${state.fontSize}px sans-serif`;
		};
		applyFont();
		for (const action of actions) {
			const { type, args = [] } = action || {};
			switch (type) {
				case "beginPath":
				case "closePath":
				case "moveTo":
				case "lineTo":
				case "rect":
				case "arc":
				case "quadraticCurveTo":
				case "bezierCurveTo":
				case "fill":
				case "stroke":
				case "clearRect":
				case "save":
				case "restore":
				case "translate":
				case "rotate":
				case "scale":
					context[type](...args);
					break;
				case "fillText":
					context.fillText(args[0], args[1], args[2], args[3]);
					break;
				case "drawImage": {
					const [src, ...drawArgs] = args;
					const image = await this.loadCanvasImage(src);
					context.drawImage(image, ...drawArgs);
					break;
				}
				case "setFillStyle":
					context.fillStyle = args[0];
					break;
				case "setStrokeStyle":
					context.strokeStyle = args[0];
					break;
				case "setGlobalAlpha":
					context.globalAlpha = args[0];
					break;
				case "setLineCap":
					context.lineCap = args[0];
					break;
				case "setLineJoin":
					context.lineJoin = args[0];
					break;
				case "setLineWidth":
					context.lineWidth = args[0];
					break;
				case "setMiterLimit":
					context.miterLimit = args[0];
					break;
				case "setFontSize":
					state.fontSize = args[0];
					applyFont();
					break;
				case "setShadow":
					context.shadowOffsetX = args[0];
					context.shadowOffsetY = args[1];
					context.shadowBlur = args[2];
					context.shadowColor = args[3];
					break;
				default: console.warn("[system]", "[render]", `Unsupported canvas action: ${type}`);
			}
		}
	}
	async drawCanvas({ bridgeId, params }) {
		const { canvasId, actions = [], reserve = false } = params;
		const canvas = await this.getCanvasElement(canvasId, params.moduleId);
		if (!canvas) {
			this.triggerCanvasFailure(bridgeId, params, `drawCanvas:fail canvas ${canvasId} not found`);
			return;
		}
		try {
			this.ensureCanvasResolution(canvas);
			const context = canvas.getContext("2d");
			if (!reserve) context.clearRect(0, 0, canvas.width, canvas.height);
			await this.replayCanvasActions(context, actions);
			const result = { errMsg: "drawCanvas:ok" };
			this.triggerCallback(bridgeId, params.success, [result], result);
			this.triggerCallback(bridgeId, params.complete, [result], result);
		} catch (error) {
			this.triggerCanvasFailure(bridgeId, params, `drawCanvas:fail ${error.message}`);
		}
	}
	async canvasToTempFilePath({ bridgeId, params }) {
		const { canvasId, x = 0, y = 0, width, height, destWidth, destHeight, fileType = "png", quality = 1 } = params;
		const canvas = await this.getCanvasElement(canvasId, params.moduleId);
		if (!canvas) {
			this.triggerCanvasFailure(bridgeId, params, `canvasToTempFilePath:fail canvas ${canvasId} not found`);
			return;
		}
		try {
			const exportWidth = width || canvas.width;
			const exportHeight = height || canvas.height;
			const outputCanvas = document.createElement("canvas");
			outputCanvas.width = destWidth || exportWidth;
			outputCanvas.height = destHeight || exportHeight;
			outputCanvas.getContext("2d").drawImage(canvas, x, y, exportWidth, exportHeight, 0, 0, outputCanvas.width, outputCanvas.height);
			const mimeType = fileType === "jpg" || fileType === "jpeg" ? "image/jpeg" : "image/png";
			const dataURL = outputCanvas.toDataURL(mimeType, quality);
			message_default.invoke({
				type: "invokeAPI",
				target: "container",
				body: {
					name: "saveCanvasTempFile",
					bridgeId,
					params: {
						dataURL,
						fileType,
						success: params.success,
						fail: params.fail,
						complete: params.complete
					}
				}
			});
		} catch (error) {
			this.triggerCanvasFailure(bridgeId, params, `canvasToTempFilePath:fail ${error.message}`);
		}
	}
	showToast({ params }) {
		window.__globalAPI.showToast(params);
	}
	hideToast({ params }) {
		window.__globalAPI.hideToast(params);
	}
	addIntersectionObserver(opts) {
		(async () => {
			const { bridgeId, params: { targetSelector, relativeInfo, moduleId, options, success } } = opts;
			const instance = await this._waitForInstance(moduleId);
			const el = await this.waitForEl(instance);
			if (!el) {
				console.error("[system]", "[render]", "Failed to find element for intersection observer");
				return;
			}
			const observers = [];
			for (const info of relativeInfo) {
				const observerOptions = {
					root: null,
					threshold: options.thresholds,
					rootMargin: info.margins,
					initialRatio: options.initialRatio,
					observeAll: options.observeAll
				};
				if (info.selector === null) {
					observerOptions.root = null;
					observers.push({ options: observerOptions });
					continue;
				}
				const relativeEl = await this.waitForElement(el, info.selector, "querySelector");
				const targetEls = await this.waitForElement(el, targetSelector, options.observeAll ? "querySelectorAll" : "querySelector");
				if (!relativeEl || !targetEls) {
					console.warn("[system]", "[render]", "Failed to find elements");
					continue;
				}
				if (Array.isArray(targetEls) || targetEls instanceof NodeList ? Array.from(targetEls).some((target) => target && relativeEl.contains(target)) : relativeEl.contains(targetEls)) observerOptions.root = relativeEl;
				else if (window.getComputedStyle(relativeEl).position === "fixed") {
					const computedStyle = window.getComputedStyle(relativeEl);
					const top = Number.parseFloat(computedStyle.top) || 0;
					const bottom = top + Number.parseFloat(computedStyle.height) || 0;
					const left = Number.parseFloat(computedStyle.left) || 0;
					const right = left + Number.parseFloat(computedStyle.width) || 0;
					observerOptions.root = null;
					observerOptions.type = "fixed";
					observerOptions.rootMargin = `${-top}px ${-(window.innerWidth - right)}px ${-(window.innerHeight - bottom)}px ${-left}px`;
				} else continue;
				observers.push({ options: observerOptions });
			}
			const targetEls = await this.waitForElement(el, targetSelector, options.observeAll ? "querySelectorAll" : "querySelector");
			if (!targetEls) {
				console.error("[system]", "[render]", "Failed to find target element for intersection observer");
				return;
			}
			const pendingExceptSelf = Array.from(this._pendingSetups.entries()).filter(([id]) => id !== moduleId).map(([, promise]) => promise);
			if (pendingExceptSelf.length > 0) await Promise.all(pendingExceptSelf);
			const allObservers = observers.map(({ options }) => {
				let initRatio = options.initialRatio;
				const observer = new IntersectionObserver((entries) => {
					entries.forEach((entry) => {
						if (entry.intersectionRatio === initRatio) return;
						initRatio = entry.intersectionRatio;
						const { top, bottom } = entry.boundingClientRect;
						const viewportHeight = window.innerHeight;
						if (!options.type && !entry.isIntersecting && top >= 0 && bottom <= viewportHeight) return;
						message_default.send({
							type: "triggerCallback",
							target: "service",
							body: {
								bridgeId,
								id: success,
								args: { info: {
									boundingClientRect: entry.boundingClientRect,
									intersectionRatio: entry.intersectionRatio,
									intersectionRect: entry.intersectionRect,
									relativeRect: entry.rootBounds,
									time: entry.time,
									dataset: entry.target._ds || {}
								} }
							}
						});
					});
				}, options);
				if (options.observeAll) Array.from(targetEls).forEach((target) => observer.observe(target));
				else observer.observe(targetEls);
				return observer;
			});
			const observerId = uuid$1();
			this.intersectionObservers.set(observerId, allObservers);
			message_default.send({
				type: "triggerCallback",
				target: "service",
				body: {
					bridgeId,
					id: success,
					args: { observerId }
				}
			});
		})();
	}
	removeIntersectionObserver({ params: { observerId } }) {
		if (!observerId) return;
		const observers = this.intersectionObservers.get(observerId);
		if (observers) {
			observers.forEach((observer) => observer.disconnect());
			this.intersectionObservers.delete(observerId);
		}
	}
	addMediaQueryObserver({ bridgeId, params }) {
		const { condition = {}, success } = params;
		const mediaFeatures = {
			minWidth: "min-width",
			maxWidth: "max-width",
			width: "width",
			minHeight: "min-height",
			maxHeight: "max-height",
			height: "height"
		};
		const clauses = [];
		for (const [key, feature] of Object.entries(mediaFeatures)) if (Number.isFinite(condition[key]) && condition[key] >= 0) clauses.push(`(${feature}: ${condition[key]}px)`);
		if (condition.orientation) clauses.push(`(orientation: ${condition.orientation})`);
		const mediaQueryList = window.matchMedia(clauses.join(" and ") || "all");
		const observerId = uuid$1();
		const listener = (event) => this.triggerCallback(bridgeId, success, {
			observerId,
			matches: event.matches
		});
		if (mediaQueryList.addEventListener) mediaQueryList.addEventListener("change", listener);
		else mediaQueryList.addListener?.(listener);
		this.mediaQueryObservers.set(observerId, {
			mediaQueryList,
			listener
		});
		this.triggerCallback(bridgeId, success, {
			observerId,
			matches: mediaQueryList.matches
		});
	}
	removeMediaQueryObserver({ params: { observerId } }) {
		const observer = this.mediaQueryObservers.get(observerId);
		if (!observer) return;
		if (observer.mediaQueryList.removeEventListener) observer.mediaQueryList.removeEventListener("change", observer.listener);
		else observer.mediaQueryList.removeListener?.(observer.listener);
		this.mediaQueryObservers.delete(observerId);
	}
	async componentAnimate({ bridgeId, params }) {
		const { moduleId, selector, keyframes = [], duration = 0, success } = params;
		const elements = (await this.waitForEl(this.instance.get(moduleId)))?.querySelectorAll?.(selector) || [];
		const animationKey = `${moduleId}:${selector}`;
		this.componentAnimations.get(animationKey)?.forEach((animation) => animation.cancel());
		const normalizedKeyframes = Array.from(keyframes, (keyframe) => {
			const normalized = { ...keyframe };
			if (normalized.ease && !normalized.easing) {
				normalized.easing = normalized.ease;
				delete normalized.ease;
			}
			return normalized;
		});
		const animations = Array.from(elements, (element) => element.animate(normalizedKeyframes, {
			duration: Math.max(Number(duration) || 0, 0),
			fill: "forwards"
		}));
		const animationSet = new Set(animations);
		this.componentAnimations.set(animationKey, animationSet);
		await Promise.allSettled(animations.map((animation) => animation.finished));
		if (this.componentAnimations.get(animationKey) === animationSet) this.componentAnimations.delete(animationKey);
		this.triggerCallback(bridgeId, success);
	}
	async componentClearAnimation({ bridgeId, params }) {
		const { moduleId, selector, options = {}, success } = params;
		const animationKey = `${moduleId}:${selector}`;
		const animations = this.componentAnimations.get(animationKey) || [];
		for (const animation of animations) {
			if (options.final) try {
				animation.finish();
				animation.commitStyles?.();
			} catch {}
			animation.cancel();
		}
		this.componentAnimations.delete(animationKey);
		this.triggerCallback(bridgeId, success);
	}
	addPerformanceObserver({ bridgeId, params }) {
		const { entryTypes = [], success } = params;
		const observerId = uuid$1();
		if (typeof PerformanceObserver === "undefined") {
			this.triggerCallback(bridgeId, success, {
				observerId,
				unsupported: true
			});
			return;
		}
		const supportedTypes = new Set(PerformanceObserver.supportedEntryTypes || []);
		const normalizedTypes = entryTypes.filter((type) => supportedTypes.size === 0 || supportedTypes.has(type));
		const observer = new PerformanceObserver((list) => {
			const entries = list.getEntries().map((entry) => typeof entry.toJSON === "function" ? entry.toJSON() : {
				name: entry.name,
				entryType: entry.entryType,
				startTime: entry.startTime,
				duration: entry.duration
			});
			this.triggerCallback(bridgeId, success, {
				observerId,
				data: { entryList: JSON.stringify(entries) }
			});
		});
		if (normalizedTypes.length > 0) observer.observe({ entryTypes: normalizedTypes });
		this.performanceObservers.set(observerId, observer);
		this.triggerCallback(bridgeId, success, { observerId });
	}
	removePerformanceObserver({ params: { observerId } }) {
		this.performanceObservers.get(observerId)?.disconnect();
		this.performanceObservers.delete(observerId);
	}
};
var runtime_default = new Runtime();
/**
* 渲染层消息通道
*/
var Render = class {
	constructor() {
		console.log("[system]", "[render]", "init");
		this.env = env_default;
		this.message = message_default;
		window.__message = message_default;
		window.__callback = callback_default;
		this.init();
	}
	init() {
		this.message.on("loadResource", (msg) => {
			const { bridgeId, appId, pagePath, root = ".", baseUrl = "/" } = msg;
			loader_default.loadResource({
				bridgeId,
				appId,
				pagePath,
				root,
				baseUrl
			});
		});
		this.message.on("firstRender", (msg) => {
			const { bridgeId, pageId, pagePath, initialProps, query } = msg;
			loader_default.setInitialData(initialProps);
			runtime_default.firstRender({
				pagePath,
				pageId,
				bridgeId,
				query
			});
		});
		this.message.on("u", (msg) => {
			queueMicrotask(() => {
				runtime_default.updateModule(msg);
			});
		});
		this.message.on("ub", (msg) => {
			queueMicrotask(() => {
				runtime_default.updateModules(msg);
			});
		});
		this.message.on("invokeAPI", (msg) => {
			runtime_default[msg.name](msg);
		});
		this.message.on("triggerCallback", (msg) => {
			const { success, data } = msg;
			success && callback_default.invoke(success, data);
		});
		this.message.on("print", (msg) => {
			const { type, detail } = msg;
			const logMethod = console[type] || console.log;
			let parsedDetail = detail;
			if (typeof detail === "string") try {
				if (detail.trim().startsWith("{")) parsedDetail = JSON.parse(detail);
			} catch {
				parsedDetail = detail;
			}
			if (typeof parsedDetail === "object" && parsedDetail !== null) {
				const { group, value } = parsedDetail;
				if (group === "network" && window.vConsole) window.vConsole.network.add(value);
				else logMethod("[system]", parsedDetail);
			} else if (typeof detail === "string" && detail.startsWith("[service]")) logMethod("[system]", detail);
			else logMethod(detail);
		});
	}
};
new Render();
//#endregion
//#region src/pages/pageFrame/pageFrame.js
window.modDefine = modDefine;
window.modRequire = modRequire$2;
//#endregion
